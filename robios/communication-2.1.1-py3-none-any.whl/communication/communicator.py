#!/usr/bin/env python
import os

class ClientCommunicator(object):
    ROBOT_ID_KEY = 'ROBOT_UID'
    EMPTY_ROBOT_ID = 'default'

    STATE_STARTING = 1
    STATE_ACTIVE = 2
    STATE_STOPPING = 3
    STATE_INACTIVE = 4

    def __init__(self, state_callback=None):
        self._state = ClientCommunicator.STATE_INACTIVE
        self.config = None
        self.state_callback = state_callback
        self._robot_id = None

        if state_callback is None:
            self._state_callback_list = []
        else:
            self._state_callback_list = [state_callback]

    
    def start(self):
        self._robot_id = os.getenv(ClientCommunicator.ROBOT_ID_KEY)

        # Set the default robot id over the environment variable, 
		# if it is defined in the configuration file
        if self.config.default_robot_id is not None and len(self.config.default_robot_id) > 0:
            self._robot_id = self.config.default_robot_id
    
    
    def stop(self):
        raise NotImplementedError()

    
    def publish(self, context: str, data: str) -> bool:
        raise NotImplementedError()

    
    def request(self, context: str, data: str) -> str:
        raise NotImplementedError()

    
    def subscribe(self, context: str, callback):
        raise NotImplementedError()

    
    def unsubscribe(self, context: str):
        raise NotImplementedError()


    def add_state_callback(self, callback):
        self._state_callback_list.append(callback)

    
    def remove_state_callback(self, callback):
        self._state_callback_list.remove(callback)


    def get_state(self):
        return self._state
    

    def _set_state(self, state: int, error: Exception = None):
        self._state = state

        for callback in self._state_callback_list:
            if callback is not None:
                callback(self._state, self.config.id, self.config.communication_type, error)


    def _format_context(self, context: str, for_publish: bool) -> str:
        replacement = '/'

        if self._robot_id is not None and len(self._robot_id) > 0:
            replacement = self._robot_id + replacement
        elif for_publish:
            replacement = ClientCommunicator.EMPTY_ROBOT_ID + replacement
        elif self.config.accept_any_robot_id:
            replacement = '+' + replacement

        index = context.index('/')
        context = context[:index+1] + replacement + context[index+1:]

        return context