#!/usr/bin/env python

COMMUNICATION_MQTT = 'mqtt'
COMMUNICATION_SOCKET = 'socket'
COMMUNICATION_BLUETOOTH = 'bluetooth'