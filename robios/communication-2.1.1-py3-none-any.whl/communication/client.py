#!/usr/bin/env python

from typing import List

from collections import OrderedDict
from communication.constants import COMMUNICATION_MQTT
import communication.config.manager as config_manager
from communication.clients.mqtt import MqttClientCommunicator
from communication.routines.communicator_restart import CommunicatorRestartRoutine

class CommunicationClient(object):

    def __init__(self, config=None, communicator_state_callback=None):
        self.communicator_state_callback = communicator_state_callback

        if (config is None):
            self.config = config_manager.load_client_config()
        else:
            self.config = config

        self._communicators = OrderedDict()
        self._restart_routines = OrderedDict()
        self._subscriptions = OrderedDict()

        for client_config in self.config.clients:
            communicator = MqttClientCommunicator(client_config, self._on_state_changed)
            self._communicators[client_config.id] = communicator

            if client_config.auto_restart == True:
                self._restart_routines[client_config.id] = CommunicatorRestartRoutine(communicator, client_config.restart_time)

    
    def start(self):
        for key in self._communicators:
            self._communicators[key].start()

            restart_routine = self._restart_routines.get(key, None)
            if restart_routine is not None:
                restart_routine.start()


    def stop(self):
        for key in self._communicators:
            restart_routine = self._restart_routines.get(key, None)
            if restart_routine is not None:
                restart_routine.stop()

            self._communicators[key].stop()


    def publish(self, context: str, data: str, clients=None) -> bool:
        if clients == None:
            clients = [ self.config.publish_config.default_communicator ]
        elif type(clients) == str:
            clients = [ clients ]

        all_sent = True

        for client_id in clients:
            communicator = self._communicators.get(client_id)

            if communicator is not None:
                all_sent = communicator.publish(context, data) and all_sent

        return all_sent


    def broadcast(self, context: str, data: str) -> bool:
        all_sent = True

        for communicator in self._communicators.values():
            all_sent = communicator.publish(context, data) and all_sent

        return all_sent


    def subscribe(self, context: str, callback):
        self._subscriptions[context] = callback

        for communicator in self._communicators.values():
            if communicator.get_state() == MqttClientCommunicator.STATE_ACTIVE:
                communicator.subscribe(context, callback)

    
    def unsubscribe(self, context: str):
        del self._subscriptions[context]

        for communicator in self._communicators.values():
            communicator.unsubscribe(context)


    def get_communicator_state(self, client_id: str) -> int:
        communicator = self._communicators.get(client_id)

        if communicator is None:
            return 0

        return communicator.get_state()


    def is_ready(self) -> bool:
        if len(self._communicators) == 0:
            return False

        for communicator in self._communicators.values():
            if communicator.get_state() is not MqttClientCommunicator.STATE_ACTIVE:
                return False

        return True
        

    def get_robot_id(self, client_id: str) -> str:
        communicator = self._communicators.get(client_id)

        if communicator is None:
            return None

        return communicator._robot_id


    def set_robot_id(self, client_id: str, robot_id: str):
        communicator = self._communicators.get(client_id)

        if communicator is not None:
            communicator._robot_id = robot_id


    def _on_state_changed(self, state, client_id, communication_type, error):
        if self.communicator_state_callback is not None:
            self.communicator_state_callback(client_id, state, error)

        # Subscribes to the stored contexts
        if state == MqttClientCommunicator.STATE_ACTIVE:
            for context, callback in self._subscriptions.items():
                comm = self._communicators[client_id]
                self._communicators[client_id].subscribe(context, callback)