class CommunicatorError(Exception):
    """Raised when a problem with a communicator occurs."""

    def __init__(self, message, communication_type):
        super().__init__(message)

        self.communication_type = communication_type