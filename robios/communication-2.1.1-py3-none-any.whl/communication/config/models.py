#!/usr/bin/env python

from communication.constants import COMMUNICATION_MQTT

class CommunicationClientConfig(object):
    def __init__(self):
        self.clients = []
        self.publish_config = None

    
    def get_default():
        config = CommunicationClientConfig()
        config.clients.append(ClientConfig.mqtt_default_config())
        config.publish_config = PublishConfig.mqtt_default_config()

        return config


class ClientConfig(object):
    DEFAULT_CLIENT_ID = 'client_01'

    def __init__(self):
        self.id = None
        self.communication_type = None
        self.server_address = None
        self.server_port = 0
        self.auto_restart = False
        self.restart_time = 0
        self.default_robot_id: str = None
        self.accept_any_robot_id: bool = False


    def mqtt_default_config():
        config = ClientConfig()
        config.id = ClientConfig.DEFAULT_CLIENT_ID
        config.communication_type = COMMUNICATION_MQTT
        config.server_address = "localhost"
        config.server_port = 1883
        config.auto_restart = True
        config.restart_time = 5

        return config


class PublishConfig(object):
    def __init__(self):
        self.default_communicator = None

    
    def mqtt_default_config():
        config = PublishConfig()
        config.default_communicator = "client_01"

        return config