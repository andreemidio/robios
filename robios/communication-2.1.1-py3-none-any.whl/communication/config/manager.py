#!/usr/bin/env python

import os
import json

from communication.config.models import ClientConfig
from communication.config.models import PublishConfig
from communication.config.models import CommunicationClientConfig

FILE_CLIENT = "communication_client.json"
FILE_BROKER = "communication_broker.json"

def load_client_config(config_path: str=None):
    if (config_path is None):
        path = os.path.abspath('') + "/conf/" + FILE_CLIENT
    else:
        path = config_path + FILE_CLIENT

    file_exists = os.path.isfile(path)
    if (not file_exists):
        return CommunicationClientConfig.get_default()

    with open(path) as json_file:
        json_object = json.load(json_file)
        
        config = CommunicationClientConfig()
        
        for client in json_object["clients"]:
            client_config = ClientConfig()
            
            if 'id' in client:
                client_config.id = client['id']
            if 'communicationType' in client:
                client_config.communication_type = client['communicationType']
            if 'serverAddress' in client:
                client_config.server_address = client['serverAddress']
            if 'serverPort' in client:
                client_config.server_port = client['serverPort']
            if 'autoRestart' in client:
                client_config.auto_restart = client['autoRestart']
            if 'restartTime' in client:
                client_config.restart_time = client['restartTime']
            if 'defaultRobotId' in client:
                client_config.default_robot_id = client['defaultRobotId']
            if 'acceptAnyRobotId' in client:
                client_config.accept_any_robot_id = client['acceptAnyRobotId']

            config.clients.append(client_config)

        publish_config = PublishConfig()
        publish_config.default_communicator = json_object["publishConfig"]["defaultCommunicator"]
        config.publish_config = publish_config

        return config