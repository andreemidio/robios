#!/usr/bin/env python

import uuid
import inspect

import paho.mqtt.client as mqtt

from communication.communicator import ClientCommunicator
from communication.config.models import ClientConfig
from communication.errors import CommunicatorError
from communication.utils.context import get_robot_id

class MqttClientCommunicator(ClientCommunicator):
    MQTT_RESULT_SUCCESS = 0
    MQTT_RESULT_INCORRECT_PROTOCOL_VERSION = 1
    MQTT_RESULT_INVALID_CLIENT = 2
    MQTT_RESULT_SERVER_UNAVAILABLE = 3
    MQTT_RESULT_BAD_USERNAME_OR_PASS = 4
    MQTT_RESULT_NOT_AUTHORISED = 5

    QOS_AT_MOST_ONCE = 0
    QOS_AT_LEAST_ONCE = 1
    QOS_EXACTLY_ONCE = 2

    def __init__(self, config=None, state_callback=None):
        super().__init__(state_callback)
        self.client_id = uuid.uuid4()
        self.mqtt_client = mqtt.Client()

        if (config is None):
            self.config = ClientConfig.mqtt_default_config()
        else:
            self.config = config
    
    
    def start(self):
        super().start()

        if self._state == ClientCommunicator.STATE_ACTIVE or self._state == ClientCommunicator.STATE_STARTING:
            return
        
        self._set_state(ClientCommunicator.STATE_STARTING)

        self.mqtt_client.reinitialise(str(self.client_id), True)
        self.mqtt_client.on_connect = self._on_connect
        self.mqtt_client.on_disconnect = self._on_disconnect
        
        self.mqtt_client.connect_async(self.config.server_address, self.config.server_port)
        self.mqtt_client.loop_start()

    
    def stop(self):
        if self._state == ClientCommunicator.STATE_INACTIVE or self._state == ClientCommunicator.STATE_STOPPING:
            return

        self._set_state(ClientCommunicator.STATE_STOPPING)

        self.mqtt_client.unsubscribe('#')
        self.mqtt_client.disconnect()
        self.mqtt_client.loop_stop()

    
    def publish(self, context: str, data: str) -> bool:
        if self._state is not ClientCommunicator.STATE_ACTIVE:
            return False

        context = self._format_context(context, True)

        mqtt_info = self.mqtt_client.publish(context, data, MqttClientCommunicator.QOS_AT_MOST_ONCE)

        return mqtt_info.rc == mqtt.MQTT_ERR_SUCCESS

    
    def request(self, context: str, data: str) -> str:
        raise NotImplementedError()

    
    def subscribe(self, context: str, callback):
        if callback == None:
            raise ValueError('The callback argument can\'t be None')

        context = self._format_context(context, False)

        def message_callback(client, userdata, message):
            message_content = message.payload.decode("utf-8")
            
            # Old version of the callback needs 2 arguments
            argcount_min = 2
            # New version of the callback needs 3 arguments (including robot_id)
            argcount_max = 3

            if inspect.ismethod(callback):
                # Methods has one additional parameter 'self', which increses the argcount
                argcount_min = argcount_min + 1
                argcount_max = argcount_max + 1

            # Old version of the callback (with 2 arguments)
            if (callback.__code__.co_argcount == argcount_min):
                callback(message.topic, message_content)

            # New version of the callback (with 3 arguments)
            elif (callback.__code__.co_argcount == argcount_max):
                robot_id = get_robot_id(message.topic)
                callback(message.topic, message_content, robot_id)

            else:
                raise AttributeError(message='The arguments of the callback doesn\'t match the correct signature')

        self.mqtt_client.subscribe(context, MqttClientCommunicator.QOS_AT_MOST_ONCE)
        self.mqtt_client.message_callback_add(context, message_callback)

    
    def unsubscribe(self, context: str):
        context = self._format_context(context, False)

        self.mqtt_client.unsubscribe(context)
        self.mqtt_client.message_callback_remove(context)


    def _on_connect(self, client, userdata, flags, result):
        if result == MqttClientCommunicator.MQTT_RESULT_SUCCESS:
            self._set_state(ClientCommunicator.STATE_ACTIVE)
        else:
            error = None

            if result == MqttClientCommunicator.MQTT_RESULT_BAD_USERNAME_OR_PASS:
                error = CommunicatorError('Could not connect the communicator: "Bad username or password"', self.config.communication_type)
            elif result == MqttClientCommunicator.MQTT_RESULT_INCORRECT_PROTOCOL_VERSION:
                error = CommunicatorError('Could not connect the communicator: "Incorrect MQTT protocol version"', self.config.communication_type)
            elif result == MqttClientCommunicator.MQTT_RESULT_INVALID_CLIENT:
                error = CommunicatorError('Could not connect the communicator: "Invalid MQTT client"', self.config.communication_type)
            elif result == MqttClientCommunicator.MQTT_RESULT_NOT_AUTHORISED:
                error = CommunicatorError('Could not connect the communicator: "Not authorised"', self.config.communication_type)                
            elif result == MqttClientCommunicator.MQTT_RESULT_SERVER_UNAVAILABLE:
                error = CommunicatorError('Could not connect the communicator: "Server Unavailable"', self.config.communication_type)

            self._set_state(ClientCommunicator.STATE_INACTIVE, error)


    def _on_disconnect(self, client, userdata, rc):
        error = None

        if (rc != 0):
            error = CommunicatorError('Unexpected disconnection.', self.config.communication_type)

        self._set_state(ClientCommunicator.STATE_INACTIVE, error)