#!/usr/bin/env python

import time

from communication.client import CommunicationClient


def run():
    def on_message_received(context, data, robot_id):
        print(f'Received message at robot "{robot_id}", context "{context}": {data}')


    print('Starting communication...')
    communication = CommunicationClient()
    communication.start()

    while not communication.is_ready():
        time.sleep(0.2)

    print('Communication is ready to use!')

    context = 'robot/test'

    print(f'Subscribing to "{context}"')
    communication.subscribe(context, on_message_received)

    time.sleep(15)

    print(f'Unsubscribing the context "{context}"')
    communication.unsubscribe(context)

    time.sleep(15)
    communication.stop()
    exit(0)