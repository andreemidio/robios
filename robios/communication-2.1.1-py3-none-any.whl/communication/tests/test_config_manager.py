#!/usr/bin/env python

import communication.config.manager as config_manager

def run():
    print('Loading configuration file...')
    config = config_manager.load_client_config()

    print('Loaded: \n')

    print('Clients:')
    for client in config.clients:
        print(f' - Communication Type: {client.communication_type}')
        print(f' - Server Address: {client.server_address}')
        print(f' - Server Port: {client.server_port}')
        print(f' - Auto Restart: {client.auto_restart}')
        print(f' - Restart Time: {client.restart_time}')
        print(f' - Default Robot ID: {client.default_robot_id}')
        print(f' - Accept any Robot ID: {client.accept_any_robot_id}')

    print('\nPublish Config:')
    print(f' - Default Communicator: {config.publish_config.default_communicator}')
    
