#!/usr/bin/env python

import time

from communication.client import CommunicationClient


def run():
    def on_message_received(context, data):
        print(f'Received message at context "{context}": {data}')


    print('Starting communication...')
    communication = CommunicationClient()
    communication.start()

    while not communication.is_ready():
        time.sleep(0.2)

    print('Communication is ready to use!')

    context = 'robot/test'
    message = 'Message Test {}'
    interval = 1
    count = 30

    for i in range(0, 30):
        data = str.format(message, i)
        print(f'Publishing to "{context}": {data}')
        published = communication.publish(context, data)
        print(f'Message published? {published}')
        time.sleep(interval)

    communication.stop()
    exit(0)