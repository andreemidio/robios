#!/usr/bin/env python

import time
from communication.clients.mqtt import MqttClientCommunicator

client_state = MqttClientCommunicator.STATE_INACTIVE
state_changed = False

def run():
    global client_state
    global state_changed

    print('Starting MQTT Communicator')
    client = MqttClientCommunicator(None, on_state_changed)
    client.start()

    is_active = False
    while (is_active == False):
        time.sleep(0.1)

        if (client_state == MqttClientCommunicator.STATE_ACTIVE):
            is_active = True


    context_subscribe_1 = 'robot/subscribe/test1'
    print(f'Subscribing to the context "{context_subscribe_1}"')
    client.subscribe(context_subscribe_1, on_subscribe_received)

    context_subscribe_2 = 'robot/subscribe/test2'
    print(f'Subscribing to the context "{context_subscribe_2}"')
    client.subscribe(context_subscribe_2, on_subscribe_received)

    counter = 0
    context_publish = 'robot/publish/test1'

    while (counter <= 20):
        counter = counter + 1
        print(f'Publishing data at context "{context_publish}"')
        published = client.publish(context_publish, f'Hello World from Communicator {counter}')

        if published:
            print('Published successfully!')
        else:
            print('The message has not been published')

        if counter == 10:
            print(f'Unsubscribing the context "{context_subscribe_1}"')
            client.unsubscribe(context_subscribe_1)

        time.sleep(1)

    print('Stopping MQTT Communicator')
    client.stop()

    time.sleep(3)

    print('Starting again!')
    client.start()

    counter = 0
    # context_publish = 'robot/publish/test1'

    while (counter <= 20):
        counter = counter + 1
        print(f'Publishing data at context "{context_publish}"')
        published = client.publish(context_publish, f'Hello World from Communicator {counter}')

        if published:
            print('Published successfully!')
        else:
            print('The message has not been published')

        if counter == 10:
            print(f'Unsubscribing the context "{context_subscribe_1}"')
            client.unsubscribe(context_subscribe_1)

        time.sleep(1)




def on_state_changed(state, client_id, communication_type, error):
    global client_state
    global state_changed

    print(f'MQTT Communicator State Changed: {state}')

    client_state = state
    state_changed = True


def on_subscribe_received(context, data):
    print(f'Received message at context "{context}": {data}')

