#!/usr/bin/env python

import time
from communication.clients.mqtt import MqttClientCommunicator
from communication.routines.communicator_restart import CommunicatorRestartRoutine

def on_state_changed(state, client_id, communication_type, error):
    if state == MqttClientCommunicator.STATE_ACTIVE:
        print(f'{client_id}: State changed to {state} (ACTIVE)')
    elif state == MqttClientCommunicator.STATE_INACTIVE:
        print(f'{client_id}: State changed to {state} (INACTIVE)')
    elif state == MqttClientCommunicator.STATE_STARTING:
        print(f'{client_id}: State changed to {state} (STARTING)')
    elif state == MqttClientCommunicator.STATE_STOPPING:
        print(f'{client_id}: State changed to {state} (STOPPING)')


def run():
    communicator = MqttClientCommunicator(state_callback=on_state_changed)
    restart_routine = CommunicatorRestartRoutine(communicator)

    print('Starting Communicator.')
    communicator.start()

    print('Starting Communicator Restart Routine')
    restart_routine.start()

    while True:
        if communicator.get_state() is not MqttClientCommunicator.STATE_ACTIVE:
            time.sleep(0.1)
        else:
            time.sleep(5)
            print('Forcing communicator to stop')
            communicator.stop()
