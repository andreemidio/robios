#!/usr/bin/env python

from communication.utils.context import *

def run():
    context = 'robot/robios1/test'

    print(f'Removing format from "{context}"')
    context_no_id = remove_format(context)
    print(f'Result: {context_no_id}')

    print(f'Getting robot ID from context "{context}"')
    robot_id = get_robot_id(context)
    print(f'Result: {robot_id}')