
import time
from communication.clients.mqtt import MqttClientCommunicator

def _state_callback(state):
    if state == MqttClientCommunicator.STATE_ACTIVE:
        print(f'STATE CHANGED TO {state} (ACTIVE)')
    elif state == MqttClientCommunicator.STATE_INACTIVE:
        print(f'STATE CHANGED TO {state} (INACTIVE)')
    elif state == MqttClientCommunicator.STATE_STARTING:
        print(f'STATE CHANGED TO {state} (STARTING)')
    elif state == MqttClientCommunicator.STATE_STOPPING:
        print(f'STATE CHANGED TO {state} (STOPPING)')


def run():
    client = MqttClientCommunicator()
    client.state_callback = _state_callback

    client.start()

    while True:
        time.sleep(0.3)