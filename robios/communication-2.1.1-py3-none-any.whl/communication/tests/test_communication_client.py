#!/usr/bin/env python

import time

from communication.constants import COMMUNICATION_MQTT
from communication.client import CommunicationClient
from communication.communicator import ClientCommunicator

def run():
    print('Starting Communication Client')
    client = CommunicationClient(communicator_state_callback=on_communicator_state_changed)
    client.start()

    # Waiting for the mqtt client to connect
    while (not client.is_ready()):
        time.sleep(0.1)

    print('Communication Client is ready to use.')

    context_sub1 = 'robot/subscribe/test1'
    print(f'Subscribing to the context "{context_sub1}"')
    client.subscribe(context_sub1, on_received_message)

    context_sub2 = 'robot/subscribe/test2'
    print(f'Subscribing to the context "{context_sub2}"')
    client.subscribe(context_sub2, on_received_message)

    counter = 1
    context_pub = 'robot/publish/test1'
    forced_stop = False
    while (counter <= 20):
        if client.publish(context_pub, f'Hello World from Communication Client {counter}'):
            print(f'Published data at context "{context_pub}"')
        else:
            print('Could not publish the data')

        if counter == 10:
            print(f'Unsubscribing the context "{context_pub}"')
            client.unsubscribe(context_sub1)

            if forced_stop == False:
                forced_stop = True
                print('Forcing communicator to stop (TO TEST THE RESTART ROUTINE)')
                client._communicators[client.config.clients[0].id].stop()

        counter = counter + 1
        time.sleep(1)

    print('Closing communication client')
    client.stop()

    print('Bye bye!')


def on_received_message(context, data):
    print(f'Received message at context "{context}": {data}')

def on_communicator_state_changed(client_id, state):
    print(f'{client_id}: State Changed to: {state}')