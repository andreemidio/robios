#!/usr/bin/env python

import time

from communication.config.models import ClientConfig, CommunicationClientConfig
from communication.client import CommunicationClient

def run():
    def on_state_changed(client_id, state, error):
        print(f'MQTT Communicator State Changed ({client_id}): {state}')


    client_01 = ClientConfig.mqtt_default_config()
    client_01.id = "client_01"

    client_02 = ClientConfig.mqtt_default_config()
    client_02.id = "client_02"

    client_03 = ClientConfig.mqtt_default_config()
    client_03.id = "client_03"

    client_04 = ClientConfig.mqtt_default_config()
    client_04.id = "client_04"

    config = CommunicationClientConfig.get_default()
    config.clients = [client_01, client_02, client_03, client_04]

    communication = CommunicationClient(config, on_state_changed)
    # communication.state_callback = on_state_changed
    communication.start()

    while not communication.is_ready():
        time.sleep(0.1)

    context = 'robot/publish/test'
    print('Publishing to multiple clients...')

    for i in range(1, 21):
        print(f'Broadcasting message to all clients')
        published = communication.broadcast(context, f'Hello {i}')
        time.sleep(1)

    communication.stop()
    exit(0)