#!/usr/bin/env python

import time
import threading

from communication.communicator import ClientCommunicator

class CommunicatorRestartRoutine(object):
    LOOP_INTERVAL = 0.2

    def __init__(self, communicator: ClientCommunicator, restart_time=5):
        self._communicator = communicator
        self._restart_time = restart_time

        self._check_thread = threading.Thread(target=self._run, name='CommunicatorRestartRoutine', daemon=True)

        # FLAGS
        self._running = False
        self._state_changed = False
        
    
    def _run(self):
        self._running = True

        lastLoopTime = time.time()
        timer = 0

        while self._running == True:
            currentTime = time.time()
            delta_time = currentTime - lastLoopTime

            if self._state_changed == True:
                timer = 0
                self._state_changed = False
            
            else:
                # If the state stays as INACTIVE for some time,
                # try to start the communciation again
                if self._communicator.get_state() == ClientCommunicator.STATE_INACTIVE:
                    timer = timer + delta_time

                    if timer >= self._restart_time:
                        self._communicator.start()

                
            # Update the time of the loop
            lastLoopTime = currentTime
            time.sleep(CommunicatorRestartRoutine.LOOP_INTERVAL)


    def start(self):
        self._communicator.add_state_callback(self._on_state_changed)

        if self._check_thread.is_alive():
            return
        else:
            self._check_thread = threading.Thread(target=self._run, name='CommunicatorRestartRoutine', daemon=True)

        self._check_thread.start()


    def stop(self):
        self._running = False
        self._communicator.remove_state_callback(self._on_state_changed)


    def _on_state_changed(self, state, client_id, communication_type, error):
        self._state_changed = True