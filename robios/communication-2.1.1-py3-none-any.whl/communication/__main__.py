#!/usr/bin/env python

import communication.tests.test_mqtt_communicator as test_mqtt
import communication.tests.test_mqtt_communicator_states as test_mqtt_states
import communication.tests.test_config_manager as test_config
import communication.tests.test_communication_client as test_client
import communication.tests.test_communicator_restart_routine as test_restart_routine
import communication.tests.test_publish_many_clients as test_publish_many
import communication.tests.test_broadcast as test_broadcast
import communication.tests.test_subscribe as test_subscribe
import communication.tests.test_publish as test_publish
import communication.tests.test_context_utils as test_context_utils

if __name__ == '__main__':
    # test_mqtt.run()
    # test_mqtt_states.run()
    # test_config.run()
    # test_client.run()
    # test_restart_routine.run()
    # test_publish_many.run()
    # test_broadcast.run()
    test_subscribe.run()
    # test_publish.run()
    # test_context_utils.run()
    
    pass