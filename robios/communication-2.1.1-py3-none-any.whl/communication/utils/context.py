#!/usr/bin/env python


def remove_format(context: str) -> str:
    """
    Clear the format of the context.

    Clearing the context's format consist in remove the robot ID from
    the context string, which is placed at the second topic level 
    (between the first and second "/").

    Parameters
    --------------
    context : str
        Is the context string to be manipulated.

    Returns
    --------------
    A new context string without the formatting.

    """
    x = context.index('/')
    y = context.index('/', x+1)

    return context[:x+1] + context[y+1:]


def get_robot_id(context: str) -> str:
    """
    Gets the robot's ID from the context string.

    Parameters
    ---------------
    context : str Is the context string to get the robot ID from.

    Returns
    ---------------
    The robot ID in the given context string or an empty string
    if no ID is present.
    """
    x = context.index('/')
    y = context.index('/', x+1)

    return context[x+1: y]