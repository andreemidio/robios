import logging

class Log():
    _is_log_debug: bool = False
    _is_log_info: bool = True
    _is_log_error: bool = True
    _is_log_warning: bool = True

    def __init__(self):
        logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


    def info(message: str):
        if Log._is_log_info == True:
            logging.info(message)


    def debug(message: str):
        if Log._is_log_debug == True:
            logging.debug(message)


    def warn(message: str):
        if Log._is_log_warning == True:
            logging.warning(message)


    def error(message: str):
        if Log._is_log_error == True:
            logging.error(message)
        