#!/usr/bin/env python

import time

from communication.config.models import *

from robios.interface import Robios
from robios.impl.communication import RobiosCommunication
from robios.config import RobiosConfig
from robios.errors import RobiosError, RobiosInvalidAPIKeyError

TIMEOUT = 10.0

def get(api_key: str, robot_address: str=None, config: RobiosConfig=None) -> Robios:
    communicator_id = 'api_client'

    if config == None:
        config = RobiosConfig()

        if robot_address is not None:
            config.robot_address = robot_address


    client_config = ClientConfig.mqtt_default_config()
    client_config.id = communicator_id
    client_config.server_address = config.robot_address
    client_config.server_port = config.robot_port
    client_config.communication_type = config.communication_source
    client_config.accept_any_robot_id = True

    if config.robot_id is not None:
        communicator_id = config.robot_id
        client_config.id = config.robot_id
        client_config.default_robot_id = config.robot_id

    communication_config = CommunicationClientConfig.get_default()
    communication_config.clients = [client_config]
    communication_config.publish_config.default_communicator = communicator_id

    robios: Robios = RobiosCommunication(communication_config)
    
    timeout_counter = 0.0

    while not robios.is_connected():
        time.sleep(0.2)

        timeout_counter = timeout_counter + 0.2

        if timeout_counter > TIMEOUT:
            raise RobiosError('Failed to connect the API. Timeout...')

    return robios