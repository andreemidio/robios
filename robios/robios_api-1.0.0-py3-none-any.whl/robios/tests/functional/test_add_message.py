import unittest

from robios import api
from robios.interface import Robios
from robios.config import RobiosConfig

class TestSay(unittest.TestCase):
    def setUp(self):
        config = RobiosConfig(
            robot_address='robots.humanrobotics.ai',
            robot_id='0db0572a-1e46-44a1-a459-16a94c67f6c2'
        )
        self.robios = api.get('a7ec43fe-0922-46ad-bb10-91599e6a131f', config=config)


    def tearDown(self):
        self.robios.close()


    def on_receive_message(self, context, data):
        print(f'Receive message at context "{context}": {data}')


    def test_say(self):
        self.robios.add_message_callback('robot/speak/callback', self.on_receive_message)
        self.robios.delay(30000)
        self.robios.remove_message_callback('robot/speak/callback', self.on_receive_message)
        self.assertTrue(True)
        