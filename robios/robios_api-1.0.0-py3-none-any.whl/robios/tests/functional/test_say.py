import unittest

from robios import api
from robios.interface import Robios

class TestSay(unittest.TestCase):
    def setUp(self):
        ip = '127.0.0.1'
        self.robios = api.get('a7ec43fe-0922-46ad-bb10-91599e6a131f', ip)


    def tearDown(self):
        self.robios.close()


    def test_say(self):
        self.robios.say('Hello World')
        self.assertTrue(True)
        