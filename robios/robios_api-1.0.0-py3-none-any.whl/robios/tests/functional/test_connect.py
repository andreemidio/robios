import unittest

from robios import api
from robios.interface import Robios

class TestConnect(unittest.TestCase):

    def test_connect_at_localhost(self):
        ip = '127.0.0.1'
    
        try: 
            robios = api.get('a7ec43fe-0922-46ad-bb10-91599e6a131f', ip)
        except:
            robios = None
            
        
        self.assertIsNotNone(robios, 'API has not been properly connected.')
        