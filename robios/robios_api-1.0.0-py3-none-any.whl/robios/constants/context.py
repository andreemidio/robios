#!/usr/bin/env python

EXPRESSION = 'robot/expression'
SCRIPT = 'robot/script'
SCRIPT_CALLBACK = 'robot/script/callback'
SPEAK = 'robot/speak'
SPEAK_CALLBACK = 'robot/speak/callback'
SPEAK_WITH_ID = 'robot/speak/with_id'
TELEMETRY = 'robot/telemetry'

class Api:
    REQUEST_VALIDATION = 'robot/api/request/key_validation'
    RESPONSE_VALIDATION = 'robot/api/response/key_validation'

class Core:
    SET_BEHAVIOUR = 'robot/core/set/behaviour'
    INPUT_CONFIG = 'robot/core/input/commands'


class DialogEngine:
    SET_ENABLED = 'robot/dialog_engine/set/enabled'


class Head:
    ALERT_DIALOG = 'robot/alert_dialog'
    ALERT_DIALOG_RESULT = 'robot/alert_dialog/result'
    EXECUTE = 'robot/head/execute'


class Move:
    BY_FORCE = 'robot/move/force'
    BY_SPEED = 'robot/move/speed'
    BY_TWIST = 'robot/move/twist'
    CENTER_HEAD = 'robot/move/head/center'
    HEAD = 'robot/move/head'


class Navigation:
    CANCEL = 'robot/navigation/cancel'
    GOAL_STATUS = 'robot/navigation/goal/status'
    GOTO_CHECKPOINT = 'robot/navigation/go_to/checkpoint'
    GOTO_POINT = 'robot/navigation/go_to/point'
    RESET_ODOMETRY = 'robot/navigation/reset_odometry'
    SET_CHECKPOINT = 'robot/navigation/set/checkpoint'


class Vision:
    DETECTED_OBJECTS = 'robot/vision/detected_objects'
    STATUS = 'robot/vision/status'
    INPUT_COMMMANDS = 'robot/vision/input/commands'
    OUTPUT_COMMMANDS = 'robot/vision/output/commands'


class Voice:
    COMMANDS = 'robot/asr/commands'
    STATUS = 'robot/asr/status'
    USER_TEXT = 'robot/asr/user_text'