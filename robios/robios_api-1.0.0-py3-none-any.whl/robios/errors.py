class RobiosConfigError(Exception):
    pass


class RobiosError(Exception):
    pass


class RobiosInvalidAPIKeyError(Exception):
    pass