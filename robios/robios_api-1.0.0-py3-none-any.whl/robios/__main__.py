import unittest

from robios.tests.functional.test_connect import TestConnect
from robios.tests.functional.test_say import TestSay

if __name__ == '__main__':
    unittest.main(verbosity=2)