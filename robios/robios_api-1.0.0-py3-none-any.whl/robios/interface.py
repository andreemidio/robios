#!/usr/bin/env python

import time

from robios.log import Log

class Robios:
    def __init__(self):
        super().__init__()

        self._ext = None
        self._navigation = None

        self._face_detection_callbacks: list = []
        self._navigation_cancel_callbacks: list = []
        self._navigation_goto_point_callbacks: list = []
        self._navigation_reset_ododmetry_callbacks: list = []
        self._navigation_goal_status_callbacks: list = []
        self._script_start_callbacks: list = []
        self._script_end_callbacks: list = []
        self._script_pause_callbacks: list = []
        self._script_resume_callbacks: list = []
        self._script_command_executed_callbacks: list = []
        self._telemetry_callbacks: list = []
        self._voice_recognition_callbacks: list = []
        self._dialog_callbacks: list = []
        self._alert_dialog_callbacks: list = []
        self._speak_callbacks: list = []
        self._message_callbacks = {}

        self.behavior_names = [
            'autonomous',
            'entertainement',
        ]

        self.face_expressions = [
            'normal',
            'happy',
            'sad',
            'afraid',
            'scared',
            'hangry'
        ]

        self.head_app_ids = [
            'camera',
            'command_game',
            'feedback',
            'log_viewer',
            'menu',
            'product_reader',
            'settings',
            'game_change_voice'
        ]

        self.head_commands = [
            'swipe_face_left',
            'swipe_face_right',
            'set_background_next',
            'set_background_previous',
            'set_mask_next',
            'set_mask_previous',
            'statusbar_show'
        ]


    def add_face_detection_callback(self, callback) -> 'Robios':
        self._face_detection_callbacks.append(callback)
        return self

    
    def remove_face_detection_callback(self, callback) -> 'Robios':
        self._face_detection_callbacks.remove(callback)
        return self


    def add_navigation_cancel_callback(self, callback) -> 'Robios':
        self._navigation_cancel_callbacks.append(callback)
        return self


    def remove_navigation_cancel_callback(self, callback) -> 'Robios':
        self._navigation_cancel_callbacks.remove(callback)
        return self


    def add_navigation_goto_point_callback(self, callback) -> 'Robios':
        self._navigation_goto_point_callbacks.append(callback)
        return self


    def remove_navigation_goto_point_callback(self, callback) -> 'Robios':
        self._navigation_goto_point_callbacks.remove(callback)
        return self


    def add_navigation_reset_odometry_callback(self, callback) -> 'Robios':
        self._navigation_reset_ododmetry_callbacks.append(callback)
        return self


    def remove_navigation_reset_odometry_callback(self, callback) -> 'Robios':
        self._navigation_reset_ododmetry_callbacks.remove(callback)
        return self


    def add_navigation_goal_status_callback(self, callback) -> 'Robios':
        self._navigation_goal_status_callbacks.append(callback)
        return self


    def remove_navigation_goal_status_callback(self, callback) -> 'Robios':
        self._navigation_goal_status_callbacks.remove(callback)
        return self


    def add_script_start_callback(self, callback) -> 'Robios':
        self._script_start_callbacks.append(callback)
        return self


    def remove_script_start_callback(self, callback) -> 'Robios':
        self._script_start_callbacks.remove(callback)
        return self

    
    def add_script_end_callback(self, callback) -> 'Robios':
        self._script_end_callbacks.append(callback)
        return self


    def remove_script_end_callback(self, callback) -> 'Robios':
        self._script_end_callbacks.remove(callback)
        return self

    
    def add_script_pause_callback(self, callback) -> 'Robios':
        self._script_pause_callbacks.append(callback)
        return self


    def remove_script_pause_callback(self, callback) -> 'Robios':
        self._script_pause_callbacks.remove(callback)
        return self


    def add_script_resume_callback(self, callback) -> 'Robios':
        self._script_resume_callbacks.append(callback)
        return self


    def remove_script_resume_callback(self, callback) -> 'Robios':
        self._script_resume_callbacks.remove(callback)
        return self


    def add_script_command_executed_callback(self, callback) -> 'Robios':
        self._script_command_executed_callbacks.append(callback)
        return self


    def remove_script_command_executed_callback(self, callback) -> 'Robios':
        self._script_command_executed_callbacks.remove(callback)
        return self


    def add_telemetry_callback(self, callback) -> 'Robios':
        self._telemetry_callbacks.append(callback)
        return self


    def remove_telemetry_callback(self, callback) -> 'Robios':
        self._telemetry_callbacks.remove(callback)
        return self

    
    def add_voice_recognition_callback(self, callback) -> 'Robios':
        self._voice_recognition_callbacks.append(callback)
        return self


    def remove_voice_recognition_callback(self, callback) -> 'Robios':
        self._voice_recognition_callbacks.remove(callback)
        return self


    def add_alert_dialog_callback(self, callback) -> 'Robios':
        self._alert_dialog_callbacks.append(callback)
        return self


    def remove_alert_dialog_callback(self, callback) -> 'Robios':
        self._alert_dialog_callbacks.remove(callback)
        return self


    def add_speak_callback(self, callback) -> 'Robios':
        self._speak_callbacks.append(callback)
        return self


    def remove_speak_callback(self, callback) -> 'Robios':
        self._speak_callbacks.remove(callback)
        return self


    def add_message_callback(self, context: str, callback) -> 'Robios':
        callbacks = self._message_callbacks.get(context)
        
        if callbacks is None:
            self._message_callbacks[context] = [callback]
        else:
            self._message_callbacks[context].append(callback)

        return self


    def remove_message_callback(self, context: str, callback) -> 'Robios':
        context_callbacks = self._message_callbacks.get(context)

        if context_callbacks is None:
            return self

        self._message_callbacks[context].remove(callback)
        return self
        

    def say(self, text: str) -> 'Robios':
        raise NotImplementedError


    def set_expression(self, expression: str) -> 'Robios': 
        raise NotImplementedError


    def move_head(self, horizontal_degrees: int, vertical_degrees) -> 'Robios':
        raise NotImplementedError


    def center_head(self) -> 'Robios':
        raise NotImplementedError


    def move(self, linear_speed: float, angular_speed: float) -> 'Robios':
        raise NotImplementedError


    def execute_script(self, script: str) -> 'Robios':
        raise NotImplementedError


    def pause_script(self) -> 'Robios':
        raise NotImplementedError


    def resume_script(self) -> 'Robios':
        raise NotImplementedError


    def stop_script(self) -> 'Robios':
        raise NotImplementedError


    def clear_scripts(self, force_stop: bool) -> 'Robios':
        raise NotImplementedError


    def execute_app_on_head(self, app_id: str) -> 'Robios':
        raise NotImplementedError


    def execute_command_on_head(self, command_id: str) -> 'Robios':
        raise NotImplementedError


    def stop_after(self, time_to_stop: int) -> 'Robios':
        raise NotImplementedError


    def delay(self, milliseconds: int) -> 'Robios':
        time.sleep(milliseconds/1000)
        return self


    def stop(self) -> 'Robios':
        raise NotImplementedError


    def set_behavior(self, behavior_name: str) -> 'Robios':
        raise NotImplementedError


    def led(self, front: int, left: int, back: int, right: int) -> 'Robios':
        raise NotImplementedError


    def simulate_user_speaking(self, text: str) -> 'Robios':
        raise NotImplementedError


    def display_image(self, img_url: str, display_time: int) -> 'Robios':
        raise NotImplementedError


    def display_video(self, video_url: str, display_time: int, audio_enabled: bool, loop: bool) -> 'Robios':
        raise NotImplementedError


    def ask(self, question: str) -> 'Robios':
        raise NotImplementedError


    def listen(self) -> 'Robios':
        raise NotImplementedError


    def use_native_dialogs(self, enabled: bool) -> 'Robios':
        raise NotImplementedError


    def is_connected(self) -> bool:
        raise NotImplementedError


    def validate_api_key(self, key: str) -> bool:
        raise NotImplementedError


    def close(self):
        raise NotImplementedError


    def ext(self) -> 'RobiosExt':
        raise NotImplementedError

    
    def navigation(self) -> 'RobiosNavigation':
        raise NotImplementedError


class RobiosExt:
    def __init__(self):
        super().__init__()


    def set_log_info_enabled(self, enabled: bool):
        Log._is_log_info = enabled


    def set_log_debug_enabled(self, enabled: bool):
        Log._is_log_debug = enabled


    def set_log_error_enabled(self, enabled: bool):
        Log._is_log_error = enabled


    def set_log_warn_enabled(self, enabled: bool):
        Log._is_log_warning = enabled


    def set_all_logs_enabled(self, enabled: bool):
        Log._is_log_info = enabled
        Log._is_log_debug = enabled
        Log._is_log_error = enabled
        Log._is_log_warning = enabled


    def move_by_force(self, left_wheel_force: int, right_wheel_force: int, interval: int = None) -> 'RobiosExt':
        raise NotImplementedError


    def move_by_speed(self, left_wheel_speed: float, right_wheel_speed: float) -> 'RobiosExt':
        raise NotImplementedError


    def send_message(self, context: str, message: str) -> 'RobiosExt':
        raise NotImplementedError


class RobiosNavigation:
    def __init__(self):
        super().__init__()

    
    def cancel(self) -> 'RobiosNavigation':
        raise NotImplementedError


    def go_to_point(self, x: float, y: float, z: float, orientation: int) -> 'RobiosNavigation':
        raise NotImplementedError
    

    def go_to_checkpoint(self, checkpoint: str) -> 'RobiosNavigation':
        raise NotImplementedError


    def reset_odometry(self) -> 'RobiosNavigation':
        raise NotImplementedError


    def set_checkpoint(self, world: str, checkpoint: str, description: str, point_x: float, point_y: float, point_z: float, point_orientation: int) -> 'RobiosNavigation':
        raise NotImplementedError