#!/usr/bin/env python

import time

from communication.client import CommunicationClient
from communication.errors import CommunicatorError
from communication.config.models import CommunicationClientConfig
from communication.utils import context as context_utils

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.AlertDialog import AlertDialog
from messaging.types.AlertDialogResult import AlertDialogResult
from messaging.types.BooleanWithHeader import BooleanWithHeader
from messaging.types.Checkpoint import Checkpoint
from messaging.types.IntWithHeader import IntWithHeader
from messaging.types.DetectedObjectArray import DetectedObjectArray
from messaging.types.GoToCheckpoint import GoToCheckpoint
from messaging.types.GoToPoint import GoToPoint
from messaging.types.SpeakCallback import SpeakCallback
from messaging.types.StringWithHeader import StringWithHeader
from messaging.types.SpeakMessage import SpeakMessage
from messaging.types.ScriptCallback import ScriptCallback
from messaging.types.MoveHead import MoveHead
from messaging.types.MoveByTwist import MoveByTwist
from messaging.types.MoveByForce import MoveByForce
from messaging.types.MoveBySpeed import MoveBySpeed
from messaging.types.NavigationPoint import NavigationPoint
from messaging.types.Script import Script
from messaging.types.ExecuteOnHead import ExecuteOnHead
from messaging.types.Telemetry import Telemetry
from messaging.types.Vector3 import Vector3

from robios.interface import Robios, RobiosExt, RobiosNavigation
from robios.errors import RobiosConfigError, RobiosError
from robios.constants import context

class RobiosCommunication(Robios):

    def __init__(self, config: CommunicationClientConfig=None):
        super().__init__()

        self.client: CommunicationClient = None

        if config == None:
            config = CommunicationClientConfig.get_default()

        try:
            self.client = CommunicationClient(config)
            self.client.start()
        except (IOError):
            raise RobiosConfigError('Failed to load Communication configuration file.')
        except (CommunicatorError):
            raise RobiosError('Failed to start the API instance. Could not connect with the robot')

        self._ext: RobiosExt = RobiosCommunicationExt(self)
        self._navigation: RobiosNavigation = RobiosCommunicationNavigation(self)

        self._api_key: str = None
        self._key_valid = False
        self._key_checked = False
        self._script_callback_subscribed = False


    def say(self, text: str) -> Robios:
        message = SpeakMessage(text=text)
        message.context = context.SPEAK_WITH_ID

        self._publish(message)

        return self

    
    def set_expression(self, expression):
        message = StringWithHeader()
        message.data = expression
        message.context = context.EXPRESSION

        self._publish(message)

        return self

    
    def move_head(self, horizontal_degrees, vertical_degrees):
        message = MoveHead(horizontal_degrees, vertical_degrees)
        message.context = context.Move.HEAD

        self._publish(message)

        return self


    def center_head(self):
        message = StringWithHeader()
        message.context = context.Move.CENTER_HEAD

        self._publish(message)

        return self


    def move(self, linear_speed, angular_speed):
        message = MoveByTwist(linear_speed, angular_speed)
        message.context = context.Move.BY_TWIST

        self._publish(message)

        return self


    def execute_script(self, script):
        message = Script(Script.ACTION_ADD, script)
        message.context = context.SCRIPT

        self._publish(message)

        return self


    def pause_script(self):
        message = Script(Script.ACTION_PAUSE)
        message.context = context.SCRIPT

        self._publish(message)

        return self


    def stop_script(self):
        message = Script(Script.ACTION_STOP)
        message.context = context.SCRIPT

        self._publish(message)

        return self
    
        
    def clear_scripts(self, force_stop):
        message = Script(Script.ACTION_CLEAR, str(force_stop))
        message.context = context.SCRIPT

        self._publish(message)

        return self


    def execute_app_on_head(self, app_id):
        message = ExecuteOnHead(ExecuteOnHead.TYPE_INTERNAL_APP, app_id)
        message.context = context.Head.EXECUTE

        self._publish(message)

        return self


    def execute_command_on_head(self, command_id):
        message = ExecuteOnHead(ExecuteOnHead.TYPE_COMMAND, command_id)
        message.context = context.Head.EXECUTE

        self._publish(message)

        return self
    

    def stop(self):
        message = MoveByForce(0, 0)
        message.context = context.Move.BY_FORCE

        self._publish(message)

        return self


    def set_behavior(self, behavior_name):
        message = StringWithHeader()
        message.data = behavior_name
        message.context = context.Core.SET_BEHAVIOUR

        self._publish(message)

        return self

    
    def simulate_user_speaking(self, text):
        message = StringWithHeader()
        message.data = text
        message.context = context.Voice.USER_TEXT

        self._publish(message)

        return self


    def display_image(self, img_url, display_time):
        message = AlertDialog('Image')
        message.dialog_type = AlertDialog.TYPE_INFO
        message.media_type = AlertDialog.MEDIA_TYPE_IMAGE
        message.media_url = img_url
        message.timeout = display_time
        message.speak_title = False
        message.speak_description = False
        message.display_title = False
        message.display_description = False
        message.context = context.Head.ALERT_DIALOG

        self._publish(message)

        return self


    def display_video(self, video_url, display_time, audio_enabled, loop):
        message = AlertDialog('Video')
        message.dialog_type = AlertDialog.TYPE_INFO
        message.media_type = AlertDialog.MEDIA_TYPE_VIDEO
        message.media_url = video_url
        message.media_audio_enabled = audio_enabled
        message.media_loop = loop
        message.timeout = display_time
        message.speak_title = False
        message.speak_description = False
        message.display_title = False
        message.display_description = False
        message.context = context.Head.ALERT_DIALOG

        self._publish(message)

        return self


    def ask(self, question):
        self.say(question)
        self.delay(500)
        self.listen()

        return self

    
    def listen(self):
        message = StringWithHeader()
        message.data = 'trigger_asr'
        message.context = context.Voice.COMMANDS

        self._publish(message)

        return self


    def use_native_dialogs(self, enabled):
        message = BooleanWithHeader()
        message.data = enabled
        message.context = context.DialogEngine.SET_ENABLED

        self._publish(message)

        return self


    def is_connected(self):
        return self.client.is_ready()

    
    def validate_api_key(self, key):
        self._api_key = key
        self._key_valid = False

        def on_response(context, data):
            message: StringWithHeader = StringWithHeader.decode(data)
            items = message.data.split('+')

            token = items[0]

            if token == self._api_key:
                self._key_valid = items[1].lower() == 'true'
                self._key_checked = True

        self.client.subscribe(context.Api.RESPONSE_VALIDATION, on_response)

        message = StringWithHeader()
        message.data = key
        message.context = context.Api.REQUEST_VALIDATION

        self._publish(message)

        timeoutCounter = 0.0
        while self._key_checked == False:
            time.sleep(0.2)
            timeoutCounter = timeoutCounter + 0.2

            if timeoutCounter >= 10:
                break

        return self._key_valid


    def close(self):
        self.client.stop()


    def ext(self):
        return self._ext

    
    def navigation(self):
        return self._navigation


    def add_alert_dialog_callback(self, callback):
        super().add_alert_dialog_callback(callback)

        self.client.subscribe(context.Head.ALERT_DIALOG_RESULT, self._on_alert_dialog_result)

        return self


    def remove_alert_dialog_callback(self, callback):
        super().remove_alert_dialog_callback(callback)

        if len(self._alert_dialog_callbacks) == 0:
            self.client.unsubscribe(context.Head.ALERT_DIALOG_RESULT)

        return self


    def add_face_detection_callback(self, callback):
        super().add_face_detection_callback(callback)
        
        self.client.subscribe(context.Vision.DETECTED_OBJECTS, self._on_face_detection)

        return self

    
    def remove_face_detection_callback(self, callback):
        super().remove_face_detection_callback(callback)

        if len(self._face_detection_callbacks) == 0:
            self.client.unsubscribe(context.Vision.DETECTED_OBJECTS)

        return self


    def add_navigation_cancel_callback(self, callback):
        super().add_navigation_cancel_callback(callback)

        self.client.subscribe(context.Navigation.CANCEL, self._on_navigation_cancel)

        return self


    def remove_navigation_cancel_callback(self, callback):
        super().remove_navigation_cancel_callback(callback)

        if len(self._navigation_cancel_callbacks) == 0:
            self.client.unsubscribe(context.Navigation.CANCEL)

        return self


    def add_navigation_goal_status_callback(self, callback):
        super().add_navigation_goal_status_callback(callback)

        self.client.subscribe(context.Navigation.GOAL_STATUS, self._on_navigation_goal_status)

        return self


    def remove_navigation_goal_status_callback(self, callback):
        super().remove_navigation_goal_status_callback(callback)

        if len(self._navigation_goal_status_callbacks) == 0:
            self.client.unsubscribe(context.Navigation.GOAL_STATUS)

        return self


    def add_navigation_goto_point_callback(self, callback):
        super().add_navigation_goto_point_callback(callback)

        self.client.subscribe(context.Navigation.GOTO_POINT, self._on_navigation_goto_point)

        return self


    def remove_navigation_goto_point_callback(self, callback):
        super().remove_navigation_goto_point_callback(callback)

        if len(self._navigation_goto_point_callbacks) == 0:
            self.client.unsubscribe(context.Navigation.GOTO_POINT)


    def add_navigation_reset_odometry_callback(self, callback):
        super().add_navigation_reset_odometry_callback(callback)

        self.client.subscribe(context.Navigation.RESET_ODOMETRY, self._on_navigation_reset_odometry)

        return self


    def remove_navigation_reset_odometry_callback(self, callback):
        super().remove_navigation_reset_odometry_callback(callback)

        if len(self._navigation_reset_ododmetry_callbacks) == 0:
            self.client.unsubscribe(context.Navigation.RESET_ODOMETRY)

        return self


    def _subscribe_script_callback(self):
        if self._script_callback_subscribed:
            return

        self.client.subscribe(context.SCRIPT_CALLBACK, self._on_script_callback)
        self._script_callback_subscribed = True


    def _unsubscribe_script_callback(self):
        if not self._script_callback_subscribed:
            return 

        if len(self._script_start_callbacks) == 0 and \
            len(self._script_end_callbacks) == 0 and \
            len(self._script_pause_callbacks) == 0 and \
            len(self._script_resume_callbacks) == 0 and \
            len(self._script_command_executed_callbacks) == 0:
            
            self.client.unsubscribe(context.SCRIPT_CALLBACK)
            self._script_callback_subscribed = False
            

    def add_script_start_callback(self, callback) -> 'Robios':
        super().add_script_start_callback(callback)

        self._subscribe_script_callback()

        return self


    def remove_script_start_callback(self, callback) -> 'Robios':
        super().remove_script_start_callback(callback)

        self._unsubscribe_script_callback()

        return self

    
    def add_script_end_callback(self, callback) -> 'Robios':
        super().add_script_end_callback(callback)

        self._subscribe_script_callback()

        return self


    def remove_script_end_callback(self, callback) -> 'Robios':
        super().remove_script_end_callback(callback)

        self._unsubscribe_script_callback()
        
        return self

    
    def add_script_pause_callback(self, callback) -> 'Robios':
        super().add_script_pause_callback(callback)

        self._subscribe_script_callback()

        return self


    def remove_script_pause_callback(self, callback) -> 'Robios':
        super().remove_script_pause_callback(callback)

        self._unsubscribe_script_callback()

        return self


    def add_script_resume_callback(self, callback) -> 'Robios':
        super().add_script_resume_callback(callback)

        self._subscribe_script_callback()

        return self


    def remove_script_resume_callback(self, callback) -> 'Robios':
        super().remove_script_resume_callback(callback)

        self._unsubscribe_script_callback()

        return self


    def add_script_command_executed_callback(self, callback) -> 'Robios':
        super().add_script_command_executed_callback(callback)

        self._subscribe_script_callback()

        return self


    def remove_script_command_executed_callback(self, callback) -> 'Robios':
        super().remove_script_command_executed_callback(callback)

        self._unsubscribe_script_callback()

        return self

    
    def add_telemetry_callback(self, callback):
        super().add_telemetry_callback(callback)

        self.client.subscribe(context.TELEMETRY, self._on_telemetry)

        return self


    def remove_telemetry_callback(self, callback):
        super().remove_telemetry_callback(callback)

        if len(self._telemetry_callbacks) == 0:
            self.client.unsubscribe(context.TELEMETRY)

        return self


    def add_voice_recognition_callback(self, callback):
        super().add_voice_recognition_callback(callback)

        self.client.subscribe(context.Voice.USER_TEXT, self._on_voice_recognition)

        return self


    def remove_voice_recognition_callback(self, callback):
        super().remove_voice_recognition_callback(callback)

        if len(self._voice_recognition_callbacks) == 0:
            self.client.unsubscribe(context.Voice.USER_TEXT)

        return self


    def add_alert_dialog_callback(self, callback) -> 'Robios':
        super().add_alert_dialog_callback(callback)

        self.client.subscribe(context.Head.ALERT_DIALOG_RESULT, self._on_alert_dialog_result)

        return self


    def remove_alert_dialog_callback(self, callback) -> 'Robios':
        super().remove_alert_dialog_callback(callback)

        if len(self._alert_dialog_callbacks) == 0:
            self.client.unsubscribe(context.Head.ALERT_DIALOG_RESULT)

        return self


    def add_speak_callback(self, callback) -> 'Robios':
        super().add_speak_callback(callback)

        self.client.subscribe(context.SPEAK_CALLBACK, self._on_speak_callback)

        return self


    def remove_speak_callback(self, callback) -> 'Robios':
        super().remove_speak_callback(callback)

        if len(self._speak_callbacks) == 0:
            self.client.unsubscribe(context.SPEAK_CALLBACK)

        return self
    

    def add_message_callback(self, context: str, callback) -> 'Robios':
        super().add_message_callback(context, callback)

        self.client.subscribe(context, self._on_message_received)

        return self


    def remove_message_callback(self, context: str, callback) -> 'Robios':
        super().remove_message_callback(context, callback)

        context_callbacks = self._message_callbacks.get(context)

        if context_callbacks is None or len(context_callbacks) == 0:
            self.client.unsubscribe(context)

        return self


    def _on_message_received(self, context, data, robot_id):
        formatted_context = context_utils.remove_format(context)
        context_callbacks = self._message_callbacks.get(formatted_context)

        if context_callbacks is not None:
            for callback in context_callbacks:
                callback(formatted_context, data)


    def _on_script_callback(self, context, data, robot_id):
        message: ScriptCallback = ScriptCallback.decode(data)

        if message.event == ScriptCallback.CALLBACK_STARTED and self._script_start_callbacks is not None:
            for callback in self._script_start_callbacks:
                callback(message.parameters[0])
        
        elif message.event == ScriptCallback.CALLBACK_ENDED and self._script_end_callbacks is not None:
            for callback in self._script_end_callbacks:
                callback(message.parameters[0])

        elif message.event == ScriptCallback.CALLBACK_PAUSED and self._script_pause_callbacks is not None:
            for callback in self._script_pause_callbacks:
                callback(message.parameters[0], int(message.parameters[1]))

        elif message.event == ScriptCallback.CALLBACK_RESUMED and self._script_resume_callbacks is not None:
            for callback in self._script_resume_callbacks:
                callback(message.parameters[0])

        elif message.event == ScriptCallback.CALLBACK_EXECUTE_COMMAND and self._script_command_executed_callbacks is not None:
            for callback in self._script_command_executed_callbacks:
                callback(message.parameters[0], message.parameters[1])


    def _on_speak_callback(self, context, data, robot_id):
        message: SpeakCallback = SpeakCallback.decode(data)

        for callback in self._speak_callbacks:
            callback(message)


    def _on_alert_dialog_result(self, context, data):
        message = AlertDialogResult.decode(data)

        for callback in self._alert_dialog_callbacks:
            callback(message)


    def _on_face_detection(self, context, data):
        message = DetectedObjectArray.decode(data)

        for callback in self._face_detection_callbacks:
            callback(message)

    
    def _on_navigation_cancel(self, context, data):
        for callback in self._navigation_cancel_callbacks:
            callback()


    def _on_navigation_goal_status(self, context, data):
        message = IntWithHeader.decode(data)

        for callback in self._navigation_goal_status_callbacks:
            callback(message.data)


    def _on_navigation_goto_point(self, context, data):
        message: GoToPoint = GoToPoint.decode(data)

        for callback in self._navigation_goto_point_callbacks:
            x = message.point.position.x
            y = message.point.position.y
            z = message.point.position.z
            orientation = message.point.orientation
            callback(x, y, z, orientation, None, None)


    def _on_navigation_reset_odometry(self, context, data):
        for callback in self._navigation_reset_ododmetry_callbacks:
            callback()

    
    def _on_telemetry(self, context, data):
        message = Telemetry.decode(data)

        for callback in self._telemetry_callbacks:
            callback(message)

    
    def _on_voice_recognition(self, context, data):
        message: StringWithHeader = StringWithHeader.decode(data)

        for callback in self._voice_recognition_callbacks:
            callback(message.data)


    def _publish(self, message: Message):
        data = message.encode()
        self.client.publish(message.context, data)


class RobiosCommunicationExt(RobiosExt):
    def __init__(self, robios_communication: RobiosCommunication):
        super().__init__()
        self.robios_communication = robios_communication


    def move_by_force(self, left_wheel_force, right_wheel_force, interval=None):
        message = MoveByForce(left_wheel_force, right_wheel_force, interval)
        message.context = context.Move.BY_FORCE

        self.robios_communication._publish(message)

        return self


    def move_by_speed(self, left_wheel_speed, right_wheel_speed):
        message = MoveBySpeed(left_wheel_speed, right_wheel_speed)
        message.context = context.Move.BY_SPEED

        self.robios_communication._publish(message)

        return self


    def send_message(self, context, message):
        self.robios_communication.client.publish(context, message)
        return self


class RobiosCommunicationNavigation(RobiosNavigation):
    def __init__(self, robios_communication: RobiosCommunication):
        super().__init__()
        self.robios_communication = robios_communication


    def cancel(self):
        message = StringWithHeader()
        message.context = context.Navigation.CANCEL

        self.robios_communication._publish(message)

        return self

    
    def go_to_point(self, x, y, z, orientation):
        position = Vector3(x, y, z)
        point = NavigationPoint(position, orientation)
        message = GoToPoint(point)
        message.context = context.Navigation.GOTO_POINT

        self.robios_communication._publish(message)

        return self


    def go_to_checkpoint(self, checkpoint):
        checkpoint_msg = Checkpoint(checkpoint)
        message = GoToCheckpoint(checkpoint=checkpoint_msg)
        message.context = context.Navigation.GOTO_CHECKPOINT

        self.robios_communication._publish(message)

        return self


    def reset_odometry(self):
        message = StringWithHeader
        message.context = context.Navigation.RESET_ODOMETRY

        self.robios_communication._publish(message)

        return self


    def set_checkpoint(self, world, checkpoint, description, point_x, point_y, point_z, point_orientation):
        position = Vector3(point_x, point_y, point_z)
        point = NavigationPoint(position, point_orientation)
        message = Checkpoint(checkpoint, description, world, Checkpoint.CATEGORY_CHECKPOINT, '', point)
        message.context = context.Navigation.SET_CHECKPOINT

        self.robios_communication._publish(message)

        return self