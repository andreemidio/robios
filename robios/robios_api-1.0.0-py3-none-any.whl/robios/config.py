#!/usr/bin/env python

class RobiosConfig:
    COMMUNICATION_MQTT: str = 'mqtt'
    COMMUNICATION_SOCKET: str = 'socket'

    def __init__(self, robot_address: str="localhost", robot_port: int=1883, communication_source: str='mqtt', robot_id: str=None):
        self.communication_source = communication_source
        self.robot_address = robot_address
        self.robot_port = robot_port
        self.robot_id = robot_id