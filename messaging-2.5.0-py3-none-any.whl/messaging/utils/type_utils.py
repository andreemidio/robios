#!/usr/bin/env python

def parse_bool(string_value):
    return string_value.lower() == "true"