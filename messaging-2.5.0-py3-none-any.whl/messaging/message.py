#!/usr/bin/env python
"""Human Robotic's messaging library main module.

The message module contains the Message's base class that is used for
all the message types implementation.

Classes
----------
Message
    The base class for every message implementation.
"""

import importlib
from typing import List
from messaging.utils.type_utils import parse_bool

class Message(object):
    """The base class for every message implementation.

    It has the base operations used to Decode and Encode messages.

    Constants
    ----------
    CURRENT_VERSION : int
        The current version of the Message implementation.

    SEPARATOR : str
        Is the character used as a separator for each field of the message.

    LIST_SEPARATOR : str
        Is the character used as a separator for a list field of the message.

    Attributes
    ----------
    version : int
        Represents the version of this message instance.

    context : str
        Represents a context that this message is related to.

    type : str
        Is the name that identifies the type of this message. Is is used
        to instantiate the message through reflection.

    origin : str
        Represents the origin of the message. It is the place this 
        message is coming from.

    Methods
    ----------
    decode(raw_message)
        Decodes a message text into a Message's instance.

    encode()
        Encodes the message into a string.

    get_default_origin() - static
        Gets the default value of the message's origin
        when it is not set by the user.

    set_default_origin() - static
        Sets the default value of the message's origin
        when it is not set by the user.
    """
    CURRENT_VERSION = 2
    SEPARATOR = '@'
    LIST_SEPARATOR = '#'
    SEPARATOR_ESCAPE = '\\%$\\'
    LIST_SEPARATOR_ESCAPE = '\\%&\\'

    __default_origin = 'robot'

    def __init__(self):
        """The base constructor of a Message instance.

        It initializes the value the version and type attributes.
        """
        self.version = Message.CURRENT_VERSION
        self.context = ""
        self.message_type = type(self).__name__
        self.origin = Message.get_default_origin()
        self._escape_strings = True

    @staticmethod
    def decode(raw_message):
        """Decodes a message text into a Message's instance.

        The process of decoding a message is performed by spliting 
        the raw encoded message string by the Message's SEPARATOR and
        placing each field on it respective attribute, using the unpack
        method of the Message implementation.

        Parameters
        ----------
        raw_message : str
            is the encoded string that represents the message.

        Returns
        ----------
        Message
            a Message instance with the values of the attributes filled
            based on the raw_message parameter.
        """
        fields = raw_message.split(Message.SEPARATOR)

        index = 0

        version = int(fields[index]); index+=1
        context = fields[index]; index+=1
        message_type = fields[index]; index+=1

        module = importlib.import_module(f"messaging.types.{message_type}")
        clazz = getattr(module, message_type)
        message = clazz()

        message.version = version
        message.context = context

        if version == Message.CURRENT_VERSION:
            message.origin = fields[index]; index+=1

        message.unpack(fields, index)

        return message


    def encode(self):
        """Encodes a message into a string.

        The process of encoding a message is performed by joining the
        Message attributs into a String, separating each field by a
        character defined by the SEPARATOR constant. It uses the pack
        method to get the ordered valeus of the fields as an array of
        strings and join them in one string message.

        Returns
        ----------
        str
            The encoded message in a text format.
        """
        fields = self.pack()

        encoded = []
        encoded.append(str(self.version))
        encoded.append(Message.SEPARATOR)
        encoded.append(self.context)
        encoded.append(Message.SEPARATOR)
        encoded.append(self.message_type)

        if self.version == Message.CURRENT_VERSION:
            encoded.append(Message.SEPARATOR)
            encoded.append(self.origin)

        for i in range(0, len(fields)):
            encoded.append(Message.SEPARATOR)
            encoded.append(fields[i])

        return ''.join(encoded)


    def pack(self):
        """Packs the Message's attributes into an array of string.

        The pack process is used by the Message class whe it performs
        the encode operation.

        The class who implements the Message class must implement the
        pack method and returns an array of string with its attributes
        values, in order.

        NOTE: The order matters! The message attributes values must be
        in the same order as the fields in the unpack method.

        Returns
        ----------
        list
            An array of strings with the values of the attributes in the
            message implementation.
        """
        raise NotImplementedError()


    def unpack(self, fields, startingIndex):
        """Unpacks the Message's values into its respective attributes 
        in the instance.

        The unpack process is used by the Message class when it performs
        the decode operation.

        The class who implements the Message class must implement the
        method unpack and read the fields value into its respective 
        attributes in the instance, in order, and them return the index
        of the last read item plus one.

        The startingIndex parameter must be used as the index of the 
        first parameter in the array.

        NOTE: The order matters! The message attributes values must be
        read in the same order as the pack method.

        Parameters
        ----------
        fields : list
            Is an array of string containing all the message's 
            attributes values, in order.

        startingIndex : int
            Is the index of the first item to be read in the array.

            NOTE: The index must be the position of the last read item
            in the array plus one. That's because the returned index of
            the unpack method can be used as the starting index of
            another message, in cases where a message is used as an
            attribute of another message.

        Returns
        ----------
        int
            The index after the last read item in the array.
        """
        raise NotImplementedError()


    def _pack_array(self, array):
        """Packs an array in one string field.

        Use this method for packing and an array that is used an
        attribute of another message.

        It will pack the array with the separator of the LIST_SEPARATOR
        constant, and return it in one string to be used as a field of
        a superior Message that has this array as an attribute.

        Parameters
        ----------
        array : list
            Is the array to be packed. The items of the array must have
            a Message instance or primitive types (bool, int, float or
            str).

        Returns
        ----------
        str
            The packed array formatted in a text.
        """
        if array == None or len(array) == 0:
            return ''

        packed = []

        for i in range(0, len(array)):
            if isinstance(array[i], Message):
                fields = array[i].pack()

                for j in range(0, len(fields)):
                    # Ignore the separator on the first field
                    if i == 0 and j == 0:
                        packed.append(fields[i])
                    else:
                        packed.extend([ Message.LIST_SEPARATOR, fields[j] ])
            
            else:
                field = self._pack_field(array[i])

                # Ignore the separator on the first field
                if i == 0:
                    packed.append(field)
                else:
                    packed.extend([ Message.LIST_SEPARATOR, field ])

        return ''.join(packed)


    def _unpack_array(self, field, value_type):
        """Unpacks a field text into an array of Messages.

        Use this method for unpacking a field text into an attribute of
        another message.

        It will unpack the field with the separator of the LIST_SEPRATOR
        constant, and return it in a list to populate a superior Message 
        that has an array of this type as an attribute.

        Parameters
        ----------
        field : str
            Is the field content formatted in a text.

        valeu_type : type
            Is data type of the items to be unpacked. I must be a
            subclass of the Message class or a primitive type (bool,
            int, float or str).

        Returns
        ---------
        list
            An array of items of the type defined in the value_type 
            parameter with the data from the field.
        """
        if field == None or len(field) == 0:
            return None

        fields = field.split(Message.LIST_SEPARATOR)

        if issubclass(value_type, Message):
            # Unpack messages
            index = 0
            message_list: List[value_type] = []
            while (index < len(fields)):
                message = value_type()
                index = message.unpack(fields, index)
                message_list.append(message)

            return message_list

        elif value_type is bool:
            # Unpack bool
            bool_list: List[bool] = []
            for item in fields:
                bool_list.append(self._unpack_boolean(item))
            
            return bool_list

        elif value_type is int:
            # Unpack int
            int_list: List[int] = []
            for item in fields:
                int_list.append(self._unpack_int(item))

            return int_list

        elif value_type is float:
            # Unpack float
            float_list: List[float] = []
            for item in fields:
                float_list.append(self._unpack_float(item))

            return float_list

        elif value_type is str:
            # Unpack string
            str_list: List[str] = []
            for item in fields:
                str_list.append(self._unpack_string(item))

            return str_list
            
        else:
            raise ValueError("Invalid type to unpack array.")

    
    def _pack_field(self, field) -> str:
        """ Prepare a field value for packing.

        It gets the value provided by parameter and parse it to str,
        performing any required modification to be ready for packing.

        Use this method when implementing the pack() method for a
        message type.

        Parameters
        ----------
        field
            Is the value of the field.

            For 'str' values, the pack process escape the characters
            that can conflict with the separators characters.

            For 'bool', 'int' and 'float' values, the pack process only 
            parses the field to str.

        Returns
        ----------
        str
            A 'str' value of the field, ready to be packed.
        """
        if field == None:
            return ''

        field_type = type(field)

        # Escape characters for 'str' type
        if field_type is str:
            if self._escape_strings == True:
                return self._escape_text(field)
            else:
                return field

        # Simply parse the field to 'str' for the other types
        else:
            return str(field)


    def _unpack_string(self, field: str) -> str:
        """Unpacks an raw field to its original value.

        Use this method when implementing the unpack() method for a
        message type.

        Parameters
        ----------
        field : str
            Is the packed str value of the field.

            For the str values, the unpack process replaces the escaped
            characters to their actual values.

        Returns
        ----------
        str
            The original value of a str field.
        """
        if field == None:
            return ''

        if self._escape_strings == True:
            return self._remove_escape(field)
        else:
            return field


    def _unpack_boolean(self, field: str) -> bool:
        """Unpacks an raw field to its original value.

        Use this method when implementing the unpack() method for a
        message type.

        Parameters
        ----------
        field : str
            Is the packed str value of the field.

            For the bool values, the unpack process simply parses the
            packed value to its corrent type.

        Returns
        ----------
        str
            The original value of a bool field.
        """
        return parse_bool(field)


    def _unpack_int(self, field: str) -> int:
        """Unpacks an raw field to its original value.

        Use this method when implementing the unpack() method for a
        message type.

        Parameters
        ----------
        field : str
            Is the packed str value of the field.

            For the int values, the unpack process simply parses the
            packed value to its corrent type.

        Returns
        ----------
        str
            The original value of a int field.
        """
        return int(field)

    
    def _unpack_float(self, field: str) -> float:
        """Unpacks an raw field to its original value.

        Use this method when implementing the unpack() method for a
        message type.

        Parameters
        ----------
        field : str
            Is the packed str value of the field.

            For the float values, the unpack process simply parses the
            packed value to its corrent type.

        Returns
        ----------
        str
            The original value of a float field.
        """
        return float(field)


    def _escape_text(self, text: str) -> str:
        """Escape characters in a given text.

        It replaces all the separators characters, adding a escape 
        character in place of them.

        Parameters
        ----------
        text : str
            Is the text to be transformed

        Returns
        ----------
        str
            A new text with teh supplied characters escaped.
        """
        return text \
                .replace(Message.SEPARATOR, Message.SEPARATOR_ESCAPE) \
                .replace(Message.LIST_SEPARATOR, Message.LIST_SEPARATOR_ESCAPE)

    
    def _remove_escape(self, text: str) -> str:
        """Remove the escape characters of a given text.

        It replaces all escaped characters, adding the separator
        characters in place of them.

        Parameters
        ----------
        text : str
            Is the text to be transformed.

        Returns
        ----------
        str
            A new text with the escaped characters replace.
        """
        return text \
                .replace(Message.SEPARATOR_ESCAPE, Message.SEPARATOR) \
                .replace(Message.LIST_SEPARATOR_ESCAPE, Message.LIST_SEPARATOR)


    @staticmethod
    def get_default_origin() -> str:
        return Message.__default_origin


    @staticmethod
    def set_default_origin(origin: str):
        Message.__default_origin = origin


    def __eq__(self, other):
        if other == None:
            return False
        if isinstance(other, Message):
            return \
                self.version == other.version and \
                self.context == other.context and \
                self.message_type == other.message_type
        else:
            return False