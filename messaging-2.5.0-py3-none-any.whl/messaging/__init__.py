"""Human Robotic's messaging library

The messaging library is a package to deal with the messages of the 
Human Robotics systems.

Modules
----------
message
    Is the main module of the library, containing the base class for all
    message types implementation.


Sub-packages
----------
tests
    Contains the unit test modules of the project.

types
    Contains all the Message's types implementations.

utils
    Utilities module used by the other modules in the project.
"""