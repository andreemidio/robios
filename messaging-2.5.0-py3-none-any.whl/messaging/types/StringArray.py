#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class StringArray(Message):
    """Message type implementation for an array of string with header.
    
    Attributes
    ----------
    header : Header
        Message's header.

    array : list
        The string array of the message.
    """ 

    def __init__(self, header=None, array=['']):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is a new instance of Header).
            
        arra : list, optional
            Is the string array to set (default value is ['']).
        """
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header
            
        self.array = array

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_array(self.array))

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.array = self._unpack_array(fields[index], str); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, StringArray):
            return \
                self.header == other.header and \
                self.array == other.array
        else:
            return False