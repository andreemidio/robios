#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class MoveByForce(Message):
    """Message type implementation of the action to move the robot using
    the force movement type.

    Attributes
    ----------
    header : Header
        Message's header.

    left_wheel_force : int
        The force that will be applied at the left wheel. Use negative
        values to move it backwards.

    right_wheel_force : int
        The force that will be applied at the right wheel. Use negative
        values to move it backwards.

    interval : int
        The time (in milliseconds) the force will be applied to the 
        wheels.
    """

    def __init__(self, left_wheel_force=0, right_wheel_force=0, interval=None):
        """Initializes the message instance.

        Parameters
        ----------
        left_wheel_force : int, optional
            Is the force to be applied in the left wheel (default value
            is 0).
            
        right_wheel_force : int, optional
            Is the force to be applied in the right wheel (default value
            is 0).

        interval : int, optional
            Is the interval time value to set (default value is None).
        """
        super().__init__()
        self.header = Header()
        self.left_wheel_force = left_wheel_force
        self.right_wheel_force = right_wheel_force
        self.interval = interval


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.left_wheel_force),
            self._pack_field(self.right_wheel_force),
            self._pack_field(self.interval) if self.interval is not None else ''
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.left_wheel_force = self._unpack_int(fields[index]); index+=1
        self.right_wheel_force = self._unpack_int(fields[index]); index+=1
        self.interval = self._unpack_int(fields[index]) if len(fields[index]) > 0 else None

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, MoveByForce):
            return \
                self.header == other.header and \
                self.left_wheel_force == other.left_wheel_force and \
                self.right_wheel_force == other.right_wheel_force and \
                self.interval == other.interval
        else:
            return False