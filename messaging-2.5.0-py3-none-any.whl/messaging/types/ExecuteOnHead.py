#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class ExecuteOnHead(Message):
    """Message type implementation to execute actions and commands in
    the Robios Head App.

    Constants
    ----------
    TYPE_INTERNAL_APP : str
        Executes an internal application in the Robios Head App.

    TYPE_EXTERNAL_APP : str
        Executes an external application in the Robios Head App.

    TYPE_COMMAND : str
        Executes a command in the Robios Head App.

    Attributes
    ----------
    header : Header
        Message's header.

    execution_type : str
        Defines the type of action to be exeucted in the Robios Head 
        App. Check the constants for the possible values.

    execution_parameter : str
        Additional parameter of the execute action. The values must be:

        For TYPE_COMMAND: The command to execute.
        For TYPE_EXTERNAL_APP: The external app's name.
        For TYPE_INTERNAL_APP: The internal app's id.
    """

    TYPE_INTERNAL_APP = 'internal_app'
    TYPE_EXTERNAL_APP = 'external_app'
    TYPE_COMMAND = 'command'

    def __init__(self, execution_type='', execution_parameter=''):
        """Initializes the message instance.

        Parameters
        ----------
        execution_type : str, optional
            Is the execution type to set (default value is '').

        execution_parameter : str, optional
            Is the additional paramter for the execution to set (default
            value is '').
        """
        super().__init__()

        self.header = Header()
        self.execution_type = execution_type
        self.execution_parameter = execution_parameter


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.execution_type), 
            self._pack_field(self.execution_parameter)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.execution_type = self._unpack_string(fields[index]); index+=1
        self.execution_parameter = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ExecuteOnHead):
            return \
                self.header == other.header and \
                self.execution_type == other.execution_type and \
                self.execution_parameter == other.execution_parameter
        else:
            return False