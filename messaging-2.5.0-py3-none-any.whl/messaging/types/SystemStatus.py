#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class SystemStatus(Message):
    """Message type implementation of the status of the robot systems.

    Constants
    ----------
    STATUS_NO_INFO : int
        No info about the system.
    
    STATUS_OK : int
        The system is OK.
    
    STATUS_NOK : int
        Indicates that some problem occurred with the system.
    
    STATUS_READY : int
        The system is ready to use.
    
    STATUS_PROCESSING : int
        The system is processing something.
    
    STATUS_INITIALIZING : int
        The system is initializing.
    
    STATUS_REBOOTING : int
        The system is rebooting.
    
    STATUS_OFF : int
        The system if turned off.

    Attributes
    ----------
    header : Header
        Message's header.

    name : str
        The system's name.

    status : int
        The system's status. Check the constants for the available
        status.
    """
    STATUS_NO_INFO = 0
    STATUS_OK = 1
    STATUS_NOK = 2
    STATUS_READY = 3
    STATUS_PROCESSING = 4
    STATUS_INITIALIZING = 5
    STATUS_REBOOTING = 6
    STATUS_OFF = 7

    def __init__(self, name='', status=STATUS_NO_INFO):
        """Initializes the message instance.

        Parameters
        ----------
        name : str, optional
            Is the system's name to set (default value is '').

        status : int, optional
            Is the system's status to set (default value is the constant
            STATUS_NO_INFO).
        """
        super().__init__()

        self.header = Header()
        self.name = name
        self.status = status


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([ 
            self._pack_field(self.name), 
            self._pack_field(self.status)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.name = self._unpack_string(fields[index]); index+=1
        self.status = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, SystemStatus):
            return \
                self.header == other.header and \
                self.name == other.name and \
                self.status == other.status
        else:
            return False