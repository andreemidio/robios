#!/usr/bin/env python

from messaging.utils.type_utils import parse_bool
from messaging.message import Message
from messaging.types.Header import Header

class BooleanWithHeader(Message):
    """Message type implementation of bool content with header.
    
    Attributes
    ----------
    header : Header
        Message's header.

    data : bool
        The bool data of the message.
    """ 
    
    def __init__(self, header=None, data=False):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is None).

        data : bool, optional
            Is the bool value to set (default value is False).
        """
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header
            
        self.data = data

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.data))

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.data = self._unpack_boolean(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, BooleanWithHeader):
            return \
                self.header == other.header and \
                self.data == other.data
        else:
            return False