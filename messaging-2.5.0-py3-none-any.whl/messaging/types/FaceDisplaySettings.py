#!/usr/bin/env python

from messaging.message import Message

class FaceDisplaySettings(Message):
    MODE_NONE = 'none'
    MODE_RESIZED = 'resized'

    POSITION_TOP_LEFT = 'topleft'
    POSITION_TOP_CENTER = 'topcenter'
    POSITION_TOP_RIGHT = 'topright'
    POSITION_MIDDLE_LEFT = 'middleleft'
    POSITION_MIDDLE_CENTER = 'middlecenter'
    POSITION_MIDDLE_RIGHT = 'middleright'
    POSITION_BOTTOM_LEFT = 'bottomleft'
    POSITION_BOTTOM_CENTER = 'bottomcenter'
    POSITION_BOTTOM_RIGHT = 'bottomright'

    """Message type implementation defining the settings of how to
    display the robot's face.

    Constants
    ----------
    MODE_NONE : str
        Display mode to not show the robot's face.

    MODE_RESIZED : str
        Display mode to resize the robot's face.

    POSITION_TOP_LEFT : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at top left corner.

    POSITION_TOP_CENTER : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at top center.

    POSITION_TOP_RIGHT : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at top right corner.

    POSITION_MIDDLE_LEFT : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at middle left.

    POSITION_MIDDLE_CENTER : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at middle center.

    POSITION_MIDDLE_RIGHT : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at middle right

    POSITION_BOTTOM_LEFT : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at bottom left corner.

    POSITION_BOTTOM_CENTER : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at bottom center.

    POSITION_BOTTOM_RIGHT : str
        Constant for the MODE_RESIZED mode to position the robot's face 
        at bottom right corner.


    Attributes
    ----------
    mode : str
        The robot's face display mode. Check the constants for the 
        available values.

    position : str
        The robot's face display position. Check the constants for
        the available values.
        This attribute works when the display mode is set as
        MODE_RESIZED.

    size : float
        The robot's face display scale.
        This attribute works when the display mode is set as
        MODE_RESIZED.
        It must be a value from 0 to 1.
    """

    def __init__(self, mode='none', position='topleft', size=0.0):
        """Initializes the message instance.

        Parameters
            mode : str, optional
                The face display mode to set (default is MODE_NONE)

            position : str, optional
                The face display position to set (default is 
                POSITION_TOP_LEFT)

            size : float, optional
                The face display scale to set (default is 0.0)
        """
        super().__init__()

        self.mode = mode
        self.position = position
        self.size = size


    def pack(self):
        return [
            self._pack_field(self.mode), 
            self._pack_field(self.position), 
            self._pack_field(self.size)
        ]


    def unpack(self, fields, starting_index):
        index = starting_index

        self.mode = self._unpack_string(fields[index]); index+=1
        self.position = self._unpack_string(fields[index]); index+=1
        self.size = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, FaceDisplaySettings):
            return \
                self.mode == other.mode and \
                self.position == other.position and \
                self.size == other.size
        else:
            return False