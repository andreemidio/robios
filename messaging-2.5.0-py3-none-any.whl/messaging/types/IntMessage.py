#!/usr/bin/env python

from messaging.message import Message

class IntMessage(Message):
    """Message type implementation of int content.
    
    Attributes
    ----------
    data : int
        The int data of the message.
    """

    def __init__(self, data=0):
        """Initializes the message instance.

        Parameters
        ----------
        data : int, optional
            Is the int value to set (default is 0).
        """
        super().__init__()

        self.data = data

    
    def pack(self):
        return [ self._pack_field(self.data) ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.data = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, IntMessage):
            return self.data == other.data
        else:
            return False