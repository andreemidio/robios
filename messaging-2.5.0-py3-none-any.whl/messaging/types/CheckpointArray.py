#!/usr/bin/env python

from typing import List

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Checkpoint import Checkpoint

class CheckpointArray(Message):
    '''Message type implementation containing an array of checkpoints 
    with a header.

    Attributes
    ----------
    header : Header
        The message's header.

    arucos : List[Checkpoint]
        The list of Checkpoints.
    '''
    def __init__(self, header: Header=Header(), checkpoints: List[Checkpoint]=[]):
        '''Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is message header to set (default value is a new instance of
            Header).

        arucos : List[Checkpoint]
            Is the list of checkpoints to set (default value is []).
        '''
        super().__init__()

        self.header = header
        self.checkpoints = checkpoints


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_array(self.checkpoints))

        return packed


    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.checkpoints = self._unpack_array(fields[index], Checkpoint); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, CheckpointArray):
            return  \
                self.header == other.header and \
                self.checkpoints == other.checkpoints
        else:
            return False