#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector2 import Vector2
from messaging.types.Vector3 import Vector3

class SensorMinDistance(Message):
    """Message type implementation representing the minimum distance of sensor.

    Attributes
    ----------
    header : Header
        Message's header

    sensor_type : str
        The sensor type of the distacne. For example: infrared, 
        ultrasonic, depthCamera, etc.

    points_number : int
        Number of points in the point cloud when using the depth camera.

    dense : bool
        True if the point cloud has no NaN/Inf values when using depth
        camera.

    distance : float
        Minimum distance to the obstacle (in meters).

    angle : Vector2
        Horizontal and vertical angle in degrees of the point closer to
        depth camera.

    point : Vector3
        Coordinates of the point closer to depth camera in meters.
    """
    
    def __init__(self, header: Header=None, sensor_type: str='', points_number: int=0, dense: bool=False, distance: float=0.0, angle: Vector2=None, point:Vector3=None):
        """Initilizes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header value to set (default value is a new instance 
            of Header).

        sensor_type : str, optional
            Is the sensor type to set (default value is '').

        points_number : int, optional
            Is the number of points in the point cloud of the depth
            camera (default value is 0).

        dense : bool, optional
            Is the value defining if the point cloud has no NaN/Inf
            values (default value if False).

        distance : float, optional
            Is the minimum distance to the obstacle to set (default
            value is 0.0).

        angle : Vector2, optional
            Is the angle of the point closer to depth camera to set
            (default value is a new instance of Vector2).

        point : Vector3, optional
            Is the point closer to depth camera to set (default value
            is a new instance of Vector3).
        """
        super().__init__()
        self.header = header or Header()
        self.sensor_type = sensor_type
        self.points_number = points_number
        self.dense = dense
        self.distance = distance
        self.angle = angle or Vector2()
        self.point = point or Vector3()

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.sensor_type))
        packed.append(self._pack_field(self.points_number))
        packed.append(self._pack_field(self.dense))
        packed.append(self._pack_field(self.distance))
        packed.extend(self.angle.pack())
        packed.extend(self.point.pack())
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.sensor_type = self._unpack_string(fields[index]); index+=1
        self.points_number = self._unpack_int(fields[index]); index+=1
        self.dense = self._unpack_boolean(fields[index]); index+=1
        self.distance = self._unpack_float(fields[index]); index+=1
        index = self.angle.unpack(fields, index)
        index = self.point.unpack(fields, index)

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, SensorMinDistance):
            return \
                self.header == other.header and \
                self.sensor_type == other.sensor_type and \
                self.points_number == other.points_number and \
                self.dense == other.dense and \
                self.distance == other.distance and \
                self.angle == other.angle and \
                self.point == other.point
        else:
            return False