#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class MoveBySpeed(Message):
    """Message type implementation of the action to move the robot using
    the speed movement type.

    Attributes
    ----------
    header : Header
        Message's header.

    left_wheel_speed : float
        The speed, in RPM (Rotation per minute), that will be applied 
        at the left wheel. Use negative values to rotate the wheel 
        backwards.

    right_wheel_speed : float
        The speed, in RPM (Rotation per minute), that will be applied
        at the right wheel. Use negative values to roate the wheel
        backwards.
    """

    def __init__(self, left_wheel_speed=0.0, right_wheel_speed=0.0):
        """Initializes the message instance.

        Parameters
        ----------
        left_wheel_speed : float, optional
            Is the speed to be applied in the left wheel (default value
            is 0.0).

        right_wheel_speed : flaot, optional
            Is the speed to be applied in the right wheel (default value
            is 0.0).
        """
        super().__init__()
        self.header = Header()
        self.left_wheel_speed = left_wheel_speed
        self.right_wheel_speed = right_wheel_speed


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.left_wheel_speed),
            self._pack_field(self.right_wheel_speed),
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.left_wheel_speed = self._unpack_float(fields[index]); index+=1
        self.right_wheel_speed = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, MoveBySpeed):
            return \
                self.header == other.header and \
                self.left_wheel_speed == other.left_wheel_speed and \
                self.right_wheel_speed == other.right_wheel_speed
        else:
            return False