#!/usr/bin/env python

from messaging.message import Message
from messaging.utils.type_utils import parse_bool

class WifiAccessPoint(Message):
    """Message type implementation of a Wi-Fi Access Point information.

    Attributes
    ----------
    ssid : str
        The Wi-Fi's SSID value.

    security : str
        The Wi-Fi's security level.

    signal : int
        The Wi-Fi Access Point signal level.

    in_use : bool
        Defines if the Wi-Fi Access Point is in use by the interface (if
        it is connected).
    """

    def __init__(self, ssid='', security='', signal=0, in_use=False):
        """Initializes the message instance.

        Parameters
        ----------
        ssid : str, optional
            The SSID value to set (default is '')

        security : str, optional
            The security value to set (default is '')

        signal : int, optional
            The signal level to set (default is 0)

        in_use : bool, optional
            The value idicating if the Wi-Fi access point is connected
            to set (default is False)
        """
        super().__init__()
        self.ssid = ssid
        self.security = security
        self.signal = signal
        self.in_use = in_use

    
    def pack(self):
        packed = []
        packed.extend([
            self._pack_field(self.ssid), 
            self._pack_field(self.security),
            self._pack_field(self.signal),
            self._pack_field(self.in_use)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        self.ssid = self._unpack_string(fields[index]); index+=1
        self.security = self._unpack_string(fields[index]); index+=1
        self.signal = self._unpack_int(fields[index]); index+=1
        self.in_use = self._unpack_boolean(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, WifiAccessPoint):
            return \
                self.ssid == other.ssid and \
                self.security == other.security and \
                self.signal == other.signal and \
                self.in_use == other.in_use
        else:
            return False