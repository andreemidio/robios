#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector2 import Vector2
from messaging.types.Geometry2D import Geometry2D
from messaging.types.TrackingInfo import TrackingInfo

class DetectedObject(Message):
    """Message type implementation for the detected objects in the 
    vision module.

    This message is used to send information about any type of entity
    detected by image processing system, like the recognized faces,
    objects and etc.

    Attributes
    ----------
    name : str
        The name of the detected object.

    object_type : str
        The type of the object. It defines what this object is, 
        like a face, a person body or any other type of entity that
        can be detected.

    accuracy : float
        The detection accuracy.

    object_index : int
        The index of the detected object.

    global_image_size : Vector2
        Defines the size of the image that this entity has been
        detected.

    geometry : Geometry2D
        The geometry of the detected object inside the size defined by
	    the global_image_size attribute. It contains the position and 
        size of this entity in the image frame.
    """

    def __init__(self, name='', object_type='', accuracy=0.0, object_index=0):
        """Initializes the message instance.

        Parameters
        ----------
        name : str, optional
            Is the name to set (default value is '').

        object_type : str, optional
            Is the type of object to set (default value is '').

        accuracy : float, optional
            Is the detection accuracy to set (default value is 0.0).

        object_index : int, optional
            Is the index of the object to set (default value is 0).
        """
        super().__init__()

        self.name = name
        self.object_type = object_type
        self.accuracy = accuracy
        self.object_index = object_index
        self.global_image_size = Vector2()
        self.geometry = Geometry2D()
        self.tracking_info = TrackingInfo()

    
    def pack(self):
        packed = []
        packed.extend([
            self._pack_field(self.name),
            self._pack_field(self.object_type),
            self._pack_field(self.accuracy),
            self._pack_field(self.object_index)
        ])
        packed.extend(self.global_image_size.pack())
        packed.extend(self.geometry.pack())
        packed.extend(self.tracking_info.pack())
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.name = self._unpack_string(fields[index]); index+=1
        self.object_type = self._unpack_string(fields[index]); index+=1
        self.accuracy = self._unpack_float(fields[index]); index+=1
        self.object_index = self._unpack_int(fields[index]); index+=1
        index = self.global_image_size.unpack(fields, index)
        index = self.geometry.unpack(fields, index)
        index = self.tracking_info.unpack(fields,index)

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, DetectedObject):
            return \
                self.name == other.name and \
                self.object_type == other.object_type and \
                self.accuracy == other.accuracy and \
                self.object_index == other.object_index and \
                self.global_image_size == other.global_image_size and \
                self.geometry == other.geometry and \
                self.tracking_info == other.tracking_info
        else:
            return False