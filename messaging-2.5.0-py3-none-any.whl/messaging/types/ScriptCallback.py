#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class ScriptCallback(Message):
    """Message type implementation of the robot Script System's
    callbacks.

    Constants
    ----------
    CALLBACK_STARTED : str
        Event when a new script starts.
    
    CALLBACK_ENDED : str
        Event when the execution of a script ends.

    CALLBACK_PAUSED : str
        Event when the execution of the current script gets paused.
    
    CALLBACK_RESUMED : str
        Event when the execution of the current script gets resumed.
    
    CALLBACK_EXECUTE_COMMAND : str
        Event when a script command is executed.

    Attributes
    ----------
    header : Header
        Message's header

    event : str
        The callback event of the Script System. Check the constants for
        the available events.

    parameters : list
        A list of additional parameters of the event.
    """

    CALLBACK_STARTED = 'onScriptStart'
    CALLBACK_ENDED = 'onScriptEnd'
    CALLBACK_PAUSED = 'onScriptPause'
    CALLBACK_RESUMED = 'onScriptResume'
    CALLBACK_EXECUTE_COMMAND = 'onExecuteCommand'

    def __init__(self, event='', parameters=[]):
        """Initializes the message instance.

        Parameters
        ----------
        event : str, optional
            Is the event to set (default value is ''). 
            
            Check the constants for the available events.

        parameters : list, optional
            Is a list of additional parameters of the event to set
            (default value is []).
        """
        super().__init__()

        self.header = Header()
        self.event = event
        self.parameters = parameters


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.event))
        packed.append(self._pack_array(self.parameters))

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.event = self._unpack_string(fields[index]); index+=1
        self.parameters = self._unpack_array(fields[index], str); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ScriptCallback):
            return \
                self.header == other.header and \
                self.event == other.event and \
                self.parameters == other.parameters
        else:
            return False