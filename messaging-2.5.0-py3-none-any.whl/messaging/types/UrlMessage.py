#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class UrlMessage(Message):
    '''Message type implementation of string content with header.

    Attributes
    ----------
    header : Header
        Message's header.

    url: str
        The URL address to call.
    '''
    def __init__(self, header: Header=None, url: str=''):
        '''Initializes the message instance.
        
        Parameters
        ----------
        header: Header, optional
            Is the header to set (default value is None).

        url: str, optional
            Is the URL address to set (default value is '').
        '''
        super().__init__()
        
        if header == None:
            self.header = Header()
        else:
            self.header = header

        self.url = url


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.url))

        return packed


    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.url = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other: object) -> bool:
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, UrlMessage):
            return \
                self.header == other.header and \
                self.url == other.url
        else:
            return False