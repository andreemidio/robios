#!/usr/bin/env python

from messaging.message import Message

class LongMessage(Message):
    """Message type implementation of long content.
    
    Note: In python, the int type is used for long values as well.
    So this message type works exactly the same as the IntMessage.
    This message has been implemented to keep the compatibility with the
    other languages that has a separate type for int and long.

    Attributes
    ----------
    data : int
        The long data of the message.
    """

    def __init__(self, data=0):
        """Initializes the message instance.

        Parameters
        ----------
        data : int, optional
            Is the long value to set (default is 0).
        """
        super().__init__()

        self.data = data

    
    def pack(self):
        return [ self._pack_field(self.data) ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.data = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, LongMessage):
            return self.data == other.data
        else:
            return False