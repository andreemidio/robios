#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class MoveHead(Message):
    """Message type implementation of the action to move the head of the
    robot.

    Attributes
    ----------
    header : Header
        Message's header.

    horizontal_angle : int
        The value of angle, in degrees, to move the head 
        horizontallly.

    vertical_angle : int
        The value of angle, in degrees, to move the head
        vertically.
    """

    def __init__(self, horizontal_angle=0, vertical_angle=0):
        """Initializes the message instance.

        Parameters
        ----------
        horizontal_angle : int, optional
            Is the angle of the horizontal movement to set (default 
            value is 0).

        vertical_angle : int, optional
            Is the angle of the vertical movement to set (default
            value is 0).
        """
        super().__init__()
        self.header = Header()
        self.horizontal_angle = horizontal_angle
        self.vertical_angle = vertical_angle


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.horizontal_angle),
            self._pack_field(self.vertical_angle),
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.horizontal_angle = self._unpack_float(fields[index]); index+=1
        self.vertical_angle = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, MoveHead):
            return \
                self.header == other.header and \
                self.horizontal_angle == other.horizontal_angle and \
                self.vertical_angle == other.vertical_angle
        else:
            return False