#!/usr/bin/env python

"""
 Message type implementation to send Email Message from Robios to a target.
 See: Header
"""

__author__ = 'Alexandre Calil'


from messaging.message import Message
from messaging.types.Header import Header


class EmailMessage(Message):
    """
    Message type implementation to send Email Message from Robios to a target.

    Attributes
    ----------
    header : Header
        Message's header.

    name : str -> [Optional, Default: 'Senhor(a)']
        Recipient name. 

    recipient : str -> [Required]
        Recipient email. 
    
    subject : str -> [Optional, Default: 'Hey']
        Email subject (title). 

    html_content : str -> [Optional]
        It's a body message contained in the email html, accepts HTML tags. 

    file_encoded : str -> [Optional]
        It's a file to send through the email.
        The steps to encode is: 
            1) Read the file in binary mode
            2) Encode the file in BASE64
            2) Decode the file in UTF-8
            4) Save into a string.
            
        Python Example:
            import base64
            with open(file_path, 'rb') as fp:
                file_data_encoded: str = base64.b64encode(fp.read()).decode('utf-8')

    file_extension : str -> [Required if you are passing file_encoded]
        It's the file extension of the file that you are sending.
        Works with a bunch of extensions like: png, pdf, txt, log, tiff, xlsx, csv, gif, jpg, ...

        Avoid to send large files.(Limit ?)
        Files tested that won't work: mp4(>1.2mb)

        Example: file_extension='png' -> Uppercase or Lowercase, without the dot.      

    show_image_in_html : bool -> [Optional, Default: True]
        If the file_encoded it's an image you can choose if the image will 
        be embedded in HTML or it will be attached in the email 

    template_name : str -> [Optional, Default: 'default']
        It's the HTML template that will be used. You can find the templates
        availables in the emailManager application.

        1)  Go to: 'emailManager/htmlManager/templates'
    """

    def __init__(
            self,
            name='Senhor(a)',
            recipient: str = '',
            subject: str = 'Hey',
            html_content: str = '',
            file_encoded: str = '',
            file_extension: str = '',
            show_image_in_html: bool = True,
            template_name: str = 'default'):
        """
        Initializes the message instance.
        
        Keyword Arguments: Se in class docstring for more information about the arguments.

            name {str} -- Recipient name. (default: {'Senhor(a)'})
            recipient {str} -- Recipient email. (Required)
            subject {str} -- Email subject (title). (default: {'Hey'})
            html_content {str} -- It's a body message contained in the email html, accepts HTML tags. (default: {''})
            file_encoded {str} -- It's a file to send through the email. (default: {''})
            file_extension {str} -- It's the file extension of the file that you are sending. (Required if file_encoded is not empty)
            show_image_in_html {bool} -- If file_encoded is an image, put in HTML or not. (default: {True})
            template_name {str} -- It's the HTML template that will be used. (default: {'default'})
        """
        super().__init__()

        self.header = Header()
        self.name: str = name
        self.recipient: str = recipient
        self.subject: str = subject
        self.html_content: str = html_content
        self.file_encoded: str = file_encoded
        self.file_extension: str = file_extension
        self.show_image_in_html: bool = show_image_in_html
        self.template_name: str = template_name

    def pack(self) -> list:
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.name),
            self._pack_field(self.recipient),
            self._pack_field(self.subject),
            self._pack_field(self.html_content),
            self._pack_field(self.file_encoded),
            self._pack_field(self.file_extension),
            self._pack_field(self.show_image_in_html),
            self._pack_field(self.template_name),
        ])

        return packed

    def unpack(self, fields, starting_index: int) -> int:
        index = starting_index
        index = self.header.unpack(fields, index)
        self.name = self._unpack_string(fields[index]); index+=1
        self.recipient = self._unpack_string(fields[index]); index+=1
        self.subject = self._unpack_string(fields[index]); index+=1
        self.html_content = self._unpack_string(fields[index]); index+=1
        self.file_encoded = self._unpack_string(fields[index]); index+=1
        self.file_extension = self._unpack_string(fields[index]); index+=1
        self.show_image_in_html = self._unpack_boolean(fields[index]); index+=1
        self.template_name = self._unpack_string(fields[index]); index+=1

        return index

    def __eq__(self, other) -> bool:
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, EmailMessage):
            return \
                self.header == other.header and \
                self.name == other.name and \
                self.recipient == other.recipient and \
                self.subject == other.subject and \
                self.html_content == other.html_content and \
                self.file_encoded == other.file_encoded and \
                self.file_extension == other.file_extension and \
                self.show_image_in_html == other.show_image_in_html and \
                self.template_name == other.template_name
        else:
            return False
