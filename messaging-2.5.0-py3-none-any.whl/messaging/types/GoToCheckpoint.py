#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Checkpoint import Checkpoint

class GoToCheckpoint(Message):
    """Message type implementation to execute an action in the 
    navigation system to move to a checkpoint in the map.

    Attributes
    ----------
    header : Header
        Message's header.

    checkpoint : Checkpoint
        The action checkpoint data.
    """

    def __init__(self, header=Header(), checkpoint=Checkpoint()):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is new instance of 
            Header).

        checkpoint : Checkpoint, optional    
            Is the checkpoint information (default value is new instance
            of Checkpoint).
        """
        super().__init__()
        self.header = header
        self.checkpoint = checkpoint

    
    def pack(self):
        packed = self.header.pack()
        packed.extend(self.checkpoint.pack())
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        index = self.checkpoint.unpack(fields, index)

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, GoToCheckpoint):
            return \
                self.header == other.header and \
                self.checkpoint == other.checkpoint
        else:
            return False