#!/usr/bin/env python

from messaging.message import Message

class AlertDialogOption(Message):
    """Message type implementation for the options settings of the
    AlertDialog.

    Attributes
    ----------
    display_text : str
        The text to be displayed in the option label.

    value : str
        The actual value of the option.
    """

    def __init__(self, display_text='', value=''):
        """Initializes the message instance.

        Parameters
        ----------
        display_text : str, optional
            Is the option display text to set (default is '')

        value : str, optional
            Is the option value to set (default is '')
        """
        super().__init__()

        self.display_text = display_text
        self.value = value


    def pack(self):
        return [
            self._pack_field(self.display_text), 
            self._pack_field(self.value)
        ]


    def unpack(self, fields, starting_index):
        index = starting_index

        self.display_text = self._unpack_string(fields[index]); index+=1
        self.value = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, AlertDialogOption):
            return \
                self.display_text == other.display_text and \
                self.value == other.value
        else:
            return False