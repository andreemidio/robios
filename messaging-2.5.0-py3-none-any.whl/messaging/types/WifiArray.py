#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.WifiAccessPoint import WifiAccessPoint

class WifiArray(Message):
    """Message type implementation with an array of Wi-Fi Access Point
    information.

    Attributes
    ----------
    header : Header
        Message's header.

    array : list
        The list of Wi-Fi access point. See the message type 
        WifiAccessPoint.
    """

    def __init__(self, array=None):
        """Initializes the message instance.

        Parameters
        ----------
        array : list, optional
            Is the list of Wi-Fi Access Point to set (default is 
            None).
        """
        super().__init__()
        
        self.header = Header()
        self.array = array

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_array(self.array))
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.array = self._unpack_array(fields[index], WifiAccessPoint); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, WifiArray):
            return \
                self.header == other.header and \
                self.array == other.array
        else:
            return False