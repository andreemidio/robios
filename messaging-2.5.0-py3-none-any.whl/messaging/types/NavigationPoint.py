#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Vector3 import Vector3

class NavigationPoint(Message):
    """Message type implementation used to determine a point in the navigation system.

    Attributes
    ----------
    position : Vector3
        The position of the point

    orientation : int
        The orientation (direction) of the point.
    """
    
    def __init__(self, position=Vector3(), orientation=0):
        """Initializes the message instance.

        Parameters
        ----------
        position : Vector3, optional
            Is the position to set (default value is a new intance of 
            Vector2).

        orientation : int, optional
            Is the orientation to set (default value is 0).
        """
        super().__init__()
        self.position = position
        self.orientation = orientation

    
    def pack(self):
        packed = []
        packed.extend(self.position.pack())
        packed.append(self._pack_field(self.orientation))
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.position.unpack(fields, index)
        self.orientation = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, NavigationPoint):
            return \
                self.position == other.position and \
                self.orientation == other.orientation
        else:
            return False