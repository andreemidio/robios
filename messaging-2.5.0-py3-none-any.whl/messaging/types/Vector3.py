#!/usr/bin/env python

from messaging.message import Message

class Vector3(Message):
    """ Message type implementation representing a three dimensional
    vector.

    Attributes
    ----------
    x : float
        The x axis value.
    
    y : float
        The y axis value.

    z : float
        The z axis value.
    """
    def __init__(self, x=0.0, y=0.0, z=0.0):
        """Initializes the message instance.

        Parameters
        ----------
        x : float, optional
            Is the x value to set (default is 0.0)
            
        y : float, optional
            Is the t value to set (default is 0.0)

        z : float, optional
            Is the z value to set (default is 0.0)
        """
        super().__init__()
        self.x = x
        self.y = y
        self.z = z

    
    def pack(self):
        return [ 
            self._pack_field(self.x), 
            self._pack_field(self.y), 
            self._pack_field(self.z)
        ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.x = self._unpack_float(fields[index]); index+=1
        self.y = self._unpack_float(fields[index]); index+=1
        self.z = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Vector3):
            return self.x == other.x and self.y == other.y and self.z == other.z
        else:
            return False