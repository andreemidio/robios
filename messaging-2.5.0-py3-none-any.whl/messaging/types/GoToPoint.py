#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.NavigationPoint import NavigationPoint

class GoToPoint(Message):
    """Message type implementation to execute an action in the 
    navigation system to move to a specific point in the map.

    Attributes
    ----------
    header : Header
        Message's header.

    point : NavigationPoint
        The point value for the navigation system. Check the 
        NavigationPoint message type.
    """

    def __init__(self, header=Header(), point=NavigationPoint()):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the message header to set (default value is a new 
            instance of Header).

        point : NavigationPoint, optional
            Is the point information to set (default value is a new
            instance of NavigationPoint).
        """
        super().__init__()
        self.header = header
        self.point = point

    
    def pack(self):
        packed = self.header.pack()
        packed.extend(self.point.pack())
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        index = self.point.unpack(fields, index)

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, GoToPoint):
            return \
                self.header == other.header and \
                self.point == other.point
        else:
            return False