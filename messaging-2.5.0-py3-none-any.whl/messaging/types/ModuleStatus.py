#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class ModuleStatus(Message):
    """Message type implementation of the status of the robot modules.


    Attributes
    ----------
    header : Header
        Message's header.

    module : str
        The modules's name.

    submodule : str
        The submodule's name. This value is used for the status of
        submodules of an specific module. If this field has no value,
        means the status is related specifically for the module.

    sender : str
        Who's sending this status. Generally the module sends its own
        status. But there'll be cases where the module's status will 
        be sent by another application. In thoses cases the name of 
        the other application will be set in this field.

    name : str
        Represents the name of the status that is being sent by the 
        module. It can represent a feature or a resource of the module.

    status : int
        The module's status value.
    """

    def __init__(self, module: str='', submodule: str='', sender: str='',
                name: str='', status: int=0):
        """Initializes the message instance.

        Parameters
        ----------

        module : str, optional
            Is the module name to set (default value is '').

        submodule : str, optional
            Is the submodule name to set (default value is '').

        sender : str, optional
            Is the sender value to set (default value is '').

        name : str, optional
            Is the name of the status to set (default value is '').

        status : int, optional
            Is the actual status value to set (default value is -1).
        """
        super().__init__()

        self.header = Header()
        self.module = module
        self.submodule = submodule
        self.sender = sender
        self.name = name
        self.status = status


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([ 
            self._pack_field(self.module),
            self._pack_field(self.submodule),
            self._pack_field(self.sender),
            self._pack_field(self.name), 
            self._pack_field(self.status)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.module = self._unpack_string(fields[index]); index+=1
        self.submodule = self._unpack_string(fields[index]); index+=1
        self.sender = self._unpack_string(fields[index]); index+=1
        self.name = self._unpack_string(fields[index]); index+=1
        self.status = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ModuleStatus):
            return \
                self.header == other.header and \
                self.module == other.module and \
                self.submodule == other.submodule and \
                self.sender == other.sender and \
                self.name == other.name and \
                self.status == other.status
        else:
            return False