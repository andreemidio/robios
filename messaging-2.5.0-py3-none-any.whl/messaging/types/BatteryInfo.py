#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class BatteryInfo(Message):
    '''Message type implementation that carries information about
    the battery status.

    Attributes
    ----------
    header : Header
        Message's header.

    level : float
        The current level of the battery.

    voltage : float
        The current voltage of the battery.
    '''
    def __init__(self, header=None, level=0.0, voltage=0.0):
        '''Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is None).

        level : float, optional
            Is the battery level value to set (default value is 0.0).

        voltage : float, optional
            Is the battery volta value to set (default value is 0.0).
        '''
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header

        self.level = level
        self.voltage = voltage

    

    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.level))
        packed.append(self._pack_field(self.voltage))

        return packed


    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.level = self._unpack_float(fields[index]); index+=1
        self.voltage = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, BatteryInfo):
            return \
                self.header == other.header and \
                self.level == other.level and \
                self.voltage == other.voltage
        else:
            return False
