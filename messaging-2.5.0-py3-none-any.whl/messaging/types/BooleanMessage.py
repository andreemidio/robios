#!/usr/bin/env python

from messaging.message import Message
from messaging.utils.type_utils import parse_bool

class BooleanMessage(Message):
    """Message type implementation of bool content.
    
    Attributes
    ----------
    data : bool
        The bool data of the message.
    """

    def __init__(self, data=False):
        """Initializes the message instance.

        Parameters
        ----------
        data : bool, optional
            Is the bool value to set (default is False).
        """
        super().__init__()

        self.data = data

    
    def pack(self):
        return [ self._pack_field(self.data) ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.data = parse_bool(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, BooleanMessage):
            return self.data == other.data
        else:
            return False