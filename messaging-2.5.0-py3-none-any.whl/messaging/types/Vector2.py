#!/usr/bin/env python

from messaging.message import Message

class Vector2(Message):
    """ Message type implementation representing a two dimensional
    vector.

    Attributes
    ----------
    x : float
        The x axis value.
    
    y : float
        The y axis value.
    """
    def __init__(self, x=0.0, y=0.0):
        """Initializes the message instance.

        Parameters
        ----------
        x : float, optional
            Is the x value to set (default is 0.0)
            
        y : float, optional
            Is the t value to set (default is 0.0)
        """
        super().__init__()
        self.x = x
        self.y = y

    
    def pack(self):
        return [ 
            self._pack_field(self.x),
            self._pack_field(self.y) 
        ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex
        
        self.x = self._unpack_float(fields[index]); index+=1
        self.y = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Vector2):
            return self.x == other.x and self.y == other.y
        else:
            return False