#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class SpeakMessage(Message):
    """Message type implementation of Speak action used by the robot's 
    Text To Speech system.
    
    Attributes
    ----------
    header : Header
        Message's header.

    text : str
        The text to be spoken.

    utterance_id : str
        The id associated with the text.
    """ 

    def __init__(self, header: Header=None, text: str='', utterance_id: str=''):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is a new instance of 
            Header).
            
        text : str, optional
            Is the text to be spoken by the robot (default value is '').

        utterance_id : str, optional
            Is the id of the text to be spoken (default value is '').
        """
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header
            
        self.text = text
        self.utterance_id = utterance_id

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.text),
            self._pack_field(self.utterance_id)
        ])

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.text = self._unpack_string(fields[index]); index+=1
        self.utterance_id = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, SpeakMessage):
            return \
                self.header == other.header and \
                self.text == other.text and \
                self.utterance_id == other.utterance_id
        else:
            return False