#!/usr/bin/env python

import time
from datetime import datetime
from messaging.message import Message

class Header(Message):
    """Message type implementation representing header data for other
    messages.

    Attributes
    ----------
    timestamp : int
        The timestamp of the message.
    """

    def __init__(self, timestamp=None):
        """Initializes the message instance.

        Parameters
        ----------
        timestamp : int, optional
            Is the timestamp to set (default value is None).
        """
        super().__init__()

        if timestamp == None:
            self.timestamp = int(datetime.now().timestamp() * 1000)
        else:
            self.timestamp = timestamp

    
    def pack(self):
        return [ self._pack_field(self.timestamp) ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.timestamp = self._unpack_int(fields[index]); index+=1

        return index

    
    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Header):
            return self.timestamp == other.timestamp
        else:
            return False