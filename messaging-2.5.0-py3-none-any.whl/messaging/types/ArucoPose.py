#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Vector3 import Vector3

class ArucoPose(Message):
    """Message type implementation representing Aruco Markers 
    information.
    
    Attributes
    ----------
    id : str
        The Aruco Marker's ID.

    position : Vector3
        The Aruco Marker's position in the map.

    orientation : int
        The Aruco Marker's orientation in the map.
    """

    def __init__(self, id: str='', position: Vector3=None, orientation: int=0):
        """Initializes the message instance.

        Parameters
        ----------
        id : str, optional
            Is the Aruco Marker ID to set (default value is '').

        position : Vector3
            Is the Aruco Marker position to set (default value is a new
            instance of Vector3).

        orientation : int
            Is the Aruco Marker orientation to set (default value is 0)
        """
        super().__init__()

        self.id = id
        self.position = Vector3() if position is None else position
        self.orientation = orientation

    
    def pack(self):
        packed = [self._pack_field(self.id)]
        packed.extend(self.position.pack())
        packed.append(self._pack_field(self.orientation))

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.id = self._unpack_string(fields[index]); index+=1
        index = self.position.unpack(fields, index)
        self.orientation = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ArucoPose):
            return  self.id == other.id and \
                    self.position == other.position and \
                    self.orientation == other.orientation
        else:
            return False