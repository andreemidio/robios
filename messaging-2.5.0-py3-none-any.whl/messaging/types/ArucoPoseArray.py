#!/usr/bin/env python

from typing import List

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.ArucoPose import ArucoPose

class ArucoPoseArray(Message):
    """Message type implementation containing an array of Aruco Markers
    with a header. 
    
    Attributes
    ----------
    header : Header
        The message's header.

    arucos : List[ArucoPose]
        The list of Aruco Markers.
    """

    def __init__(self, header: Header=Header(), arucos: List[ArucoPose]=[]):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is message header to set (default value is a new instance of
            Header).

        arucos : Vector3
            Is the list of Aruco Markers to set (default value is []).
        """
        super().__init__()

        self.header = header
        self.arucos = arucos

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_array(self.arucos))

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.arucos = self._unpack_array(fields[index], ArucoPose); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ArucoPoseArray):
            return  \
                self.header == other.header and \
                self.arucos == other.arucos
        else:
            return False