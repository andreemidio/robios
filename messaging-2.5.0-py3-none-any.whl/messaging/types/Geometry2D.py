#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Vector2 import Vector2

class Geometry2D(Message):
    """Message type implementation for 2D Geometry definition.

    It is used to store data of position and size in 2D vectors.

    Attributes
    ----------
    position : Vector2
        The position value, in a 2D vector.

    size : Vector2
        The size value, in a 2D vector. The x value represents the witdh
        and the y value represents the height.
    """

    def __init__(self, position=None, size=None):
        """Initializes the message instance.

        Parameters
        ----------
        position : Vector2, optional
            Is the position value to set (default value is None).

        size : Vector2, optional
            Is the size value to set (default value is None).
        """
        super().__init__()
        if position == None:
            self.position = Vector2()
        else:
            self.position = position

        if size == None:
            self.size = Vector2()
        else:
            self.size = size

    
    def pack(self):
        packed = []
        packed.extend(self.position.pack())
        packed.extend(self.size.pack())

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.position.unpack(fields, index)
        index = self.size.unpack(fields, index)

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Geometry2D):
            return self.position == other.position and self.size == other.size
        else:
            return False