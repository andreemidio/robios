#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class SpeakCallback(Message):
    """Message type implementation of the robot Text To Speech system
    callback.

    Constants
    ----------
    EVENT_STARTED : str
        Event when the robot starts speaking.
    
    EVENT_DONE : str
        Eent when the robot finishes speaking.

    EVENT_STOP : str
        Event when the robot speaking is stopped while in progress like
        getting interrupted.
    
    EVENT_ERROR : str
        Event when the robot fails or stops speaking due and error.

    Attributes
    ----------
    header : Header
        Message's header

    event : str
        The callback event of the Text To Speech System. Check the 
        constants for the available events.

    utterance_id : str
        The id of the sentence this callback is related to.

    text: str
        The speak text this callback is related to.
    """

    EVENT_STARTED: str = 'onSpeakStart'
    EVENT_DONE: str = 'onSpeakDone'
    EVENT_STOP: str = 'onSpeakStop'
    EVENT_ERROR: str = 'onSpeakError'
    
    def __init__(self,header: Header=None, event: str='', utterance_id: str='', text: str=''):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the message header to set (default value is a new 
            instance of Header).
            
        event : str, optional
            Is the event to set. (default value is ''). 
            
            Check the constants for the available events.

        utterance_id : str, optional
            Is the speak text id to set (default value is '').

        text : str, optional
            Is the speak text to set (default value is '')
        """
        super().__init__()

        if header == None:
            self.header = Header()
        else:
            self.header = header
        self.event = event
        self.utterance_id = utterance_id
        self.text = text


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.event),
            self._pack_field(self.utterance_id),
            self._pack_field(self.text)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.event = self._unpack_string(fields[index]); index+=1
        self.utterance_id = self._unpack_string(fields[index]); index+=1
        self.text = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, SpeakCallback):
            return \
                self.header == other.header and \
                self.event == other.event and \
                self.utterance_id == other.utterance_id and \
                self.text == other.text

        else:
            return False