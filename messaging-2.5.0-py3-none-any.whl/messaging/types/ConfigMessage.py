#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.utils.type_utils import parse_bool

class ConfigMessage(Message):
    """Message type implementation to share an store all robot 
    configurations. Basically, is used by the Config Manager Module to
    send configs to other modules.

    Example:

    key = robot.joystick.config.buttons.mapping.r1+left
    value = script1

    Attributes
    ----------
    header : Header
        Message's header

    id : str
        Internal id of the config

    key : str
        The config key.

        Example: robot.joystick.config.buttons.mapping.r1+left

    value : str
        The value of the config.

        Example: script1

    value_type : str
        The type of the value (int, float, string, ...)

    active : bool
        Indicates if the config is activated.

    created : int
        A timestamp when the config has been created.

    updated : int
        A timestamp when the config has been updated.

    updated_by : str
        Who updated the config.
    """

    def __init__(self, id='', key='', value='', value_type='string', active=False, created=0, updated=0, updated_by=''):
        """Initializes the message instance.

        Parameters
        ----------
        id : str, optional
            Is the config's internal ID to set (default value is '').

        key : str, optional
            Is the name of the configuration to set (default value is '').

        value : str, optional
            Is the configuration value to set (default value is '').

        value_type : str, optional
            Is the type of the configuration value to set (default value
            is '').

        active : bool, optional
            Is the active value to set (default value is False).

        created : int, optional
            Is the timestamp when the configuration has been created to
            set (default value is 0).

        updated : int, optional
            Is the timestamp when the configuration has been updated to
            set (default value is 0).

        updated_by : str, optional
            Is the name of who updated the configuration last time to 
            set (default value is '').

        """
        super().__init__()
        self.header = Header()
        self.id = id
        self.key = key
        self.value = value
        self.value_type = value_type
        self.active = active
        self.created = created
        self.updated = updated
        self.updated_by = updated_by


    def pack(self):
        packed = self.header.pack()
        packed.extend([
            self._pack_field(self.id),
            self._pack_field(self.key),
            self._pack_field(self.value),
            self._pack_field(self.value_type),
            self._pack_field(self.active),
            self._pack_field(self.created),
            self._pack_field(self.updated),
            self._pack_field(self.updated_by)
        ])

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.id = self._unpack_string(fields[index]); index+=1
        self.key = self._unpack_string(fields[index]); index+=1
        self.value = self._unpack_string(fields[index]); index+=1
        self.value_type = self._unpack_string(fields[index]); index+=1
        self.active = self._unpack_boolean(fields[index]); index+=1
        self.created = self._unpack_int(fields[index]); index+=1
        self.updated = self._unpack_int(fields[index]); index+=1
        self.updated_by = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ConfigMessage):
            return \
                self.id == other.id and \
                self.key == other.key and \
                self.value == other.value and \
                self.value_type == other.value_type and \
                self.active == other.active and \
                self.created == other.created and \
                self.updated == other.updated and \
                self.updated_by == other.updated_by
        else:
            return False