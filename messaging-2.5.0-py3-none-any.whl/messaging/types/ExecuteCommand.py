#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class ExecuteCommand(Message):
    """Message type implementation to execute actions and commands in
    the Robios Head App.

    Attributes
    ----------
    header : Header
        Message's header.

    id : str
        The ID of the command to be executed in the target.

    parameters : list
        Additional parameters to send along with the command. The type 
        and amount of parameters depends on the system that will be 
        receiving the message.
    """

    def __init__(self, id='', parameters=[]):
        """Initializes the message instance.

        Parameters
        ----------
        id : str, optional
            Is the command id to set (default value is '').

        execution_parameter : str, optional
            Is the extras parameters for the command to set (default
            value is []).
        """
        super().__init__()

        self.header = Header()
        self.id = id
        self.parameters = parameters


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.id), 
            self._pack_array(self.parameters)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.id = self._unpack_string(fields[index]); index+=1
        self.parameters = self._unpack_array(fields[index], str); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ExecuteCommand):
            return \
                self.header == other.header and \
                self.id == other.id and \
                self.parameters == other.parameters
        else:
            return False