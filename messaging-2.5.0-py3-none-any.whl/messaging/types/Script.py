#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class Script(Message):
    """Message type implementation of action for the robot Script 
    System.

    Constants
    ----------
    ACTION_ADD : str
        Action to add a script in the Script System's execution queue.

    ACTION_PAUSE : str
        Action to pause the current script in the Script System.

    ACTION_RESUME : str
        Action to resume the execution of the current script in the 
        Script System.

    ACTION_STOP : str
        Action to stop the execution of the current script in the Script
        System.

    ACTION_CLEAR : str
        Action to clear the Script System's execution queue.

    Attributes
    ----------
    header : Header
        Message's header.

    action : str
        The action for the Script System. Check the constants for the 
        available actions.

    action_parameter : str
        An additional parameter for the action.
    """

    ACTION_ADD = 'add'
    ACTION_PAUSE = 'pause'
    ACTION_RESUME = 'resume'
    ACTION_STOP = 'stop'
    ACTION_CLEAR = 'clear'

    def __init__(self, action='', action_parameter=''):
        """Initializes the message instance.

        Parameters
        ----------
        action : str, optional
            Is the action to set. Cehck the constatns for the available
            actions (default value is '').

        action_parameter : str, optional
            Is the additional parameter for the action (default value 
            is '').
        """
        super().__init__()

        self.header = Header()
        self.action = action
        self.action_parameter = action_parameter


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([ 
            self._pack_field(self.action), 
            self._pack_field(self.action_parameter) 
        ])

        return packed
    

    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.action = self._unpack_string(fields[index]); index+=1
        self.action_parameter = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Script):
            return \
                self.header == other.header and \
                self.action == other.action and \
                self.action_parameter == other.action_parameter
        else:
            return False