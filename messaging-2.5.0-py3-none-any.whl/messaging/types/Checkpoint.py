#!/usr/bin/env python

from messaging.message import Message
from messaging.types.NavigationPoint import NavigationPoint

class Checkpoint(Message):
    """Message type implementation for the Checkpoint data used in the
    Navigation System.

    Constants 
    ----------
    CATEGORY_ARUCO : str
        Point category for Aruco Markers

    CATEGORY_CHECKPOINT : str
        Point category for Checkpoints

    CATEGORY_CHECKPOINT : str
        Point category for checkpoints used to localize the robot.

    CATEGORY_DOOR : str
         Point category for Door points.
    
    Attributes
    ----------
    name : str
        The checkpoint's name.

    description : str
        The checkpoint's description.

    world : str
        The name of the World this checkpoint is in.

    category : str
        The category this points represents in the world it is 
        associated to. Check the constants for the available
        values.

    aruco_id : str
        The ID of the Aruco Marker in the Navigation System. It
        is only used for the points of category CATEGORY_ARUCO.

    point : NavigationPoint
        The coordinates of the checkpoint.
    """
    CATEGORY_ARUCO = 'aruco'
    CATEGORY_CHECKPOINT = 'checkpoint'
    CATEGORY_LOCALIZATION = 'localization'
    CATEGORY_DOOR = 'door'


    def __init__(self, name='', description='', world='', category='checkpoint', aruco_id='', point=NavigationPoint()):
        """Initializes the message instance.

        Parameters
        ----------
        name : str, optional
            Is the checkpoint's name to set (default value is '').

        description: str, optional
            Is the checkpoint's description to set (default value is '')

        world : str, optional
            Is the checkpoint's world to set (default value is '').

        category : str, optional
            Is the point's category to set (default value is CATEGORY_CHECKPOINT).

        aruco_id : str, optional
            Is the Aruco Marker's ID to set (default value is '').

        point : NavigationPoint, optional
            is the checkpoint's coordinates to set (default value is a
            new instance of NavigationPoint with default values).
        """
        super().__init__()
        self.name = name
        self.description = description
        self.world = world
        self.category = category
        self.aruco_id = aruco_id
        self.point = point

    
    def pack(self):
        packed = [ 
            self._pack_field(self.name),
            self._pack_field(self.description), 
            self._pack_field(self.world), 
            self._pack_field(self.category), 
            self._pack_field(self.aruco_id)
        ]
        packed.extend(self.point.pack())
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.name = self._unpack_string(fields[index]); index+=1
        self.description = self._unpack_string(fields[index]); index+=1
        self.world = self._unpack_string(fields[index]); index+=1
        self.category = self._unpack_string(fields[index]); index+=1
        self.aruco_id = self._unpack_string(fields[index]); index+=1
        index = self.point.unpack(fields, index)

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Checkpoint):
            return \
                self.name == other.name and \
                self.description == other.description and \
                self.world == other.world and \
                self.point == other.point
        else:
            return False