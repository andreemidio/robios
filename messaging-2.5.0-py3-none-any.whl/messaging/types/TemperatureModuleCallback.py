#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class TemperatureModuleCallback(Message):
    """Message type implementation of the partial and final results of 
    the temperature module.

    Constants
    ----------
    STATUS_DEACTIVATED : int
        Status indicating the temperature module is deactivated.
    
    STATUS_DETECTION_WAITING : int
        Status indicating the module is waiting for the person to move
        the wrist close enouth to be able to detect its temperature. The
        range of the distance required to start detecting the 
        temperature is defined by the 'minDetectionDistance' and
        'maxDetectionDistance' variables.

    STATUS_DETECTING : int
        Status indicating the module is currently detecting the 
        temperature.
    
    STATUS_DETECTION_DONE : int
        Status indicating the detection has been done successfully.

    Attributes
    ----------
    header : Header
        Message's header

    state : int
        Current status of the Temperature Module.

    distance : int
        Current detected distance.

    min_detection_distance : int
        Minimum distance required to detect the temperature.

    max_detection_distance : int
        Maximum distance allowed to detect the temperature.

    person_temperature : float
        The result value of the detected temperature of the person.

    environment_temperature : float
        The result value of the detected temperature of the environment.
    """

    STATUS_DEACTIVATED: int = 1
    STATUS_DETECTION_WAITING: int = 2
    STATUS_DETECTING: int = 3
    STATUS_DETECTING: int = 4
    
    def __init__(self, header: Header=None, status: int=0, distance: int=-1, min_detection_distance: int=-1, max_detection_distance: int=-1, person_temperature: float=0.0, environment_temperature: float=0.0):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the message header to set (default value is a new 
            instance of Header).
            
        status : int, optional
            Is the module status to set. (default value is 0). 
            
            Check the constants for the available events.

        distance : int, optional
            Is the current distance to set (default value is -1).

        min_detection_distance : int, optional
            Is the min distance to set (default value is -1).
            
        max_detection_distance : int, optional
            Is the max distance to set (default value is -1).

        person_temperature : float, optional
            Is person temperature to set (default value is 0.0).

        environment_temperature : float, optional
            Is environment temperature to set (default value is 0.0).
        """
        super().__init__()

        if header == None:
            self.header = Header()
        else:
            self.header = header
        self.status = status
        self.distance = distance
        self.min_detection_distance = min_detection_distance
        self.max_detection_distance = max_detection_distance
        self.person_temperature = person_temperature
        self.environment_temperature = environment_temperature


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.status),
            self._pack_field(self.distance),
            self._pack_field(self.min_detection_distance),
            self._pack_field(self.max_detection_distance),
            self._pack_field(self.person_temperature),
            self._pack_field(self.environment_temperature)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.status = self._unpack_int(fields[index]); index+=1
        self.distance = self._unpack_int(fields[index]); index+=1
        self.min_detection_distance = self._unpack_int(fields[index]); index+=1
        self.max_detection_distance = self._unpack_int(fields[index]); index+=1
        self.person_temperature = self._unpack_float(fields[index]); index+=1
        self.environment_temperature = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, TemperatureModuleCallback):
            return \
                self.header == other.header and \
                self.status == other.status and \
                self.distance == other.distance and \
                self.min_detection_distance == other.min_detection_distance and \
                self.max_detection_distance == other.max_detection_distance and \
                self.person_temperature == other.person_temperature and \
                self.environment_temperature == other.environment_temperature

        else:
            return False