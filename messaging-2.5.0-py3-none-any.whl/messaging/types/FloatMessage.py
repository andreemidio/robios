#!/usr/bin/env python

from messaging.message import Message

class FloatMessage(Message):
    """Message type implementation of float content.
    
    Attributes
    ----------
    data : float
        The float data of the message.
    """
    def __init__(self, data=0.0):
        """Initializes the message instance.

        Parameters
        ----------
        data : float, optional
            Is the float value to set (default is 0.0).
        """
        super().__init__()

        self.data = data

    
    def pack(self):
        return [ self._pack_field(self.data) ]

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.data = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, FloatMessage):
            return self.data == other.data
        else:
            return False