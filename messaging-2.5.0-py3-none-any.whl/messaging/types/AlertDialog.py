#!/usr/bin/env python

from messaging.utils.type_utils import parse_bool
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.AlertDialogInput import AlertDialogInput
from messaging.types.AlertDialogOption import AlertDialogOption
from messaging.types.FaceDisplaySettings import FaceDisplaySettings


class AlertDialog(Message):
    """ Message type implementation to send Alert Dialog to the Robios
    Head application.

    Constants
    ----------
    MEDIA_TYPE_NONE : int
        Constant for an AlertDialog without any type of media to be 
        displayed.

    MEDIA_TYPE_IMAGE : int
        Constant for an AlertDialog that displays an image as media.

    MEDIA_TYPE_VIDEO : int
        Constant for an AlertDialog that displays a video as 
        media.

    REPLACE_ALLOWED : int
        Allows the current AlertDialog to be replaced when another
        dialog is received.

    REPLACE_LOCKED : int
        Locks the current AlertDialog so it can't be replaced by 
        another one. The other one is ignored, in this case.

    TYPE_INFO : str
        AlertDialog type to simply show an information.

    TYPE_CONFIRM : str
        AlertDialog type to ask for the user confirmation.

    TYPE_INPUT : str
        AlertDialog type for displaying an input field to be typed by
        the user.
    TYPE_OPTIONS : str
        AlertDialog type for displaying custom options to the user.

    TYPE_BARCODE : str
        AlertDialog type for displaying a Barcode/QR Code reader to the
        user.
    
    SUBTYPE_TEXT : str
        A subtype to format the input field for text. Used together with
        TYPE_INPUT.

    SUBTYPE_NUMBER : str
        A subtype to format the input field for number. Used together 
        with TYPE_INPUT.

    SUBTYPE_EMAIL : str
        A subtype to format the input field for e-mails. Used together 
        with TYPE_INPUT.

    RESULT_TYPE_TEXT : str
        Simple text result type.

    RESULT_TYPE_DIALOG_INPUT : str
        Result type to perform a dialog input. The dialog input is used
        by the Dialog Sytem as a phrase said by the user.

    RESULT_TYPE_SCRIPT : str
        Result type to run a script. The dialog result is used by the 
        Script Runner System to run a script.


    Attributes
    ----------
    header : Header
        Message's header.

    id : str
        Dialog ID.

    title : str
        Dialog Title.

    description : str
        Dialog Description.

    validation : str
        The validation message for the dialog.

    media_type : str
        The type of media to be displayed.

    media_url : str
        The URL of the media to be displayed.

    media_audio_enabled : bool
        Defines if the audio of the media will be played.

    media_loop : bool
        Defines if the media will play in loop.
    
    required : bool
        Defines if a result for the dialog is required. 
        It show the validation message if no result is supplied.

    replacement : int
        The replacement criteria. Check the constants of the class
        for possible values.

    timeout : int
        Determines how long the dialog are going to be displayed (in
        seconds).

    timeout_with_video : bool
        Determines if the dialog should be closed when the video 
        finishes playing. The dialog is going to be cancelled when 
        getting closed by timeout.
        This attribute is only when the media_type is set as
        MEDIA_TYPE_VIDEO.

    dialog_type : str
        The dialog type.

    subtype : str
        The dialog subtype.

    result_type : str
        The Result's type.

    confirm_result : str
        The value of the result if the user press the Cofirm Button.

    cancel_result : str
        The value of the result if the user press the Cancel Button.

    display_title : bool
        Defines if the Title should be displayed in the screen.

    display_description : bool
        Defines if the Description should be displayed in the screen.

    speak_title : bool
        Defines if the robot will speak the text of the Title.

    speak_description : bool
        Defines if the robot will speak the text of the Description.

    input : AlertDialogInput
        The settings for the Input Field to be displayed. Used only when
        the type is TYPE_INPUT.

    options : list
        The settings for the Options of the dialog. Used only when the 
        type is TYPE_OPTIONS.

    face_display : FaceDisplaySettings
        The settings of how the face will be displayed in the Alert 
        Dialog.

    """
    MEDIA_TYPE_NONE = 0
    MEDIA_TYPE_IMAGE = 1
    MEDIA_TYPE_VIDEO = 2

    REPLACE_ALLOWED = 0
    REPLACE_LOCKED = 1

    TYPE_INFO = 'info'
    TYPE_CONFIRM = 'confirm'
    TYPE_INPUT = 'input'
    TYPE_OPTIONS = 'options'
    TYPE_BARCODE = 'barcode'
    
    SUBTYPE_TEXT = 'text'
    SUBTYPE_NUMBER = 'number'
    SUBTYPE_EMAIL = 'email'

    RESULT_TYPE_TEXT = 'text'
    RESULT_TYPE_DIALOG_INPUT = 'dialog_input'
    RESULT_TYPE_SCRIPT = 'script'

    def __init__(self, title='', description=''):
        """Initializes the message instance.

        Parameters
        ----------
        title : str, optional
            The AlertDialog's title to set (default is '').

        description : str, optional
            The AlertDialog's description to set (default is '').
        """
        super().__init__()

        self.header = Header()
        self.id = ''
        self.title = title
        self.description = description
        self.validation = ''
        self.media_type = AlertDialog.MEDIA_TYPE_NONE
        self.media_url = ''
        self.media_audio_enabled = True
        self.media_loop = False
        self.required = False
        self.replacement = AlertDialog.REPLACE_ALLOWED
        self.timeout = 0
        self.timeout_with_video = False
        self.dialog_type = ''
        self.subtype = ''
        self.result_type = AlertDialog.RESULT_TYPE_TEXT
        self.confirm_result = ''
        self.cancel_result = ''
        self.display_title = True
        self.display_description = True
        self.speak_title = True
        self.speak_description = False
        self.input = AlertDialogInput()
        self.options = None
        self.face_display = FaceDisplaySettings()


    def pack(self):
        packed = []

        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.id),
            self._pack_field(self.title),
            self._pack_field(self.description),
            self._pack_field(self.validation),
            self._pack_field(self.media_type),
            self._pack_field(self.media_url),
            self._pack_field(self.media_audio_enabled),
            self._pack_field(self.media_loop),
            self._pack_field(self.required),
            self._pack_field(self.replacement),
            self._pack_field(self.timeout),
            self._pack_field(self.timeout_with_video),
            self._pack_field(self.dialog_type),
            self._pack_field(self.subtype),
            self._pack_field(self.result_type),
            self._pack_field(self.confirm_result),
            self._pack_field(self.cancel_result),
            self._pack_field(self.display_title),
            self._pack_field(self.display_description),
            self._pack_field(self.speak_title),
            self._pack_field(self.speak_description)
        ])
        packed.extend(self.input.pack())
        packed.append(self._pack_array(self.options))
        packed.extend(self.face_display.pack())

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.id = self._unpack_string(fields[index]); index+=1
        self.title = self._unpack_string(fields[index]); index+=1
        self.description = self._unpack_string(fields[index]); index+=1
        self.validation = self._unpack_string(fields[index]); index+=1
        self.media_type = self._unpack_int(fields[index]); index+=1
        self.media_url = self._unpack_string(fields[index]); index+=1
        self.media_audio_enabled = self._unpack_boolean(fields[index]); index+=1
        self.media_loop = self._unpack_boolean(fields[index]); index+=1
        self.required = self._unpack_boolean(fields[index]); index+=1
        self.replacement = self._unpack_int(fields[index]); index+=1
        self.timeout = self._unpack_int(fields[index]); index+=1
        self.timeout_with_video = self._unpack_boolean(fields[index]); index+=1
        self.dialog_type = self._unpack_string(fields[index]); index+=1
        self.subtype = self._unpack_string(fields[index]); index+=1
        self.result_type = self._unpack_string(fields[index]); index+=1
        self.confirm_result = self._unpack_string(fields[index]); index+=1
        self.cancel_result = self._unpack_string(fields[index]); index+=1
        self.display_title = self._unpack_boolean(fields[index]); index+=1
        self.display_description = self._unpack_boolean(fields[index]); index+=1
        self.speak_title = self._unpack_boolean(fields[index]); index+=1
        self.speak_description = self._unpack_boolean(fields[index]); index+=1
        index = self.input.unpack(fields, index)
        self.options = self._unpack_array(fields[index], AlertDialogOption); index+=1
        index = self.face_display.unpack(fields, index)

        return index

    
    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, AlertDialog):
            return \
                self.header == other.header and \
                self.id == other.id and \
                self.title == other.title and \
                self.description == other.description and \
                self.validation == other.validation and \
                self.media_type == other.media_type and \
                self.media_url == other.media_url and \
                self.media_audio_enabled == other.media_audio_enabled and \
                self.media_loop == other.media_loop and \
                self.required == other.required and \
                self.replacement == other.replacement and \
                self.timeout == other.timeout and \
                self.timeout_with_video == other.timeout_with_video and \
                self.dialog_type == other.dialog_type and \
                self.subtype == other.subtype and \
                self.result_type == other.result_type and \
                self.confirm_result == other.confirm_result and \
                self.cancel_result == other.cancel_result and \
                self.display_title == other.display_title and \
                self.display_description == other.display_description and \
                self.speak_title == other.speak_title and \
                self.speak_description == other.speak_description and \
                self.input == other.input and \
                self.options == other.options and \
                self.face_display == other.face_display
        else:
            return False