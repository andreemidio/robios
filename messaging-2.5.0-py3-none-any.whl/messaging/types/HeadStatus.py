#!/usr/bin/env python

from messaging.utils.type_utils import parse_bool
from messaging.message import Message
from messaging.types.Header import Header

class HeadStatus(Message):
    """ Message type implementation with the current status of the 
    Robios Head Application.

    It indicates if the robot is speaking, what is his current 
    expression, the last performed action, the current open internal
    application and the level of the head's device battery.

    Attributes
    ----------
    header : Header
        Message's header.

    speaking : bool
        Indicates if the robot is speaking.

    expression : str
        The current face expression.

    action : str
        The performed action in the Head App.

    current_internal_app : str
        Current open internal application.

    battery_level : int
        The device's battery level.

    is_alert_dialog_open : bool
        Idicates if the Alert Dialog is open in the Robiso Face app.
    """

    def __init__(self, speaking=False, expression='', action='', current_internal_app='', battery_level=0, is_alert_dialog_open=False):
        """Initializes the message instance.

        Parameters
        ----------
        speaking : bool, optional
            Is the speaking value to set (default value is False).

        expression : str, optional
            Is the face expression to set (default value is '').
        
        action : str, optional
            Is the action to set (default value is '').

        current_internal_app : str, optional
            Is the current internal app to set (default value is '').

        battery_level : int, optional
            Is the device's battery level to set (default value is 0).

        is_alert_dialog_open : bool, optional
            Is the value indicating if the Alert Dialog is currently
            open (default value is False).
        """
        super().__init__()

        self.header = Header()
        self.speaking = speaking
        self.expression = expression
        self.action = action
        self.current_internal_app = current_internal_app
        self.battery_level = battery_level
        self.is_alert_dialog_open = is_alert_dialog_open


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.speaking),
            self._pack_field(self.expression),
            self._pack_field(self.action),
            self._pack_field(self.current_internal_app),
            self._pack_field(self.battery_level),
            self._pack_field(self.is_alert_dialog_open)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.speaking = self._unpack_boolean(fields[index]); index+=1
        self.expression = self._unpack_string(fields[index]); index+=1
        self.action = self._unpack_string(fields[index]); index+=1
        self.current_internal_app = self._unpack_string(fields[index]); index+=1
        self.battery_level = self._unpack_int(fields[index]); index+=1
        self.is_alert_dialog_open = self._unpack_boolean(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, HeadStatus):
            return \
                self.header == other.header and \
                self.speaking == other.speaking and \
                self.expression == other.expression and \
                self.action == other.action and \
                self.current_internal_app == other.current_internal_app and \
                self.battery_level == other.battery_level and \
                self.is_alert_dialog_open == other.is_alert_dialog_open
        else:
            return False