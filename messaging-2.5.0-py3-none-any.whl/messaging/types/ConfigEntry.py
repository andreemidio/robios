#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.ConfigKey import ConfigKey


class ConfigEntry(Message):
    '''Message type implementation of a robot configuration entry.

    Constants
    ----------
    TYPE_BOOLEAN : str
        Configuration with boolean type.

    TYPE_DECIMAL : str
        Configuration with decimal type, like a float or double.

    TYPE_INT : str
        Configuration with integer type.

    TYPE_JSON : str
        Configuration with JSON type.

    TYPE_STRING : str
        Configuration with string type.

    TYPE_XML : str
        Configuration with XML type.

    Attributes
    ----------
    description : str
        The configuration entry description text.

    value_type : str
        The value type of the configuration entry.

    value : str
        The actual value data of the configuration entry.

    robot_id : str
        The robot ID the configuration entry belongs to.

    application_id : str 
        The application ID the configuration entry belongs to.
    '''

    TYPE_BOOLEAN: str = 'boolean'
    TYPE_DECIMAL: str = 'decimal'
    TYPE_INT: str = 'int'
    TYPE_JSON: str = 'json'
    TYPE_STRING: str =  'string'
    TYPE_XML: str = 'xml'

    def __init__(self, header: Header=None, key: ConfigKey=None, description: str='', value_type: str='string', value: str='', robot_id: str='', application_id: str=''):
        '''Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the message header to set (default value is a
            new instance of Header)

        key : ConfigKey, optional
            Is the configuration key to set (default value is a
            new instance of ConfigKey)

        description : str, optional
            Is the configuration description to set (default value is '')

        value_type : str, optional
            Is the configuration value type to set (default value is 'string')

        value : str, optional
            Is the configuration actual value to set (default value is '')

        robot_id : str, optional
            Is the robot ID of the configuration entry to set (default 
            value is '')

        application_id : str, optional
            Is the application ID of the configuration entry to set (default
            value is '')
        '''
        super().__init__()
        if header:
            self.header = header
        else:
            self.header = Header()

        if key: 
            self.key = key 
        else: 
            self.key = ConfigKey()

        self.description = description
        self.value_type = value_type
        self.value = value
        self.robot_id = robot_id
        self.application_id = application_id



    def pack(self):
        packed = self.header.pack()
        packed.extend(self.key.pack())
        packed.extend([
            self._pack_field(self.description),
            self._pack_field(self.value_type),
            self._pack_field(self.value),
            self._pack_field(self.robot_id),
            self._pack_field(self.application_id)
        ])

        return packed


    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        index = self.key.unpack(fields, index)
        self.description = self._unpack_string(fields[index]); index+=1
        self.value_type = self._unpack_string(fields[index]); index+=1
        self.value = self._unpack_string(fields[index]); index+=1
        self.robot_id = self._unpack_string(fields[index]); index+=1
        self.application_id = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ConfigEntry):
            return \
                self.header == other.header and \
                self.key == other.key and \
                self.description == other.description and \
                self.value_type == other.value_type and \
                self.value == other.value and \
                self.robot_id == other.robot_id and \
                self.application_id == other.application_id
        else:
            return False