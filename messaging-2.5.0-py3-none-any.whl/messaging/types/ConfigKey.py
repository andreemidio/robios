#!/usr/bin/env python

from messaging.message import Message


class ConfigKey(Message):
    '''Message type implementation of key values used to identify a 
    configuration entry.

    Attributes
    ----------
    module : str
        The module a configuration belongs to.

    namespace : str
        Determine a context of the configuration in the module.

    name : str
        The actual configuration name inside of the a namespace and module.
    '''

    def __init__(self, module='', namespace='', name=''):
        '''Initilizes the message instance.

        Parameters
        ----------
        module : str, optional
            Is the configuration key module to set (default value is '')

        namespace : str, optional
            Is the configuration key namespace to set (default value
            is '')

        name : str, optional
            Is the configuration key name to set (default value is '')
        '''
        super().__init__()
        self.module = module
        self.namespace = namespace
        self.name = name


    def pack(self):
        packed = [self.module, self.namespace, self.name]
        return packed


    def unpack(self, fields, startingIndex):
        index = startingIndex

        self.module = self._unpack_string(fields[index]); index+=1
        self.namespace = self._unpack_string(fields[index]); index+=1
        self.name = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ConfigKey):
            return \
                self.module == other.module and \
                self.namespace == other.namespace and \
                self.name == other.name
        else:
            return False