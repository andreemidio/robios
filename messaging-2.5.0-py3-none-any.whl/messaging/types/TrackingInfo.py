from messaging.message import Message

class TrackingInfo(Message):
    """Message type implementation for the detected objects in the 
    vision module.

    This message is used to send info about the tracking information about the detections.
    This message should be used together with DetectObject, as a sub-parameter.
    Attributes
    ----------
    angle_from_camera : float
        The angle in radians from the camera to the detect object.

    distance_from_camera : float
        Approximate distane from the camera lens, based on the width (in pixels) of the detect object.
    """

    def __init__(self, angle_from_camera : float = 0.0, distance_from_camera : float  = 0.0):
        super().__init__()
        self.angle_from_camera = angle_from_camera
        self.distance_from_camera = distance_from_camera
    
    def pack(self):
        packed = []
        packed.append(self._pack_field(self.angle_from_camera))
        packed.append(self._pack_field(self.distance_from_camera))
        return packed

    def unpack(self, fields, startingIndex):
        index = startingIndex
        self.angle_from_camera = self._unpack_float(fields[index]); index+=1
        self.distance_from_camera = self._unpack_float(fields[index]); index+=1
        return index

    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, TrackingInfo):
            return self.angle_from_camera == other.angle_from_camera and self.distance_from_camera == other.distance_from_camera
        else:
            return False