#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header


class ConfigSet(Message):
    """Message type implementation to send configurations to be set in
    the receiver.

    Attributes
    ----------
    header : Header
        Message's header.

    target_resource : str
        Defines the name of a resource in the receiver where the 
        configuration are going to be applied.

    config_data : str
        The configuration data to be set. In JSON format.
    """

    def __init__(self, target_resource='', config_data=''):
        """Initializes the message instance.

        Parameters
        ----------
        target_resource : str, optional
            Is the target resource to set (default value is '').

        config_data : str, optional
            Is the configuration data to set (default value is '').
        """
        super().__init__()

        self.header = Header()
        self.target_resource = target_resource
        self.config_data = config_data


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.target_resource), 
            self._pack_field(self.config_data)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.target_resource = self._unpack_string(fields[index]); index+=1
        self.config_data = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, ConfigSet):
            return \
                self.header == other.header and \
                self.target_resource == other.target_resource and \
                self.config_data == other.config_data
        else:
            return False