#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.DetectedObject import DetectedObject

class DetectedObjectArray(Message):
    """Message type implementation with an array of detected objects.

    This message is used to send a collections of entities detected by
    the image processing system.

    Attributes
    ----------
    header : Header
        Message's header.

    objects : list
        The list of detected objects. See the message type 
        DetectedObject.
    """

    def __init__(self, objects=None):
        """Initializes the message instance.

        Parameters
        ----------
        objects : list, optional
            Is the list of detected objects to set (default value is 
            None).
        """
        super().__init__()
        
        self.header = Header()
        self.objects = objects

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_array(self.objects))
        
        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.objects = self._unpack_array(fields[index], DetectedObject); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, DetectedObjectArray):
            return \
                self.header == other.header and \
                self.objects == other.objects
        else:
            return False