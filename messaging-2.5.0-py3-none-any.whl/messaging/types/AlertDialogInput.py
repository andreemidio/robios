#!/usr/bin/env python

from messaging.message import Message

class AlertDialogInput(Message):
    """Message type implementation for the input settings of the 
    AlertDialog

    Attributes
    ----------
    field_name : str
        The name of the input field.

    placeholder : str
        The placeholder text to show in the input field.

    default_value : str
        The default value of the input field.
    """

    def __init__(self, field_name='', placeholder='', default_value=''):
        """Initializes the message instance.

        Parameters
            field_name : str, optional
                The field name to set (default is '')

            placeholder : str, optional
                The placeholder value to set (default is '')

            default_value : str, optional
                The default value to set (default is '')
        """
        super().__init__()

        self.field_name = field_name
        self.placeholder = placeholder
        self.default_value = default_value


    def pack(self):
        return [
            self._pack_field(self.field_name), 
            self._pack_field(self.placeholder), 
            self._pack_field(self.default_value)
        ]


    def unpack(self, fields, starting_index):
        index = starting_index

        self.field_name = self._unpack_string(fields[index]); index+=1
        self.placeholder = self._unpack_string(fields[index]); index+=1
        self.default_value = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, AlertDialogInput):
            return \
                self.field_name == other.field_name and \
                self.placeholder == other.placeholder and \
                self.default_value == other.default_value
        else:
            return False