#!/usr/bin/env python

from messaging.utils.type_utils import parse_bool
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector3 import Vector3
from messaging.types.DistanceSensors import DistanceSensors

class Telemetry(Message):
    """Message type implementation of the Robot's telemetry information.

    Attributes
    ----------
    header : Header
        Message's header

    temperature_1 : float
        The value of the Temperature sensor 1.

    temperature_2 : float
        The value of the Temperature sensor 2.

    gas_1 : float
        The gas level.

    sound_1 : float
        The sound level.

    light_1 : float
        The light level.

    last_command : str
        The last received command.

    last_full_command : str
        The full version of the last received command.

    loop_time : int
        The micro-controller (arduino's) loop time.

    has_alarm : bool
        If there's any alarm.

    last_alarm_type : str
        The type of the last received alarm.

    last_hot_column_1 : int
        The column 1 of the last hot value.
    
    last_hot_column_2 : int
        The column 2 of the last hot value.

    head_horizontal_direction : int
        The direction of the head's horizontal movement.

    head_vertical_direction : int
        The direction of the head's vertical movement.

    direction : int
        The robot's direction.

    pression : int
        The pression's value.

    voice_direction : int
        The direction of the last detected voice by the array microphone.

    debug_message : str
        Debug message.

    acceleration : Vector3
        The acceleration values.

    gyroscope : Vector3
        The gyroscope values.

    imu : Vector3
        The IMU's sensor values.

    sensors : DistanceSensors
        The distance sensors values.

    left_motor_encoder_counter_1 : int
        The first Encoder's counter of the left robot's motor.

    left_motor_encoder_counter_2 : int
        The second Encoder's counter of the left robot's motor.

    right_motor_encoder_counter_1 : int
        The first Encoder's counter of the right robot's motor.

    right_motor_encoder_coutner_2 : int
        The second Encoder's counter of the right robot's motor.

    left_wheel_speed : float
        The robot's current left wheel speed. In RPM (rotations per minute).

    right_wheel_speed : float
        The robot's current right wheel speed. In RPM (rotations per minute).

    position : Vector3
        The robot's current position.

    orientation : Vector3
        The robot's current orientation.

    odometry_position : Vector3
        The robot's current odometry position.

    odometry_orientation : Vector3
        The robot's current odometry orientation.

    odometry_twist_linear : Vector3
        The robot's current odometry linear twist.

    odometry_twist_angular : Vector3
        The robot's current odometry angular twist.
    
    show_firmware_debug_messages : bool
        Determines if the firmware debug messages must be shown

    """
    
    def __init__(self, header=None):
        """Initializes the message instance."""
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header
            
        self.temperature_1 = 0.0
        self.temperature_2 = 0.0
        self.gas_1 = 0.0
        self.sound_1 = 0.0
        self.light_1 = 0.0
        self.last_command = ''
        self.last_full_command = ''
        self.loop_time = 0
        self.has_alarm = False
        self.last_alarm_type = ''
        self.last_hot_column_1 = 0
        self.last_hot_column_2 = 0
        self.head_horizontal_direction = 0
        self.head_vertical_direction = 0
        self.direction = 0
        self.pression = 0
        self.voice_direction = 0
        self.debug_message = ''
        self.acceleration = Vector3()
        self.gyroscope = Vector3()
        self.imu = Vector3()
        self.sensors = DistanceSensors()
        self.left_motor_encoder_counter_1 = 0
        self.left_motor_encoder_counter_2 = 0
        self.right_motor_encoder_counter_1 = 0
        self.right_motor_encoder_counter_2 = 0
        self.left_wheel_speed = 0.0
        self.right_wheel_speed = 0.0
        self.position = Vector3()
        self.orientation = Vector3()
        self.odometry_position = Vector3()
        self.odometry_orientation = Vector3()
        self.odometry_twist_linear = Vector3()
        self.odometry_twist_angular = Vector3()
        self.show_firmware_debug_messages = True

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.temperature_1),
            self._pack_field(self.temperature_2),
            self._pack_field(self.gas_1),
            self._pack_field(self.sound_1),
            self._pack_field(self.light_1),
            self._pack_field(self.last_command),
            self._pack_field(self.last_full_command),
            self._pack_field(self.loop_time),
            self._pack_field(self.has_alarm),
            self._pack_field(self.last_alarm_type),
            self._pack_field(self.last_hot_column_1),
            self._pack_field(self.last_hot_column_2),
            self._pack_field(self.head_horizontal_direction),
            self._pack_field(self.head_vertical_direction),
            self._pack_field(self.direction),
            self._pack_field(self.pression),
            self._pack_field(self.voice_direction),
            self._pack_field(self.debug_message)
        ])
        packed.extend(self.acceleration.pack())
        packed.extend(self.gyroscope.pack())
        packed.extend(self.imu.pack())
        packed.extend(self.sensors.pack())
        packed.extend([
            self._pack_field(self.left_motor_encoder_counter_1),
            self._pack_field(self.left_motor_encoder_counter_2),
            self._pack_field(self.right_motor_encoder_counter_1),
            self._pack_field(self.right_motor_encoder_counter_2),
            self._pack_field(self.left_wheel_speed),
            self._pack_field(self.right_wheel_speed)
        ])
        packed.extend(self.position.pack())
        packed.extend(self.orientation.pack())
        packed.extend(self.odometry_position.pack())
        packed.extend(self.odometry_orientation.pack())
        packed.extend(self.odometry_twist_linear.pack())
        packed.extend(self.odometry_twist_angular.pack())
        packed.append(self._pack_field(self.show_firmware_debug_messages))

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.temperature_1 = self._unpack_float(fields[index]); index+=1
        self.temperature_2 = self._unpack_float(fields[index]); index+=1
        self.gas_1 = self._unpack_float(fields[index]); index+=1
        self.sound_1 = self._unpack_float(fields[index]); index+=1
        self.light_1 = self._unpack_float(fields[index]); index+=1
        self.last_command = self._unpack_string(fields[index]); index+=1
        self.last_full_command = self._unpack_string(fields[index]); index+=1
        self.loop_time = self._unpack_int(fields[index]); index+=1
        self.has_alarm = self._unpack_boolean(fields[index]); index+=1
        self.last_alarm_type = self._unpack_string(fields[index]); index+=1
        self.last_hot_column_1 = self._unpack_int(fields[index]); index+=1
        self.last_hot_column_2 = self._unpack_int(fields[index]); index+=1
        self.head_horizontal_direction = self._unpack_int(fields[index]); index+=1
        self.head_vertical_direction = self._unpack_int(fields[index]); index+=1
        self.direction = self._unpack_int(fields[index]); index+=1
        self.pression = self._unpack_int(fields[index]); index+=1
        self.voice_direction = self._unpack_int(fields[index]); index+=1
        self.debug_message = self._unpack_string(fields[index]); index+=1
        index = self.acceleration.unpack(fields, index)
        index = self.gyroscope.unpack(fields, index)
        index = self.imu.unpack(fields, index)
        index = self.sensors.unpack(fields, index)
        self.left_motor_encoder_counter_1 = self._unpack_int(fields[index]); index+=1
        self.left_motor_encoder_counter_2 = self._unpack_int(fields[index]); index+=1
        self.right_motor_encoder_counter_1 = self._unpack_int(fields[index]); index+=1
        self.right_motor_encoder_counter_2 = self._unpack_int(fields[index]); index+=1
        self.left_wheel_speed = self._unpack_float(fields[index]); index+=1
        self.right_wheel_speed = self._unpack_float(fields[index]); index+=1
        index = self.position.unpack(fields, index)
        index = self.orientation.unpack(fields, index)
        index = self.odometry_position.unpack(fields, index)
        index = self.odometry_orientation.unpack(fields, index)
        index = self.odometry_twist_linear.unpack(fields, index)
        index = self.odometry_twist_angular.unpack(fields, index)
        self.show_firmware_debug_messages = self._unpack_boolean(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, Telemetry):
            return \
                self.header == other.header and \
                self.temperature_1 == other.temperature_1 and \
                self.temperature_2 == other.temperature_2 and \
                self.gas_1 == other.gas_1 and \
                self.sound_1 == other.sound_1 and \
                self.light_1 == other.light_1 and \
                self.last_command == other.last_command and \
                self.last_full_command == other.last_full_command and \
                self.loop_time == other.loop_time and \
                self.has_alarm == other.has_alarm and \
                self.last_alarm_type == other.last_alarm_type and \
                self.last_hot_column_1 == other.last_hot_column_1 and \
                self.last_hot_column_2 == other.last_hot_column_2 and \
                self.head_horizontal_direction == other.head_horizontal_direction and \
                self.head_vertical_direction == other.head_vertical_direction and \
                self.direction == other.direction and \
                self.pression == other.pression and \
                self.voice_direction == other.voice_direction and \
                self.debug_message == other.debug_message and \
                self.acceleration == other.acceleration and \
                self.gyroscope == other.gyroscope and \
                self.imu == other.imu and \
                self.sensors == other.sensors and \
                self.left_motor_encoder_counter_1 == other.left_motor_encoder_counter_1 and \
                self.left_motor_encoder_counter_2 == other.left_motor_encoder_counter_2 and \
                self.right_motor_encoder_counter_1 == other.right_motor_encoder_counter_1 and \
                self.right_motor_encoder_counter_2 == other.right_motor_encoder_counter_2 and \
                self.left_wheel_speed == other.left_wheel_speed and \
                self.right_wheel_speed == other.right_wheel_speed and \
                self.position == other.position and \
                self.orientation == other.orientation and \
                self.odometry_position == other.odometry_position and \
                self.odometry_orientation == other.odometry_orientation and \
                self.odometry_twist_linear == other.odometry_twist_linear and \
                self.odometry_twist_angular == other.odometry_twist_angular and \
                self.show_firmware_debug_messages == other.show_firmware_debug_messages
        else:
            return False