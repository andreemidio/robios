#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class NeckTelemetry(Message):
    '''Message type implementation taht carries telemetry information
    about the neck system.

    Constants
    ----------
    CALIBRATION_UNDFINED : int
        Status indicating the calibration process has not been done yet.

    CALIBRATION_IN_PROGRESS : int
        Status indicating the calibration process is in progress.

    CALIBRATION_DONE : int
        Status indicating the calibration has been done succesfully.


    Attributes
    ----------
    header : Header
        Message's header.

    calibration : int
        The calibration process status.

    moving : bool
        Whether the neck is moving or not.

    position : float
        The current neck's position (the angle in degrees).
    '''
    CALIBRATION_UNDEFINED = 1
    CALIBRATION_IN_PROGRESS = 2
    CALIBRATION_DONE = 3


    def __init__(self, header=None, calibration: int=1, moving: bool=False, position: float=0.0):
        '''Initialize the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is a new instance o 
            Header with the current timestamp)

        calibration : int, optional
            Is the status of the calibration process to set (default 
            value is CALIBRATION_UNDEFINED(1))

        moving : bool, optional
            Is the value indicating the neck is moving to set (default
            value is False)

        position : float, optional
            Is the current neck position to set (default value is 0.0).
        '''
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header

        self.calibration = calibration
        self.moving = moving
        self.position = position


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.calibration))
        packed.append(self._pack_field(self.moving))
        packed.append(self._pack_field(self.position))

        return packed


    def unpack(self, fields, startinIndex):
        index = startinIndex

        index = self.header.unpack(fields, index)
        self.calibration = self._unpack_float(fields[index]); index+=1
        self.moving = self._unpack_boolean(fields[index]); index+=1
        self.position = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, NeckTelemetry):
            return \
                self.header == other.header and \
                self.calibration == other.calibration and \
                self.moving == other.moving and \
                self.position == other.position
        else:
            return False