#!/usr/bin/env python

from messaging.message import Message

class DistanceSensors(Message):
    """Message type implementation with all available sensors values.

    Attributes
    ----------
    distance_forward : float
        The distance of the Forward sensor.

    distance_head_forward : float
        The distance of the Forward sensor of the head.

    distance_forward_left : float 
        The distance of the Forward Left sensor.

    distance_forward_right : float
        The distance of the Forward Right sensor.

    distance_backward_1 : float
        The distance of the Backward sensor 1.

    distance_backward_2 : float
        The distance of the Backward sensor 2.

    distance_backward_3 : float
        The distance of the Backward sensor 3.

    distance_left_1 : float
        The distance of the Left sensor 1.

    distance_right_1 : float
        The distance of the Right sensor 1.

    distance_left_2 : float
        The distance of the Left sensor 2.

    distance_right_2 : float
        The distance of the Right sensor 2.

    distance_left_3 : float
        The distance of the Left sensor 3.

    distance_right_3 : float
        The distance of the Right sensor 3.

    ground_distance_forward_left : float
        The distance of the Forward Left Ground sensor.

    ground_distance_forward_right : float
        The distance of the Forward Right Ground sensor.
    
    ground_distance_left_1 : float
        The distance of the Left Ground sensor 1.

    ground_distance_left_2 : float
        The distance of the Left Ground sensor 2.

    ground_distance_right_1 : float
        The distance of the Right Ground sensor 1.

    ground_distance_right_2 : float
        The distance of the Right Ground sensor 2.

    ground_distance_backward_left : float
        The distance of the Backward Left Ground sensor.

    ground_distance_backward_right : float
        The distance of the Backward Right Ground sensor.
    """
    
    def __init__(self):
        """Initializes the message instance."""
        super().__init__()
        self.distance_forward = 0.0
        self.distance_head_forward = 0.0
        self.distance_forward_left = 0.0
        self.distance_forward_right = 0.0
        self.diatance_backward_1 = 0.0
        self.diatance_backward_2 = 0.0
        self.diatance_backward_3 = 0.0
        self.distance_left_1 = 0.0
        self.distance_right_1 = 0.0
        self.distance_left_2 = 0.0
        self.distance_right_2 = 0.0
        self.distance_left_3 = 0.0
        self.distance_right_3 = 0.0
        self.ground_distance_forward_left = 0.0
        self.ground_distance_forward_right = 0.0
        self.ground_distance_left_1 = 0.0
        self.ground_distance_left_2 = 0.0
        self.ground_distance_right_1 = 0.0
        self.ground_distance_right_2 = 0.0
        self.ground_distance_backward_left = 0.0
        self.ground_distance_backward_right = 0.0


    def pack(self):
        return [
            self._pack_field(self.distance_forward),
            self._pack_field(self.distance_head_forward),
            self._pack_field(self.distance_forward_left),
            self._pack_field(self.distance_forward_right),
            self._pack_field(self.diatance_backward_1),
            self._pack_field(self.diatance_backward_2),
            self._pack_field(self.diatance_backward_3),
            self._pack_field(self.distance_left_1),
            self._pack_field(self.distance_right_1),
            self._pack_field(self.distance_left_2),
            self._pack_field(self.distance_right_2),
            self._pack_field(self.distance_left_3),
            self._pack_field(self.distance_right_3),
            self._pack_field(self.ground_distance_forward_left),
            self._pack_field(self.ground_distance_forward_right),
            self._pack_field(self.ground_distance_left_1),
            self._pack_field(self.ground_distance_left_2),
            self._pack_field(self.ground_distance_right_1),
            self._pack_field(self.ground_distance_right_2),
            self._pack_field(self.ground_distance_backward_left),
            self._pack_field(self.ground_distance_backward_right)
        ]


    def unpack(self, fields, starting_index):
        index = starting_index

        self.distance_forward = self._unpack_float(fields[index]); index+=1
        self.distance_head_forward = self._unpack_float(fields[index]); index+=1
        self.distance_forward_left = self._unpack_float(fields[index]); index+=1
        self.distance_forward_right = self._unpack_float(fields[index]); index+=1
        self.diatance_backward_1 = self._unpack_float(fields[index]); index+=1
        self.diatance_backward_2 = self._unpack_float(fields[index]); index+=1
        self.diatance_backward_3 = self._unpack_float(fields[index]); index+=1
        self.distance_left_1 = self._unpack_float(fields[index]); index+=1
        self.distance_right_1 = self._unpack_float(fields[index]); index+=1
        self.distance_left_2 = self._unpack_float(fields[index]); index+=1
        self.distance_right_2 = self._unpack_float(fields[index]); index+=1
        self.distance_left_3 = self._unpack_float(fields[index]); index+=1
        self.distance_right_3 = self._unpack_float(fields[index]); index+=1
        self.ground_distance_forward_left = self._unpack_float(fields[index]); index+=1
        self.ground_distance_forward_right = self._unpack_float(fields[index]); index+=1
        self.ground_distance_left_1 = self._unpack_float(fields[index]); index+=1
        self.ground_distance_left_2 = self._unpack_float(fields[index]); index+=1
        self.ground_distance_right_1 = self._unpack_float(fields[index]); index+=1
        self.ground_distance_right_2 = self._unpack_float(fields[index]); index+=1
        self.ground_distance_backward_left = self._unpack_float(fields[index]); index+=1
        self.ground_distance_backward_right = self._unpack_float(fields[index]); index+=1

        return index

    
    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, DistanceSensors):
            return \
                self.distance_forward == other.distance_forward and \
                self.distance_head_forward == other.distance_head_forward and \
                self.distance_forward_left == other.distance_forward_left and \
                self.distance_forward_right == other.diatance_backward_1 and \
                self.diatance_backward_1 == other.diatance_backward_1 and \
                self.diatance_backward_2 == other.diatance_backward_2 and \
                self.diatance_backward_3 == other.diatance_backward_3 and \
                self.distance_left_1 == other.distance_left_1 and \
                self.distance_right_1 == other.distance_right_1 and \
                self.distance_left_2 == other.distance_left_2 and \
                self.distance_right_2 == other.distance_right_2 and \
                self.distance_left_3 == other.distance_left_3 and \
                self.distance_right_3 == other.distance_right_3 and \
                self.ground_distance_forward_left == other.ground_distance_forward_left and \
                self.ground_distance_forward_right == other.ground_distance_forward_right and \
                self.ground_distance_left_1 == other.ground_distance_left_1 and \
                self.ground_distance_left_2 == other.ground_distance_left_2 and \
                self.ground_distance_right_1 == other.ground_distance_right_1 and \
                self.ground_distance_right_2 == other.ground_distance_right_2 and \
                self.ground_distance_backward_left == other.ground_distance_backward_left and \
                self.ground_distance_backward_right == other.ground_distance_backward_right
        else:
            return False