#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class WifiConfig(Message):
    """Message type implementation of the robot's wifi configuration to
    set.

    Attributes
    ----------
    header : Header
        Message's header.

    ssid : str
        The Wifi's SSID value.

    password : str
        The Wifi's password value.
    """

    def __init__(self, ssid='', password=''):
        """Initializes the message instance.

        Parameters
        ----------
        ssid : str, optional
            The SSID value to set (default is '')

        password : str, optional
            The password value to set (default is '')
        """
        super().__init__()
        self.header = Header()
        self.ssid = ssid
        self.password = password

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.ssid), 
            self._pack_field(self.password)
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.ssid = self._unpack_string(fields[index]); index+=1
        self.password = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, WifiConfig):
            return \
                self.header == other.header and \
                self.ssid == other.ssid and \
                self.password == other.password
        else:
            return False