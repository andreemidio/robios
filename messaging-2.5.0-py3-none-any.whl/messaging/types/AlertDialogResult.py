#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class AlertDialogResult(Message):
    """Message type implementation to send the result of a AlertDialog
    to the Robot Core.

    Constants
    ----------
    ACTION_CONFIRM : str
        The confirm action result fo the Alert Dialog.

    ACTION_CANCEL : str
        The cancel action result of the Alert Dialog.

    RESULT_TYPE_TEXT : str
        Simple text result type.

    RESULT_TYPE_DIALOG_INPUT : str
        A result type to use the result content as an input for the
        dialog system.

    Attributes
    ----------
    header : Header
        Message's header

    id : str
        Dialog ID.

    action : str
        The action pressed in the Alert Dialog. Check the constants for
        the possible values.

    result : str
        The result value of the dialog.

    result_type : str
        Defines how the result value can be used by the receiver. Check
        the constants for the possible values.

    selected_option : int
        The index of the options selected by the user. Only used for the
        dialogs of type AlertDialog.TYPE_OPTIONS.

    content : str
        The input field content of the dialog. Only used for the dialogs
        of type AlertDialog.TYPE_INPUT.

    input_field_name : str
        The name of the dialog's input field. Only used for the dialogs
        of type AlertDialog.TYPE_INPUT.
    """

    ACTION_CONFIRM = 'confirm'
    ACTION_CANCEL = 'cancel'

    RESULT_TYPE_TEXT = 'text'
    RESULT_TYPE_DIALOG_INPUT = 'dialog_input'


    def __init__(self, action=ACTION_CONFIRM, result=''):
        """Initializes the message instance.

        Parameters
        ----------
        action : str, optional
            Is the action value to set (default value is the value 
            of the constant ACTION_CONFIRM).

        result : str, optional
            Is the result value to set (default value is '').
        """
        super().__init__()
        self.header = Header()
        self.id = ''
        self.action = action
        self.result = result
        self.result_type = AlertDialogResult.RESULT_TYPE_TEXT
        self.selected_option = 0
        self.content = ''
        self.input_field_name = ''


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.id),
            self._pack_field(self.action),
            self._pack_field(self.result),
            self._pack_field(self.result_type),
            self._pack_field(self.selected_option),
            self._pack_field(self.content),
            self._pack_field(self.input_field_name),
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.id = self._unpack_string(fields[index]); index+=1
        self.action = self._unpack_string(fields[index]); index+=1
        self.result = self._unpack_string(fields[index]); index+=1
        self.result_type = self._unpack_string(fields[index]); index+=1
        self.selected_option = self._unpack_int(fields[index]); index+=1
        self.content = self._unpack_string(fields[index]); index+=1
        self.input_field_name = self._unpack_string(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, AlertDialogResult):
            return \
                self.header == other.header and \
                self.id == other.id and \
                self.action == other.action and \
                self.result == other.result and \
                self.result_type == other.result_type and \
                self.selected_option == other.selected_option and \
                self.content == other.content and \
                self.input_field_name == other.input_field_name
        else:
            return False
    