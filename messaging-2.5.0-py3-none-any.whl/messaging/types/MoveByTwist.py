#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class MoveByTwist(Message):
    """Message type implementation of the action to move the robot using
    the twist movement type.

    Attributes
    ----------
    header : Header
        Message's header.

    linear_velocity : float
        The lienar speed, in rad/s (radians per second), that will be 
        applied on the robot. Use positive values to move the robot 
        forwards or negative values to move the robot backwards.

    angular_velocity : float
        The angular speed, in rad/s (radians per second), that will be
        applied on the robot. Use positive values to move the robot
        forwards or negative values to move the robot backwards.
    """

    def __init__(self, linear_velocity=0.0, angular_velocity=0.0):
        """Initializes the message instance.

        Parameters
        ----------
        linear_velocity : float, optional
            Is the linear speed to be applied (default valeu is 0.0).
        
        angular_valocity : float, optional
            Is the angular speed to be applied (default value is 0.0).
        """
        super().__init__()
        self.header = Header()
        self.linear_velocity = linear_velocity
        self.angular_velocity = angular_velocity


    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.extend([
            self._pack_field(self.linear_velocity),
            self._pack_field(self.angular_velocity),
        ])

        return packed


    def unpack(self, fields, starting_index):
        index = starting_index

        index = self.header.unpack(fields, index)
        self.linear_velocity = self._unpack_float(fields[index]); index+=1
        self.angular_velocity = self._unpack_float(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, MoveByTwist):
            return \
                self.header == other.header and \
                self.linear_velocity == other.linear_velocity and \
                self.angular_velocity == other.angular_velocity
        else:
            return False