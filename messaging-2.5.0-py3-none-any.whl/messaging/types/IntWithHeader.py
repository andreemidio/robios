#!/usr/bin/env python

from messaging.message import Message
from messaging.types.Header import Header

class IntWithHeader(Message):
    """Message type implementation of int content with header.
    
    Attributes
    ----------
    header : Header
        Message's header.

    data : int
        The int data of the message.
    """

    def __init__(self, header=None, data=0):
        """Initializes the message instance.

        Parameters
        ----------
        header : Header, optional
            Is the header to set (default value is None).
            
        data : int, optional
            Is the int value to set (default value is 0).
        """
        super().__init__()
        if header == None:
            self.header = Header()
        else:
            self.header = header
            
        self.data = data

    
    def pack(self):
        packed = []
        packed.extend(self.header.pack())
        packed.append(self._pack_field(self.data))

        return packed

    
    def unpack(self, fields, startingIndex):
        index = startingIndex

        index = self.header.unpack(fields, index)
        self.data = self._unpack_int(fields[index]); index+=1

        return index


    def __eq__(self, other):
        if other == None:
            return False
        if not super().__eq__(other):
            return False
        if isinstance(other, IntWithHeader):
            return \
                self.header == other.header and \
                self.data == other.data
        else:
            return False