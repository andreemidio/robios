#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.StringArray import StringArray
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class StringArrayTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(StringArray, include_header=True)
        self.encoded_message.extend(['item1', self.list_sep, 'item2', self.list_sep, 'item3'])

        self.decoded_message = StringArray(Header(self.timestamp), ['item1', 'item2', 'item3'])
        self.decoded_message.context = self.context