#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector3 import Vector3
from messaging.types.ArucoPose import ArucoPose
from messaging.types.ArucoPoseArray import ArucoPoseArray
from messaging.tests.types.message_tests import MessageTests


class ArucoPoseArrayTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ArucoPoseArray, include_header=True)
        self.encoded_message.extend([
            'fid01', self.list_sep, str(1.0), self.list_sep, str(2.0), self.list_sep, str(3.0), self.list_sep, str(90), self.list_sep,
            'fid02', self.list_sep, str(0.0), self.list_sep, str(0.0), self.list_sep, str(0.0), self.list_sep, str(0), self.list_sep,
            'fid03', self.list_sep, str(3.0), self.list_sep, str(2.0), self.list_sep, str(1.0), self.list_sep, str(180)        
        ])

        self.decoded_message = ArucoPoseArray(
            Header(self.timestamp), 
            [
                ArucoPose('fid01', Vector3(1.0, 2.0, 3.0), 90),
                ArucoPose('fid02', Vector3(0.0, 0.0, 0.0), 0),
                ArucoPose('fid03', Vector3(3.0, 2.0, 1.0), 180)
            ]
        )
        self.decoded_message.context = self.context