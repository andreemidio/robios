#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.MoveBySpeed import MoveBySpeed
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class MoveBySpeedTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(MoveBySpeed, include_header=True)
        self.encoded_message.extend([
            str(100.0), self.sep, str(150.0)
        ])

        self.decoded_message = MoveBySpeed(100.0, 150.0)
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp