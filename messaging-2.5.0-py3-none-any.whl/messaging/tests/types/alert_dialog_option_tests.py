#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.AlertDialogOption import AlertDialogOption
from messaging.tests.types.message_tests import MessageTests


class AlertDialogOptionTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(AlertDialogOption, include_header=False)
        self.encoded_message.extend(['Option 1', self.sep, 'option_value'])

        self.decoded_message = AlertDialogOption('Option 1', 'option_value')
        self.decoded_message.context = self.context