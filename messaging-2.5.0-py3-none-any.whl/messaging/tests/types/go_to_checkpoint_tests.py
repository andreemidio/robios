#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Checkpoint import Checkpoint
from messaging.types.NavigationPoint import NavigationPoint
from messaging.types.GoToCheckpoint import GoToCheckpoint

from messaging.tests.types.message_tests import MessageTests


class GoToCheckpointTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(GoToCheckpoint, include_header=True)
        self.encoded_message.extend([
            'checkpoint01', self.sep, 'checkpoint\'s description', self.sep, 'checkpoint\'s world', self.sep,
            Checkpoint.CATEGORY_CHECKPOINT, self.sep, '', self.sep,
            str(0.0), self.sep, str(0.0), self.sep, str(0.0), self.sep, str(0)
        ])

        self.decoded_message = GoToCheckpoint()
        self.decoded_message.checkpoint = Checkpoint('checkpoint01', 'checkpoint\'s description', 'checkpoint\'s world', Checkpoint.CATEGORY_CHECKPOINT, '', NavigationPoint())
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp        