#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.ScriptCallback import ScriptCallback
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class ScriptCallbackTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ScriptCallback, include_header=True)
        self.encoded_message.extend([
            ScriptCallback.CALLBACK_STARTED, self.sep,
            'parameter1', self.list_sep, 'parameter2'
        ])

        self.decoded_message = ScriptCallback(ScriptCallback.CALLBACK_STARTED, ['parameter1', 'parameter2'])
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp