#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector3 import Vector3
from messaging.types.NavigationPoint import NavigationPoint
from messaging.types.Checkpoint import Checkpoint
from messaging.types.CheckpointArray import CheckpointArray
from messaging.tests.types.message_tests import MessageTests


class CheckpointArrayTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(CheckpointArray, include_header=True)
        self.encoded_message.extend([
            'checkpoint01', self.list_sep, 'checkpoint\'s description 1', self.list_sep, 'checkpoint\'s world', self.list_sep,
            Checkpoint.CATEGORY_CHECKPOINT, self.list_sep, '', self.list_sep,
            str(0.0), self.list_sep, str(0.0), self.list_sep, str(0.0), self.list_sep, str(0), self.list_sep,

            'checkpoint02', self.list_sep, 'checkpoint\'s description 2', self.list_sep, 'checkpoint\'s world', self.list_sep,
            Checkpoint.CATEGORY_CHECKPOINT, self.list_sep, '', self.list_sep,
            str(0.0), self.list_sep, str(0.0), self.list_sep, str(0.0), self.list_sep, str(0), self.list_sep,
            
            'door01', self.list_sep, 'door\'s description 1', self.list_sep, 'door\'s world', self.list_sep,
            Checkpoint.CATEGORY_DOOR, self.list_sep, '', self.list_sep,
            str(0.0), self.list_sep, str(0.0), self.list_sep, str(0.0), self.list_sep, str(0)
        ])

        self.decoded_message = CheckpointArray(
            Header(self.timestamp), 
            [
                Checkpoint('checkpoint01', 'checkpoint\'s description 1', 'checkpoint\'s world', Checkpoint.CATEGORY_CHECKPOINT, '', NavigationPoint(Vector3(0.0, 0.0, 0.0), 0)),
                Checkpoint('checkpoint02', 'checkpoint\'s description 2', 'checkpoint\'s world', Checkpoint.CATEGORY_CHECKPOINT, '', NavigationPoint(Vector3(0.0, 0.0, 0.0), 0)),
                Checkpoint('door01', 'door\'s description 1', 'door\'s world', Checkpoint.CATEGORY_DOOR, '', NavigationPoint(Vector3(0.0, 0.0, 0.0), 0))
            ]
        )
        self.decoded_message.context = self.context