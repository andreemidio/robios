#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.DoubleMessage import DoubleMessage
from messaging.tests.types.message_tests import MessageTests


class DoubleMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(DoubleMessage, include_header=False)
        self.encoded_message.append(str(1.5))

        self.decoded_message = DoubleMessage(1.5)
        self.decoded_message.context = self.context