#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.BooleanWithHeader import BooleanWithHeader
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class BooleanWithHeaderTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(BooleanWithHeader, include_header=True)
        self.encoded_message.append(str(True))

        self.decoded_message = BooleanWithHeader(Header(self.timestamp), True)
        self.decoded_message.context = self.context