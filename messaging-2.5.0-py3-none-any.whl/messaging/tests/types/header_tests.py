#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class HeaderTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(Header, include_header=False)
        self.encoded_message.append(str(self.timestamp))

        self.decoded_message = Header(self.timestamp)
        self.decoded_message.context = self.context