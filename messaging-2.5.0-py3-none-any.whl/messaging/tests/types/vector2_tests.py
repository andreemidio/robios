#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Vector2 import Vector2
from messaging.tests.types.message_tests import MessageTests


class Vector2Tests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(Vector2, include_header=False)
        self.encoded_message.extend([ str(1.0), self.sep, str(0.0) ])

        self.decoded_message = Vector2(1.0, 0.0)
        self.decoded_message.context = self.context