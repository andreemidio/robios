#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.MoveHead import MoveHead
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class MoveHeadTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(MoveHead, include_header=True)
        self.encoded_message.extend([ str(10), self.sep, str(-20) ])

        self.decoded_message = MoveHead(10, -20)
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp