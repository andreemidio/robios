#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Checkpoint import Checkpoint
from messaging.types.NavigationPoint import NavigationPoint
from messaging.tests.types.message_tests import MessageTests


class CheckpointTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(Checkpoint, include_header=False)
        self.encoded_message.extend([
            'checkpoint01', self.sep, 'checkpoint\'s description', self.sep, 'checkpoint\'s world', self.sep,
            'checkpoint', self.sep, '', self.sep,
            str(0.0), self.sep, str(0.0), self.sep, str(0.0), self.sep, str(0) 
        ])

        self.decoded_message = Checkpoint('checkpoint01', 'checkpoint\'s description', 'checkpoint\'s world', 'checkpoint', '', NavigationPoint())
        self.decoded_message.context = self.context