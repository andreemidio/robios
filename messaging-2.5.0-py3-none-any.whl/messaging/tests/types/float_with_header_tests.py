#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.FloatWithHeader import FloatWithHeader
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class FloatWithHeaderTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(FloatWithHeader, include_header=True)
        self.encoded_message.append(str(1.5))

        self.decoded_message = FloatWithHeader(Header(self.timestamp), 1.5)
        self.decoded_message.context = self.context