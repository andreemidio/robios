#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.ExecuteCommand import ExecuteCommand
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class ExecuteCommandTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ExecuteCommand, include_header=True)
        self.encoded_message.extend([
            'set_face_accessory', self.sep, 
            'parameter1', self.list_sep, 'parameter2'
        ])

        self.decoded_message = ExecuteCommand('set_face_accessory', ['parameter1', 'parameter2'])
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp