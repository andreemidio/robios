#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.IntWithHeader import IntWithHeader
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class IntWithHeaderTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(IntWithHeader, include_header=True)
        self.encoded_message.append(str(100))

        self.decoded_message = IntWithHeader(Header(self.timestamp), 100)
        self.decoded_message.context = self.context