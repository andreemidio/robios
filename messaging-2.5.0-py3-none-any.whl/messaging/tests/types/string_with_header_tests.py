#!/usr/bin/env python

from messaging.message import Message
from messaging.types.StringWithHeader import StringWithHeader
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class StringWithHeaderTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(StringWithHeader, include_header=True)
        self.encoded_message.append('stringContent')

        self.decoded_message = StringWithHeader(Header(self.timestamp), 'stringContent')
        self.decoded_message.context = self.context