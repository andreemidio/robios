#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.SystemStatus import SystemStatus
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class SystemStatusTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(SystemStatus, include_header=True)
        self.encoded_message.extend([ 'FaceDetection', self.sep, str(SystemStatus.STATUS_OK) ])

        self.decoded_message = SystemStatus('FaceDetection', SystemStatus.STATUS_OK)
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp