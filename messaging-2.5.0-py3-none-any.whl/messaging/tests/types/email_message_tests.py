#!/usr/bin/env python

from messaging.message import Message
from messaging.types.EmailMessage import EmailMessage
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class EmailMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(EmailMessage, include_header=True)
        self.encoded_message.append(f'Fulano{self.sep}email{Message.SEPARATOR_ESCAPE}email.com{self.sep}Title{self.sep}')
        self.encoded_message.append(f'<h1>CONTENT</h1><br>{self.sep}!$%&*()_+=-0{{}}[]^´?;:.,<>ABC{self.sep}')
        self.encoded_message.append(f'png{self.sep}{True}{self.sep}templateX')
		
        self.decoded_message = EmailMessage()
        self.decoded_message.name = 'Fulano'
        self.decoded_message.recipient = 'email@email.com'
        self.decoded_message.subject = 'Title'
        self.decoded_message.html_content = '<h1>CONTENT</h1><br>'
        self.decoded_message.file_encoded = '!$%&*()_+=-0{}[]^´?;:.,<>ABC'
        self.decoded_message.file_extension = 'png'
        self.decoded_message.show_image_in_html = True
        self.decoded_message.template_name = 'templateX'
        self.decoded_message.context = self.context