#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.FaceDisplaySettings import FaceDisplaySettings
from messaging.tests.types.message_tests import MessageTests


class FaceDisplaySettingsTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(FaceDisplaySettings, include_header=False)
        self.encoded_message.extend([FaceDisplaySettings.MODE_NONE, self.sep, FaceDisplaySettings.POSITION_TOP_LEFT, self.sep, str(0.0)])

        self.decoded_message = FaceDisplaySettings()
        self.decoded_message.context = self.context