#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.ConfigMessage import ConfigMessage

from messaging.tests.types.message_tests import MessageTests


class ConfigMessageTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ConfigMessage, include_header=True)
        self.encoded_message.extend([
            '', self.sep, 'robot.module.test', self.sep, 'test', self.sep, 'string', self.sep,
            str(False), self.sep, str(self.timestamp), self.sep, str(self.timestamp), self.sep, 'user'
        ])

        self.decoded_message = ConfigMessage('', 'robot.module.test', 'test', 'string', False, self.timestamp, self.timestamp, 'user')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp