#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.ModuleStatus import ModuleStatus
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class ModuleStatusTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ModuleStatus, include_header=True)
        self.encoded_message.extend([ 
            'FaceDetection', self.sep, '', self.sep, 
            'FaceDetection', self.sep, 'keep_alive', self.sep, str(1)
        ])

        self.decoded_message = ModuleStatus('FaceDetection', '', 'FaceDetection', 'keep_alive', 1)
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp