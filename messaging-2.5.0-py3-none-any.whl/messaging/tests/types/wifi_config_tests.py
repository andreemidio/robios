#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.WifiConfig import WifiConfig
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class WifiConfigTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(WifiConfig, include_header=True)
        self.encoded_message.extend([ 'network', self.sep, '12345678' ])

        self.decoded_message = WifiConfig('network', '12345678')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp