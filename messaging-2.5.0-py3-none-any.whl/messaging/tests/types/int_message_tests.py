#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.IntMessage import IntMessage
from messaging.tests.types.message_tests import MessageTests


class IntMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(IntMessage, include_header=False)
        self.encoded_message.append(str(100))

        self.decoded_message = IntMessage(100)
        self.decoded_message.context = self.context