#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Vector3 import Vector3
from messaging.types.ArucoPose import ArucoPose
from messaging.tests.types.message_tests import MessageTests


class ArucoPoseTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ArucoPose, include_header=False)
        self.encoded_message.extend(['fid01', self.sep, str(1.0), self.sep, str(2.0), self.sep, str(3.0), self.sep, str(90)])

        self.decoded_message = ArucoPose('fid01', Vector3(1.0, 2.0, 3.0), 90)
        self.decoded_message.context = self.context