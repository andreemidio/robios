#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Script import Script
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class ScriptTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(Script, include_header=True)
        self.encoded_message.extend([ Script.ACTION_ADD, self.sep, 'myScript' ])

        self.decoded_message = Script(Script.ACTION_ADD, 'myScript')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp