#!/usr/bin/env python

from datetime import datetime
import unittest

from messaging.message import Message

class MessageTests(unittest.TestCase):

    def setUp(self):
        self.version = Message.CURRENT_VERSION
        self.context = "/robot/context"
        self.timestamp = int(datetime.now().timestamp() * 1000)
        self.sep = Message.SEPARATOR
        self.list_sep = Message.LIST_SEPARATOR

        self.encoded_message = []
        self.decoded_message = None       


    def test_decode(self):
        expected = self.decoded_message

        result = Message.decode(''.join(self.encoded_message))

        self.assertEqual(expected, result)


    def test_encode(self):
        expected = ''.join(self.encoded_message)

        message = self.decoded_message
        result = message.encode()

        self.assertEqual(expected, result)


    def build_encoded_message(self, klass: type, include_header: bool) -> []:
        encoded = [
            str(self.version), self.sep, 
            self.context, self.sep,
            klass.__name__, self.sep, 
            Message.get_default_origin(), self.sep
        ]

        if include_header:
            encoded.extend([str(self.timestamp), self.sep])

        return encoded