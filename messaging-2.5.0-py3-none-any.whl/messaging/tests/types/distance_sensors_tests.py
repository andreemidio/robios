#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.DistanceSensors import DistanceSensors
from messaging.tests.types.message_tests import MessageTests


class DistanceSensorsTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(DistanceSensors, include_header=False)
        self.encoded_message.extend([
            str(1.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0), self.sep, str(0.0), self.sep,
            str(0.0)
        ])

        self.decoded_message = DistanceSensors()
        self.decoded_message.context = self.context
        self.decoded_message.distance_forward = 1.0