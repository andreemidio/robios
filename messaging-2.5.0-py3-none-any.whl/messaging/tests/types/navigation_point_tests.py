#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Vector3 import Vector3
from messaging.types.NavigationPoint import NavigationPoint
from messaging.tests.types.message_tests import MessageTests


class NavigationPointTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(NavigationPoint, include_header=False)
        self.encoded_message.extend([ 
            str(5.0), self.sep, str(2.5), self.sep, str(0.0), self.sep, str(0)
        ])

        self.decoded_message = NavigationPoint(Vector3(5.0, 2.5, 0.0), 0)
        self.decoded_message.context = self.context