#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.SpeakCallback import SpeakCallback
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class SpeakCallbackTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(SpeakCallback, include_header=True)
        self.encoded_message.extend([SpeakCallback.EVENT_DONE, self.sep, 'text_id', self.sep, 'Hello'])

        self.decoded_message = SpeakCallback(Header(self.timestamp), SpeakCallback.EVENT_DONE, 'text_id', 'Hello')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp