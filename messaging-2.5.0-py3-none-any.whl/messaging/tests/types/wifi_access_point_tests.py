#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.WifiAccessPoint import WifiAccessPoint
from messaging.tests.types.message_tests import MessageTests


class WifiAccessPointTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(WifiAccessPoint, include_header=False)
        self.encoded_message.extend([ 'network', self.sep, 'WPA', self.sep, str(100), self.sep, str(False) ])

        self.decoded_message = WifiAccessPoint('network', 'WPA', 100, False)
        self.decoded_message.context = self.context