#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.FloatMessage import FloatMessage
from messaging.tests.types.message_tests import MessageTests


class FloatMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(FloatMessage, include_header=False)
        self.encoded_message.append(str(1.5))

        self.decoded_message = FloatMessage(1.5)
        self.decoded_message.context = self.context