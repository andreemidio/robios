#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.MoveByTwist import MoveByTwist
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class MoveByTwistTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(MoveByTwist, include_header=True)
        self.encoded_message.extend([
            str(1.5), self.sep, str(0.5)
        ])

        self.decoded_message = MoveByTwist(1.5, 0.5)
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp