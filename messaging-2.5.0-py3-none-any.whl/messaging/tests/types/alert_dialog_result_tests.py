#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.AlertDialogResult import AlertDialogResult
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class AlertDialogResultTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(AlertDialogResult, include_header=True)
        self.encoded_message.extend([
            '', self.sep,
            AlertDialogResult.ACTION_CONFIRM, self.sep,
            'result', self.sep,
            AlertDialogResult.RESULT_TYPE_TEXT, self.sep,
            str(0), self.sep,
            '', self.sep, ''
        ])

        self.decoded_message = AlertDialogResult(AlertDialogResult.ACTION_CONFIRM, 'result')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp