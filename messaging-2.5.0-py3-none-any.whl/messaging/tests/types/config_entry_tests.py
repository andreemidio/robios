#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.ConfigKey import ConfigKey
from messaging.types.ConfigEntry import ConfigEntry, Header
from messaging.tests.types.message_tests import MessageTests


class ConfigEntryTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ConfigEntry, include_header=True)
        self.encoded_message.extend([
            'core', self.sep, 'content', self.sep, 'hello_world', self.sep,
            'Hello World core config', self.sep, ConfigEntry.TYPE_STRING, self.sep, 
            'Hello World', self.sep, 'robios', self.sep, 'myApplication'
        ])

        self.decoded_message = ConfigEntry(Header(self.timestamp), ConfigKey('core', 'content', 'hello_world'), 'Hello World core config', ConfigEntry.TYPE_STRING, 'Hello World', 'robios', 'myApplication')
        self.decoded_message.context = self.context