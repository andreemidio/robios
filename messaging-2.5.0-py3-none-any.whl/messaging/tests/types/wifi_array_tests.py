#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.WifiAccessPoint import WifiAccessPoint
from messaging.types.WifiArray import WifiArray
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class WifiArrayTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(WifiArray, include_header=True)
        self.encoded_message.extend([ 
            'network1', self.list_sep, 'WPA', self.list_sep, str(100), self.list_sep, str(False), self.list_sep,
            'network2', self.list_sep, 'WPA2', self.list_sep, str(95), self.list_sep, str(True), self.list_sep,
            'network3', self.list_sep, 'WPA', self.list_sep, str(80), self.list_sep, str(False)
        ])

        self.decoded_message = WifiArray([
            WifiAccessPoint('network1', 'WPA', 100, False),
            WifiAccessPoint('network2', 'WPA2', 95, True),
            WifiAccessPoint('network3', 'WPA', 80, False)
        ])
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp