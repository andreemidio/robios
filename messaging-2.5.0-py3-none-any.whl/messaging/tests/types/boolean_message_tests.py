#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.BooleanMessage import BooleanMessage
from messaging.tests.types.message_tests import MessageTests


class BooleanMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(BooleanMessage, include_header=False)
        self.encoded_message.append(str(True))

        self.decoded_message = BooleanMessage(True)
        self.decoded_message.context = self.context