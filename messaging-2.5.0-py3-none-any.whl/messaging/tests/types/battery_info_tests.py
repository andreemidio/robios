#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.BatteryInfo import BatteryInfo, Header
from messaging.tests.types.message_tests import MessageTests


class BatteryInfoTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(BatteryInfo, include_header=True)
        self.encoded_message.extend([ str(30.5), self.sep, str(18.1) ])

        self.decoded_message = BatteryInfo(Header(self.timestamp), 30.5, 18.1)
        self.decoded_message.context = self.context