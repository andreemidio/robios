#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.DetectedObject import DetectedObject
from messaging.types.DetectedObjectArray import DetectedObjectArray
from messaging.tests.types.message_tests import MessageTests


class DetectedObjectArrayTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(DetectedObjectArray, include_header=True)
        self.encoded_message.extend([ "Fulano", self.list_sep, "person", self.list_sep ])
        #Accuracy & object index
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0), self.list_sep ])
        #Vector2
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        #Geometry2D
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        #TrackingInfo
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep])
        self.encoded_message.extend([ "Beltrano", self.list_sep, "person", self.list_sep ])
        #Accuracy & object index
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0), self.list_sep ])
        #Vector2
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        #Geometry2D
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        #TrackingInfo
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep])
        self.encoded_message.extend([ "Ciclano", self.list_sep, "person", self.list_sep ])
        #Accuracy & object index
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0), self.list_sep ])
        #Vector2
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        #Geometry2D
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0), self.list_sep ])
        #TrackingInfo
        self.encoded_message.extend([ str(0.0), self.list_sep, str(0.0)])

        self.decoded_message = DetectedObjectArray([
            DetectedObject(name="Fulano", object_type="person"),
            DetectedObject(name="Beltrano", object_type="person"),
            DetectedObject(name="Ciclano", object_type="person")
        ])
        self.decoded_message.header = Header(self.timestamp)
        self.decoded_message.context = self.context