#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.AlertDialog import AlertDialog
from messaging.types.Header import Header
from messaging.types.FaceDisplaySettings import FaceDisplaySettings
from messaging.tests.types.message_tests import MessageTests


class AlertDialogTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(AlertDialog, include_header=True)
        self.encoded_message.extend([
            '', self.sep,
            'Dialog Title', self.sep,
            'Dialog Description', self.sep,
            '', self.sep,
            str(AlertDialog.MEDIA_TYPE_NONE), self.sep,
            '', self.sep,
            str(True), self.sep,
            str(False), self.sep,
            str(False), self.sep,
            str(AlertDialog.REPLACE_ALLOWED), self.sep,
            str(0), self.sep,
            str(False), self.sep,
            AlertDialog.TYPE_INFO, self.sep,
            AlertDialog.SUBTYPE_TEXT, self.sep,
            AlertDialog.RESULT_TYPE_TEXT, self.sep,
            '', self.sep,
            '', self.sep,
            str(True), self.sep,
            str(True), self.sep,
            str(True), self.sep,
            str(False), self.sep,
            '', self.sep, '', self.sep, '', self.sep,
            '', self.sep,
            FaceDisplaySettings.MODE_NONE, self.sep, FaceDisplaySettings.POSITION_TOP_LEFT, self.sep, str(0.0)
        ])

        self.decoded_message = AlertDialog('Dialog Title', 'Dialog Description')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp
        self.decoded_message.dialog_type = AlertDialog.TYPE_INFO
        self.decoded_message.subtype = AlertDialog.SUBTYPE_TEXT