#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.LongMessage import LongMessage
from messaging.tests.types.message_tests import MessageTests


class LongMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(LongMessage, include_header=False)
        self.encoded_message.append(str(100))

        self.decoded_message = LongMessage(100)
        self.decoded_message.context = self.context