from messaging.types.TrackingInfo import TrackingInfo
from messaging.tests.types.message_tests import MessageTests

class TrackingInfoTests(MessageTests):
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(TrackingInfo, include_header=False)
        self.encoded_message.extend([str(0.0), self.sep ,str(0.0)])

        self.decoded_message = TrackingInfo() 
        self.decoded_message.context = self.context
