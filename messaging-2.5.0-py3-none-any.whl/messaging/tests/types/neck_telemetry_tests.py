#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.NeckTelemetry import NeckTelemetry, Header
from messaging.tests.types.message_tests import MessageTests


class NeckTelemetryTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(NeckTelemetry, include_header=True)
        self.encoded_message.extend([ str(NeckTelemetry.CALIBRATION_UNDEFINED), self.sep, str(False), self.sep, str(0.0) ])

        self.decoded_message = NeckTelemetry(Header(self.timestamp), NeckTelemetry.CALIBRATION_UNDEFINED, False, 0.0)
        self.decoded_message.context = self.context