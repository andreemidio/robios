#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.ExecuteOnHead import ExecuteOnHead
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class ExecuteOnHeadTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ExecuteOnHead, include_header=True)
        self.encoded_message.extend([
            ExecuteOnHead.TYPE_INTERNAL_APP, self.sep, 'menu'
        ])

        self.decoded_message = ExecuteOnHead(ExecuteOnHead.TYPE_INTERNAL_APP, 'menu')
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp