#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector2 import Vector2
from messaging.types.Geometry2D import Geometry2D
from messaging.types.TrackingInfo import TrackingInfo
from messaging.types.DetectedObject import DetectedObject
from messaging.tests.types.message_tests import MessageTests


class DetectedObjectTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(DetectedObject, include_header=False)
        self.encoded_message.extend([ "Fulano", self.sep, "person", self.sep ])
        #Accuracy & object index
        self.encoded_message.extend([ str(0.0), self.sep, str(0), self.sep ])
        #Vector2
        self.encoded_message.extend([ str(0.0), self.sep, str(0.0), self.sep ])
        #Geometry2D
        self.encoded_message.extend([ str(0.0), self.sep, str(0.0), self.sep ])
        self.encoded_message.extend([ str(0.0), self.sep, str(0.0), self.sep ])
        #TrackingInfo
        self.encoded_message.extend([ str(0.0), self.sep, str(0.0)])

        self.decoded_message = DetectedObject(name="Fulano", object_type="person")
        self.decoded_message.context = self.context