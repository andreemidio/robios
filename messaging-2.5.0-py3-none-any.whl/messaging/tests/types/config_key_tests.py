#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.ConfigKey import ConfigKey
from messaging.tests.types.message_tests import MessageTests


class ConfigKeyTests(MessageTests):

    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(ConfigKey, include_header=False)
        self.encoded_message.extend([
            'core', self.sep, 'content', self.sep, 'hello_world'
        ])

        self.decoded_message = ConfigKey('core', 'content', 'hello_world')
        self.decoded_message.context = self.context