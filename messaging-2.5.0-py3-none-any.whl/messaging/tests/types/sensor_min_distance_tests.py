#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.Vector2 import Vector2
from messaging.types.Vector3 import Vector3
from messaging.types.SensorMinDistance import SensorMinDistance
from messaging.tests.types.message_tests import MessageTests


class SensorMinDistanceTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(SensorMinDistance, include_header=True)
        self.encoded_message.extend([ 
            'ir', self.sep, str(10), self.sep, str(False), self.sep, str(0.5), self.sep,
            str(0.0), self.sep, str(0.0), self.sep, 
            str(0.0), self.sep, str(0.0), self.sep, str(0.0)
        ])

        self.decoded_message = SensorMinDistance(Header(self.timestamp), 'ir', 10, False, 0.5, Vector2(), Vector3())
        self.decoded_message.context = self.context