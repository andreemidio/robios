#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.StringMessage import StringMessage
from messaging.tests.types.message_tests import MessageTests


class StringMessageTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(StringMessage, include_header=False)
        self.encoded_message.append('stringContent')

        self.decoded_message = StringMessage('stringContent')
        self.decoded_message.context = self.context