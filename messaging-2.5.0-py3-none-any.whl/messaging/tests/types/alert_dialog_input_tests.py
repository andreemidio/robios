#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.AlertDialogInput import AlertDialogInput
from messaging.tests.types.message_tests import MessageTests


class AlertDialogInputTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(AlertDialogInput, include_header=False)
        self.encoded_message.extend(['Field\'s Name', self.sep, 'Placeholder text', self.sep, 'Field\'s default value'])

        self.decoded_message = AlertDialogInput('Field\'s Name', 'Placeholder text', 'Field\'s default value')
        self.decoded_message.context = self.context