#!/usr/bin/env python

from messaging.types.UrlMessage import UrlMessage
from messaging.types.Header import Header
from messaging.tests.types.message_tests import MessageTests


class UrlMessageTests(MessageTests):

    def setUp(self) -> None:
        super().setUp()

        self.encoded_message = self.build_encoded_message(UrlMessage, include_header=True)
        self.encoded_message.append('https://humanrobotics.ai')

        self.decoded_message = UrlMessage(Header(self.timestamp), 'https://humanrobotics.ai')
        self.decoded_message.context = self.context