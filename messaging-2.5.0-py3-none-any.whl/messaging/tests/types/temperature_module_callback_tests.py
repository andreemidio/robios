#!/usr/bin/env python

import unittest
from messaging.message import Message
from messaging.types.Header import Header
from messaging.types.TemperatureModuleCallback import TemperatureModuleCallback
from messaging.tests.types.message_tests import MessageTests


class TemperatureModuleCallbackTests(MessageTests):
    
    def setUp(self):
        super().setUp()

        self.encoded_message = self.build_encoded_message(TemperatureModuleCallback, include_header=True)
        self.encoded_message.extend([
            str(TemperatureModuleCallback.STATUS_DEACTIVATED), self.sep, 
            str(-1), self.sep, str(10), self.sep, str(30), self.sep,
            str(27.5), self.sep, str(18.3)])

        self.decoded_message = TemperatureModuleCallback(Header(self.timestamp), TemperatureModuleCallback.STATUS_DEACTIVATED, -1, 10, 30, 27.5, 18.3)
        self.decoded_message.context = self.context
        self.decoded_message.header.timestamp = self.timestamp