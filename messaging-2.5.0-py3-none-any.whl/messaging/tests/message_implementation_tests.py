
import unittest
from messaging.message import Message
from messaging.tests.messages.MessageSample import MessageSample
from messaging.tests.messages.MessageArraySample import MessageArraySample
from messaging.tests.messages.MessageArrayBooleanSample import MessageArrayBooleanSample
from messaging.tests.messages.MessageArrayFloatSample import MessageArrayFloatSample
from messaging.tests.messages.MessageArrayIntSample import MessageArrayIntSample
from messaging.tests.messages.MessageArrayStringSample import MessageArrayStringSample

class MessageImplementationTests(unittest.TestCase):

    def test_pack(self):
        expected = [ str(False), str(0), str(0.0), "value" ]
        message = MessageSample()

        result = message.pack()

        self.assertEqual(expected, result)


    def test_unpack(self):
        expected_message = MessageSample()
        expected_message.bool_attr = True

        fields = [ str(True), str(0), str(0.0), "value" ]
        
        result = MessageSample()
        result.unpack(fields, 0)

        self.assertEqual(expected_message, result)


    def test_pack_array(self):
        expected = [ "ordinaryValue", "False#0#0.0#value#False#0#0.0#value#False#0#0.0#value" ]
        message = MessageArraySample()

        result = message.pack()

        self.assertEqual(expected, result)


    def test_pack_array_string(self):
        expected = ["ordinaryValue", "Item 1#Item 2#Item 3"]
        message = MessageArrayStringSample()
        
        result = message.pack()

        self.assertEqual(expected, result)


    def test_pack_array_boolean(self):
        expected = ["ordinaryValue", "True#False#True#False"]
        message = MessageArrayBooleanSample()

        result = message.pack()

        self.assertEqual(expected, result)


    def test_pack_array_int(self):
        expected = ["ordinaryValue", "4#3#2#1"]
        message = MessageArrayIntSample()

        result = message.pack()

        self.assertEqual(expected, result)


    def test_pack_array_float(self):
        expected = ["ordinaryValue", "1.5#2.0#3.5#10.0"]
        message = MessageArrayFloatSample()

        result = message.pack()

        self.assertEqual(expected, result)


    def test_unpack_array(self):
        expected_message = MessageArraySample()
        message = MessageSample()
        message.bool_attr = True
        expected_message.my_messages = [message, message, message]

        fields = ["ordinaryValue", "True#0#0.0#value#True#0#0.0#value#True#0#0.0#value"]

        result = MessageArraySample()
        result.unpack(fields, 0)

        self.assertEqual(expected_message, result)


    def test_unpack_array_string(self):
        expected_message = MessageArrayStringSample()
        expected_message.string_array = ["Item 3", "Item 2", "Item 1"]

        fields = ["ordinaryValue", "Item 3#Item 2#Item 1"]
        result = MessageArrayStringSample()
        result.unpack(fields, 0)

        self.assertEqual(expected_message, result)


    def test_unpack_array_boolean(self):
        expected_message = MessageArrayBooleanSample()
        expected_message.bool_array = [False, True, False, True]

        fields = ["ordinaryValue", "False#True#False#True"]
        result = MessageArrayBooleanSample()
        result.unpack(fields, 0)

        self.assertEqual(expected_message, result)


    def test_unpack_array_int(self):
        expected_message = MessageArrayIntSample()
        expected_message.int_array = [1, 2, 3, 4]

        fields = ["ordinaryValue", "1#2#3#4"]
        result = MessageArrayIntSample()
        result.unpack(fields, 0)

        self.assertEqual(expected_message, result)


    def test_unpack_array_float(self):
        expected_message = MessageArrayFloatSample()
        expected_message.float_array = [10.0, 3.5, 2.0, 1.5]

        fields = ["ordinaryValue", "10.0#3.5#2.0#1.5"]
        result = MessageArrayFloatSample()
        result.unpack(fields, 0)

        self.assertEqual(expected_message, result)


    def test_escape_text(self):
        expected = 'Test {0} Test {1} Test {0} Test {1} Test {0} Test {1} Test'.format(Message.SEPARATOR_ESCAPE, Message.LIST_SEPARATOR_ESCAPE)

        message = MessageSample()
        message._escape_strings = True
        result = message._escape_text('Test {0} Test {1} Test {0} Test {1} Test {0} Test {1} Test'.format(Message.SEPARATOR, Message.LIST_SEPARATOR))

        self.assertEqual(expected, result)


    def test_remove_escape(self):
        expected = 'Test {0} Test {1} Test {0} Test {1} Test {0} Test {1} Test'.format(Message.SEPARATOR, Message.LIST_SEPARATOR)

        message = MessageSample()
        message._escape_strings = True
        result = message._remove_escape('Test {0} Test {1} Test {0} Test {1} Test {0} Test {1} Test'.format(Message.SEPARATOR_ESCAPE, Message.LIST_SEPARATOR_ESCAPE))

        self.assertEqual(expected, result)


    def test_pack_string_with_escaping(self):
        expected = 'Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR_ESCAPE, Message.LIST_SEPARATOR_ESCAPE)

        message = MessageSample()
        message._escape_strings = True
        result = message._pack_field('Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR, Message.LIST_SEPARATOR))

        self.assertEqual(expected, result)


    def test_pack_string_without_escaping(self):
        expected = 'Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR, Message.LIST_SEPARATOR)

        message = MessageSample()
        message._escape_strings = False
        result = message._pack_field('Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR, Message.LIST_SEPARATOR))

        self.assertEqual(expected, result)


    def test_pack_field_bool(self):
        expected = str(True)

        message = MessageSample()
        result = message._pack_field(True)

        self.assertEqual(expected, result)


    def test_pack_field_int(self):
        expected = str(42)

        message = MessageSample()
        result = message._pack_field(42)

        self.assertEqual(expected, result)


    def test_pack_field_float(self):
        expected = str(3.14159)

        message = MessageSample()
        result = message._pack_field(3.14159)

        self.assertEqual(expected, result)


    def test_unpack_string_with_escaping(self):
        expected = 'Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR, Message.LIST_SEPARATOR)

        message = MessageSample()
        result = message._unpack_string('Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR_ESCAPE, Message.LIST_SEPARATOR_ESCAPE))

        self.assertEqual(expected, result)


    def test_unpack_string_without_escaping(self):
        expected = 'Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR, Message.LIST_SEPARATOR)

        message = MessageSample()
        message._escape_strings = False
        result = message._unpack_string('Hello {1} World with separator {0} characters {0}~{1}~{0}~{1}'.format(Message.SEPARATOR, Message.LIST_SEPARATOR))

        self.assertEqual(expected, result)


    def test_unpack_field_bool(self):
        expected = True

        message = MessageSample()
        result = message._unpack_boolean(str(True))

        self.assertEqual(expected, result)


    def test_unpack_field_int(self):
        expected = 42

        message = MessageSample()
        result = message._unpack_int(str(42))

        self.assertEqual(expected, result)


    def test_unpack_field_float(self):
        expected = 3.14159

        message = MessageSample()
        result = message._unpack_float(str(3.14159))

        self.assertEqual(expected, result)